# QC-R1 Agent 2: DevOps Automator Review

**Division:** Engineering
**YODA Role ID:** `engineering/devops-automator`
**Spec Under Review:** `services/inter-cube/deploy-yoda.ps1` (1140 lines, rev deploy-yoda/v0.5.0)
**Review Date:** 2026-03-28
**Template Version:** QC-R1 v1.1.2

---

## Findings

### Finding 1
- **Finding ID:** R1-A2-1
- **Section:** Step 3/8: Source code + build (line 242)
- **Severity:** CRITICAL
- **Finding:** `git clone --depth 1` clones the default branch tip with no tag, release, or commit SHA pinning. Every deployer invocation builds whatever happens to be on `main` at the time. A force-push, a bad merge, or a transient branch state produces a silently different binary. Combined with the absence of Cargo.lock verification (the lock file is never checked for integrity or even confirmed to exist), two machines running the deployer minutes apart can produce non-identical binaries with no record of what changed.
- **Recommendation:** Pin the clone to a tagged release or commit SHA: `git clone --depth 1 --branch $RELEASE_TAG $RepoUrl $RepoDir`. After clone, verify `Cargo.lock` exists and optionally compare its TIS-27 hash against a known-good value published alongside the release tag. Expose the pinned ref in the deployment payload so auditors can trace binary→source.
- **Verification:** Run the deployer twice against the same tag on separate machines and diff the resulting `Cargo.lock` files; they must be byte-identical. Verify the deployment payload includes the exact ref that was built.

### Finding 2
- **Finding ID:** R1-A2-2
- **Section:** Step 3/8: Source code + build (lines 271-292)
- **Severity:** CRITICAL
- **Finding:** After `cargo build --release` succeeds and the binary is confirmed to exist, no TIS-27 (or any) checksum is computed over the resulting `inter-cube-daemon.exe`. The binary is then registered as a Windows service and started without integrity verification. An attacker who compromises the build directory (or a supply-chain attack that modifies the binary between build and service start) would go undetected. This also means operators have no way to independently verify that their running binary matches a known-good artifact.
- **Recommendation:** After a successful build, compute a TIS-27 hash of the binary, display it to the operator, and embed it in the deployment payload (step 8). Before each service start, re-verify the hash. Publish the expected hash alongside each release tag so operators can cross-check. Cross-reference: Security Engineer (Agent 1) should assess the threat model for binary tampering between build and service start.
- **Verification:** After deployer completes, independently compute the TIS-27 hash of the binary and compare it against the value in the deployment payload. They must match.

### Finding 3
- **Finding ID:** R1-A2-3
- **Section:** Step 7/8: Service registration (line 528)
- **Severity:** IMPORTANT
- **Finding:** Each node is registered as a Windows service via a `cmd.exe /s /c` shim that invokes a `.bat` wrapper. This introduces a three-process chain (services.exe → cmd.exe → inter-cube-daemon.exe) that complicates PID tracking, signal delivery, and graceful shutdown. The Service Control Manager sends stop signals to `cmd.exe`, which does not propagate `CTRL_SHUTDOWN_EVENT` to child processes. The watchdog (lines 642-708) must therefore walk the entire process tree via WMI to identify legitimate daemon PIDs — a fragile approach that can misidentify processes if cmd.exe exits before the daemon, leaving orphans with no parent linkage to the service.
- **Recommendation:** Replace the cmd.exe/bat shim with a lightweight native service wrapper (e.g., NSSM, WinSW, or a custom Rust service harness) that directly manages the daemon process and forwards SCM signals. This eliminates the intermediate process and simplifies PID tracking. If the shim must remain, document the signal-propagation limitations and add a `GenerateConsoleCtrlEvent` call to the stop sequence.
- **Verification:** Stop a PlenumNET-Array3-* service via `Stop-Service` and confirm the underlying `inter-cube-daemon.exe` process terminates within 10 seconds without becoming orphaned.

### Finding 4
- **Finding ID:** R1-A2-4
- **Section:** Watchdog heredoc (lines 572, 909, 918)
- **Severity:** CRITICAL
- **Finding:** The watchdog script is scheduled to run as `SYSTEM` (line 909: `New-ScheduledTaskPrincipal -UserId "SYSTEM"`), but the log directory is constructed from `$env:USERPROFILE` (line 572: `$logDir = Join-Path $env:USERPROFILE '.plenumnet\logs'`). When running as SYSTEM, `$env:USERPROFILE` resolves to `C:\Windows\system32\config\systemprofile`, not the installing user's profile. This means: (a) the watchdog log is written to a different location than displayed to the operator at line 918 (`$env:USERPROFILE\.plenumnet\logs\watchdog.log`), which shows the *deployer's* user profile path; (b) the operator cannot find the watchdog log at the advertised path; (c) if the systemprofile directory has restrictive ACLs, the log write may fail silently. Meanwhile, the daemon logs are written to `$LOG_DIR` = `C:\PlenumNET\plenumnet-data\logs` (line 51), creating a split-brain log topology.
- **Recommendation:** Use the same log directory as the daemon services: `$LOG_DIR` (i.e., `C:\PlenumNET\plenumnet-data\logs`). Hardcode this path in the watchdog heredoc rather than relying on `$env:USERPROFILE`. Update the operator-facing message at line 918 to display the actual watchdog log path. Consolidate all PlenumNET logs under a single known directory.
- **Verification:** Run the watchdog as SYSTEM (via the scheduled task), then confirm the log file appears at the path displayed during deployment. Verify the path is `C:\PlenumNET\plenumnet-data\logs\watchdog.log`, not under systemprofile.

### Finding 5
- **Finding ID:** R1-A2-5
- **Section:** Watchdog heredoc: log rotation (lines 579-590)
- **Severity:** MINOR
- **Finding:** Log rotation uses a single backup file (`$wdLog.1`) with a 1MB threshold. There is no file locking; if two scheduled task instances overlap (possible if a run exceeds 2 minutes), both may attempt to rotate simultaneously, causing data loss or a sharing violation. Additionally, a single 1MB backup provides minimal history — approximately 12-24 hours of 2-minute watchdog cycles depending on LLM engine count.
- **Recommendation:** Add a mutex or lock file around the rotation logic. Consider retaining 3-5 rotated files (`.1` through `.5`) to preserve at least 48 hours of history. Alternatively, use the Windows Event Log for watchdog events and keep the file log as a secondary record.
- **Verification:** Simulate overlapping watchdog runs (trigger the scheduled task manually while one is already executing) and verify no log data is lost or corrupted.

### Finding 6
- **Finding ID:** R1-A2-6
- **Section:** Step 7/8: Coordinator health check (lines 549-561) + worker start (lines 563-568)
- **Severity:** IMPORTANT
- **Finding:** The coordinator health check polls for up to 30 seconds (15 iterations × 2 seconds). If the coordinator fails to respond, the deployer prints a warning ("continuing anyway") and proceeds to start all worker services. Workers are configured with `CUBE_CRS_URL=$LOCAL_CRS_URL` (line 492) and will attempt to connect to a non-responsive coordinator. This creates a race condition where workers start, fail their initial CRS connection, and fall into the bat wrapper's restart loop — consuming resources and filling logs with connection errors until the coordinator eventually becomes available (or never does). The failure mode is "warn and continue" when it should be "block."
- **Recommendation:** Make coordinator readiness a hard gate: if the health check fails after the polling window, do not start worker services. Print a clear error and instruct the operator to check the coordinator log. Provide a `--force` flag for operators who explicitly want to override this check.
- **Verification:** Stop the coordinator service, re-run the deployer, and confirm that worker services are NOT started and the deployer exits with a non-zero exit code.

### Finding 7
- **Finding ID:** R1-A2-7
- **Section:** Worker registration race (lines 563-568 vs 940-971)
- **Severity:** IMPORTANT
- **Finding:** Worker services are started at lines 563-568, but CRS registration (POST to `/api/salvi/inter-cube/crs/register`) does not occur until lines 940-971 — approximately 50 lines and a 3-second sleep later. This means workers are running and potentially serving requests before they are registered with the coordinator. If the daemon's startup logic requires a valid CRS registration before accepting connections, the worker will fail internally. If the daemon accepts connections without registration, it is reachable but invisible to the coordinator's topology — a split-brain condition.
- **Recommendation:** Reorder the sequence: register each worker with the CRS *before* starting its service, or have the daemon self-register on startup (and confirm this is the case in the daemon's source). If self-registration is the intended pattern, remove the deployer-side registration code to avoid duplication and conflicting state.
- **Verification:** Start a fresh deployment, query `$LOCAL_CRS_URL/api/salvi/inter-cube/crs/nodes` immediately after all services are started (before line 940), and confirm that all nodes are already registered. If they are not, the race is confirmed.

### Finding 8
- **Finding ID:** R1-A2-8
- **Section:** Entire script (lines 1-1140)
- **Severity:** IMPORTANT
- **Finding:** The deployer has no dry-run or mock mode. Every execution requires: (a) live network access to `https://plenumnet.replit.app` (lines 313, 553, 956, 1016); (b) Administrator privileges; (c) Windows service registration; (d) a full `cargo build`. There is no way to test the deployer's logic, validate configuration, or perform CI regression testing without live infrastructure. The QC-R1 review scope (§3: Deployment testing) requires that "product-specific validation requiring network services has a mock mode." This is missing entirely.
- **Recommendation:** Add a `-DryRun` switch that: (a) prints all commands that would be executed without executing them; (b) substitutes mock HTTP responses for all `Invoke-RestMethod` calls; (c) skips service registration and scheduled task creation; (d) outputs the deployment payload to stdout for inspection. This enables automated CI testing of the deployer script itself.
- **Verification:** Run `deploy-yoda.ps1 -DryRun` in a CI container without network access or admin privileges. Confirm it completes successfully, produces deterministic output, and exits with code 0.

### Finding 9
- **Finding ID:** R1-A2-9
- **Section:** Build process (entire script)
- **Severity:** IMPORTANT
- **Finding:** The script does not specify expected build duration, does not define an architecture matrix (e.g., x86_64, ARM64), and does not implement an atomic release policy. The QC-R1 review scope (§3: Deployment testing) requires that "the spec defines the expected CI duration for full-matrix retesting, identifies the parallelism strategy, and specifies a maximum acceptable wall-clock time." None of these are present. `CARGO_BUILD_JOBS=1` (line 273) forces serial compilation, which on a 4-core machine could mean 15-30 minute build times, but this is undocumented. There is no mechanism to prevent partial deployment if the build succeeds on one architecture but fails on another.
- **Recommendation:** Document expected build times per architecture. Add a build timeout (e.g., `Start-Process` with `-Timeout`). If multi-architecture support is planned, define the matrix and enforce atomic deployment — either all architectures succeed or none are deployed. Add `CARGO_BUILD_JOBS` as a configurable parameter with a documented default.
- **Verification:** Confirm the deployer's documentation includes expected build times. Verify that a build exceeding the timeout is terminated and the deployer exits with an error.

### Finding 10
- **Finding ID:** R1-A2-10
- **Section:** Watchdog: LLM engine restart (lines 749, 807, 875)
- **Severity:** IMPORTANT
- **Finding:** LLM engine restart commands are executed via `Start-Process -FilePath "cmd.exe" -ArgumentList "/c $($engine.restart_command)"` where `$engine.restart_command` is read from a JSON file (`llm-engines.json`). The restart_command value is interpolated directly into the cmd.exe argument string with no sanitization. A malicious or corrupted `llm-engines.json` file (writable by anyone with access to `C:\ProgramData\PlenumNET`) could inject arbitrary commands that execute as SYSTEM (since the watchdog runs as SYSTEM). This is a command injection vector. Cross-reference: Security Engineer (Agent 1) should assess this as a privilege escalation path.
- **Recommendation:** Validate the `restart_command` field against an allowlist of known executables (e.g., must start with a path to `llama-server` or a registered engine binary). Set restrictive ACLs on `C:\ProgramData\PlenumNET\llm-engines.json` (SYSTEM and Administrators only). Consider using a structured command format (executable + arguments array) instead of a single string passed to `cmd.exe /c`.
- **Verification:** Set `restart_command` to `"calc.exe & echo pwned"` in `llm-engines.json`, trigger the watchdog, and confirm the injected command does NOT execute.

### Finding 11
- **Finding ID:** R1-A2-11
- **Section:** Configuration (lines 46, 575-576, 885)
- **Severity:** MINOR
- **Finding:** Critical paths are hardcoded throughout the script: `C:\PlenumNET` (line 46), `C:\ProgramData\PlenumNET` (lines 575-576, 885), and `$env:USERPROFILE\.plenumnet` (lines 347, 572). There is no mechanism to override these paths for non-standard installations, testing environments, or multi-instance deployments on the same machine. The three distinct base directories (`C:\PlenumNET` for source/binary, `C:\ProgramData\PlenumNET` for LLM config, `$env:USERPROFILE\.plenumnet` for legacy identities) create a fragmented filesystem layout that is difficult to back up or relocate.
- **Recommendation:** Define a single `$PLENUM_ROOT` variable (defaulting to `C:\PlenumNET`) that can be overridden via environment variable or parameter. Derive all subdirectories from this root. Document the directory layout in the script header.
- **Verification:** Set `$env:PLENUM_ROOT = "D:\PlenumTest"`, run the deployer, and confirm all files are created under the custom root with no writes to `C:\PlenumNET` or `C:\ProgramData\PlenumNET`.

### Finding 12
- **Finding ID:** R1-A2-12
- **Section:** Step 8/8: Deployment payload (line 1012)
- **Severity:** MINOR
- **Finding:** The deployer version is hardcoded as `"deploy-yoda/v0.5.0"` (line 1012). This string is not derived from the script file, the git tag, or any other authoritative source. When the script is updated, the version string will drift unless a developer remembers to update line 1012. The deployment payload sent to the remote CRS will report stale version information, making it impossible to distinguish deployer versions across fleet deployments.
- **Recommendation:** Derive the version from a single source of truth: either a `$DEPLOYER_VERSION` constant at the top of the script (easy to grep/update) or parse it from the git tag of the deployer script itself. Add a CI check that validates the version string against the git tag.
- **Verification:** Grep the deployment payload for the `deployer` field and confirm it matches the script's declared version constant. Change the version constant and confirm the payload updates.

### Finding 13
- **Finding ID:** R1-A2-13
- **Section:** Step 8/8: Deployment payload (lines 997-1013)
- **Severity:** IMPORTANT
- **Finding:** The deployment payload posted to the remote CRS contains `hostname`, `ip`, `binaryPath`, `logDir`, `identityBase`, and per-daemon `identityDir` and `endpoint` fields — all of which are hostname/IP/filesystem-path identifiers. Per INVARIANT 9, all cryptographic operations and provenance records that bind node identity must use Rep C (54-trit) addressing exclusively. The payload identifies nodes by IP:port endpoint and Windows filesystem paths rather than by their Rep C addresses. While the payload includes an `address` field per daemon (populated at lines 945-958), the top-level node identification uses non-Rep-C identifiers. Audit trail correlation using this payload would rely on hostname/IP rather than Rep C addresses.
- **Recommendation:** Restructure the deployment payload so that the primary node identifier is the Rep C address. Move hostname, IP, and filesystem paths into a `metadata` sub-object clearly marked as operational context (not identity). Ensure that any log correlation or audit trail downstream uses the Rep C address as the join key, not hostname or IP.
- **Verification:** Inspect the deployment payload JSON. Confirm that each daemon's primary identifier is its Rep C address. Confirm that no downstream system uses `hostname` or `ip` as a node identity key.

### Finding 14
- **Finding ID:** R1-A2-14
- **Section:** Watchdog heredoc: summary output (lines 826-827)
- **Severity:** MINOR
- **Finding:** The watchdog emits a machine-parseable summary line (line 827) in JSON-like format: `[SUMMARY] {"daemons":"3/3","llms":"0/0","restarts":0,"orphans_killed":0}`. However, the `daemons` and `llms` fields are strings (e.g., `"3/3"`) rather than structured integers, making downstream parsing fragile. A consumer must split on `/` to extract numerator and denominator. The preceding status line (line 826) uses `[OK]`/`[WARN]`/`[FAIL]` prefixes mixed with free-text, which is not reliably parseable.
- **Recommendation:** Change the JSON summary to use integer fields: `{"daemons_healthy":3,"daemons_total":3,"llms_healthy":0,"llms_total":0,"restarts":0,"orphans_killed":0,"status":"ok"}`. This is directly consumable by monitoring systems without string parsing.
- **Verification:** Parse the watchdog log with `ConvertFrom-Json` on the SUMMARY line (after stripping the `[SUMMARY] ` prefix) and confirm all fields are their expected types (integers for counts, string for status).

---

## Summary Verdict

**FAIL** — Three CRITICAL findings (R1-A2-1, R1-A2-2, R1-A2-4) block implementation.

The deployer script builds from an unpinned branch tip with no source or binary integrity verification (R1-A2-1, R1-A2-2), meaning two deployments minutes apart can produce different, unverifiable binaries. The watchdog's log path resolves to a different directory when running as SYSTEM than what is displayed to the operator (R1-A2-4), rendering operational monitoring unreliable on every deployment. Beyond these critical blockers, the script starts workers against a potentially dead coordinator (R1-A2-6), registers nodes with the CRS after services are already running (R1-A2-7), passes unsanitized commands from a world-readable JSON file to cmd.exe running as SYSTEM (R1-A2-10), and identifies nodes by hostname/IP instead of Rep C addresses in the deployment payload (R1-A2-13). There is no dry-run mode for CI testing (R1-A2-8) and no build time or architecture matrix specification (R1-A2-9). The script is functional for manual single-machine deployment but does not meet the reproducibility, integrity, or operational robustness standards required for a production release. All three CRITICAL findings must be resolved before this script can proceed to QC-R2.

---

*Capomastro Holdings Ltd. — Applied Physics Division*
*Sherwood Park, Alberta, Canada*
