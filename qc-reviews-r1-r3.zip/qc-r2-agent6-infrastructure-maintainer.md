# QC-R2 Agent 6: Infrastructure Maintainer Review

**Spec Under Review:** `services/inter-cube/deploy-yoda.ps1` (1140 lines, rev deploy-yoda/v0.5.0)
**QC-R1 Input:** `.local/qc-r1-watchdog/qc-r1-consolidated.md` (29 findings, 7 CRITICAL)
**Review Date:** 2026-03-28
**Template Version:** QC-R2 v1.2.1
**Agent:** 6 — Infrastructure Maintainer (`support/infrastructure-maintainer`)
**Division:** Applied Physics Division — Support

---

## 1. Installation Experience

### Finding 1
- **Section:** Lines 9-10 — `irm | iex` invocation
- **Severity:** CRITICAL
- **Finding:** The deployer is served via `irm https://plenumnet.replit.app/api/deploy-yoda | iex`. If the network connection drops mid-download, PowerShell receives a truncated script and executes whatever partial content was received. There is no integrity check, no content-length verification, and no checksum validation. A partial script could leave the machine in an undefined state: partial clone, partial build environment, or worse — a half-registered service with no cleanup. Additionally, machines with execution policies set to `AllSigned` or `Restricted` (common in enterprise Group Policy) will silently refuse to execute the piped script, producing a cryptic error (`... is not recognized as the name of a cmdlet`) rather than a clear "execution policy blocks this script" message.
- **Recommendation:** (1) Add a SHA-256 or TIS-27 checksum header that the download endpoint can return; the first lines of the script should validate the rest. (2) Provide a `.bat` wrapper download alternative (mentioned at line 11 but not documented). (3) Add an execution policy check at the top of the script: `if ((Get-ExecutionPolicy) -in @('Restricted','AllSigned')) { Write-Host "ERROR: ExecutionPolicy is $(Get-ExecutionPolicy). Run: Set-ExecutionPolicy RemoteSigned -Scope CurrentUser"; return }`.
- **Verification:** Test on a machine with `Set-ExecutionPolicy Restricted`; test with network interruption mid-download (e.g., kill connection after 50% transfer).

### Finding 2
- **Section:** Lines 127-148 — STEP 1 prerequisite checks
- **Severity:** IMPORTANT
- **Finding:** When `git` is not found, the error message correctly tells the operator to install from `git-scm.com`. However, when `cargo` is not found, the script silently downloads and runs `rustup-init.exe` from `https://win.rustup.rs/x86_64` without asking for consent. On enterprise machines behind proxies, this download will fail silently (Invoke-WebRequest will throw, but the error is not caught before `Start-Process`). On ARM64 machines, the hardcoded `x86_64` URL downloads the wrong architecture. The operator is never told that Rust will be installed or given the option to decline.
- **Recommendation:** (1) Prompt the operator before installing Rust: "Rust is required but not installed. Install now? [Y/n]". (2) Detect architecture and use the appropriate rustup URL. (3) Wrap the Invoke-WebRequest in a try/catch with an actionable error: "Failed to download Rust installer. If behind a proxy, set $env:HTTPS_PROXY and re-run."
- **Verification:** Test on ARM64 Windows; test behind an HTTP proxy that blocks `win.rustup.rs`.

### Finding 3
- **Section:** Lines 204-233 — LLVM/clang installation
- **Severity:** IMPORTANT
- **Finding:** If `clang` is not found, the script attempts to install LLVM via `winget` or direct download from GitHub. The `winget install` call includes `--silent` which suppresses all UI, but the operator has no idea LLVM is being installed. If winget is unavailable, the script downloads a ~500MB LLVM installer from GitHub — on metered connections this is hostile. The GitHub API call to find the latest release (`Invoke-RestMethod "https://api.github.com/repos/llvm/llvm-project/releases/latest"`) will fail behind corporate proxies and produce a non-actionable error. The `/S` silent install flag for LLVM assumes NSIS installer; if LLVM changes their installer format, this breaks silently.
- **Recommendation:** (1) Inform the operator before large downloads: "LLVM (~500MB) is required. Downloading...". (2) Add proxy-aware error handling. (3) Consider documenting prerequisites upfront so operators can pre-install before running the deployer.
- **Verification:** Test on a machine without winget and behind a proxy; verify the error message when the GitHub API call fails.

### Finding 4
- **Section:** Lines 240-261 — STEP 3 clone/update
- **Severity:** IMPORTANT
- **Finding:** `git clone --depth 1` uses the default branch (main). If the operator's network blocks GitHub, or if GitHub is down, the clone fails with `ERROR: git clone failed.` — but the error message does not mention proxy configuration, SSH vs HTTPS, or firewall rules. The `git pull origin main --ff-only` on existing repos will silently fail if there are local modifications, leaving the operator on an older version without warning.
- **Recommendation:** (1) Enhance the clone error message: "ERROR: git clone failed. Check network connectivity, proxy settings ($env:HTTPS_PROXY), and firewall rules for github.com:443." (2) After `git pull --ff-only`, check `$LASTEXITCODE` and warn if the pull was rejected due to local changes. (3) Display the current commit SHA after clone/pull for audit trail.
- **Verification:** Test with `github.com` blocked in hosts file; test with dirty working tree.

### Finding 5
- **Section:** Lines 417-431 — Admin elevation
- **Severity:** IMPORTANT
- **Finding:** When running without admin privileges, the script attempts self-elevation via `Start-Process powershell.exe -Verb RunAs`. However, when invoked via `irm | iex`, `$MyInvocation.MyCommand.Definition` is empty (piped input has no file path), so the script falls back to: "ERROR: Cannot auto-elevate from piped input. Please run PowerShell as Administrator and re-run." This is the most common invocation path and it fails. The operator must: (a) know to open an admin PowerShell, (b) re-run the entire command, (c) re-download the script. Steps 1-6 (prerequisites, build) were completed as non-admin and are now wasted — but the script starts over from the beginning.
- **Recommendation:** (1) Check for admin at the very top of the script (before Step 1), not at Step 7. If not admin and piped, tell the operator immediately. (2) Alternatively, save the script to a temp file and re-launch from there. (3) Document that the `irm | iex` invocation requires an admin PowerShell window.
- **Verification:** Run `irm ... | iex` from a non-admin PowerShell; verify the error appears before any downloads or builds.

### Finding 6
- **Section:** Lines 527-541 — Service registration
- **Severity:** MINOR
- **Finding:** If `New-Service` fails (e.g., a service with the same name exists from a different product, or the binary path is too long), the error is caught but the message `[WARN] Could not register node #N as service: <exception>` does not tell the operator how to resolve it. The script continues to attempt starting the service anyway, which will fail.
- **Recommendation:** Add specific guidance: "If a service with this name already exists from a previous installation, run: sc.exe delete PlenumNET-Array3-N and re-run the deployer."
- **Verification:** Manually create a conflicting service name; verify the error message is actionable.

---

## 2. Error Messages and Diagnostics

### Finding 7
- **Section:** Lines 271-292 — Build failure
- **Severity:** MINOR
- **Finding:** When `cargo build` fails, the deployer shows `ERROR: Build failed.` with no additional context. The build output is filtered to only show lines matching "error" — but Rust compiler errors often span multiple lines with context, and the regex match `$line -match "error"` is overly broad (matches "error" anywhere in the line, including benign strings like "error-chain" crate name). The operator cannot diagnose build failures from the deployer output alone.
- **Recommendation:** (1) Write full build output to a log file (e.g., `$LOG_DIR\build.log`) and tell the operator where to find it. (2) Use a more specific regex for real errors. (3) Display the last 20 lines of build output on failure.
- **Verification:** Introduce a deliberate syntax error in a Rust file; verify the build failure message points to a log file with full output.

### Finding 8
- **Section:** Lines 592-594 — Watchdog log format
- **Severity:** IMPORTANT
- **Finding:** The watchdog log uses `[yyyy-MM-dd HH:mm:ss] message` format. The timestamp has no timezone indicator (UTC vs local is ambiguous). The `[SUMMARY]` JSON line (line 827) uses string ratios (`"3/3"`) instead of integer fields, making machine parsing fragile — a log aggregator would need to split on `/` to extract numerics. Log entries reference services by Windows service name (`PlenumNET-Array3-1`) and processes by PID, but never by Rep C address. An operator correlating watchdog logs with CRS registration records cannot join on any common key.
- **Recommendation:** (1) Use ISO 8601 timestamps with timezone: `Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK'`. (2) Change summary JSON to integer fields: `{"daemons_healthy":3,"daemons_total":3,...}`. (3) Include the node's Rep C address in each watchdog log entry (requires reading it from the identity directory or CRS health endpoint). This addresses INVARIANT 9.
- **Verification:** Parse the watchdog log with a JSON parser; verify all entries include a Rep C address field; verify timestamps include timezone offset.

### Finding 9
- **Section:** Lines 557-561 — Coordinator health check
- **Severity:** IMPORTANT
- **Finding:** If the coordinator health check fails after 30 seconds (15 attempts × 2s), the deployer prints `WARN: Coordinator health check did not respond -- continuing anyway` and proceeds to start worker nodes and register them. Workers will fail to register with a dead coordinator, producing confusing cascading errors. The "continuing anyway" approach means the deployer can complete "successfully" with all 3 nodes in a broken state.
- **Recommendation:** (1) Make coordinator health check a hard gate — if it fails, do not start workers. (2) Provide diagnostic guidance: "Coordinator failed to start. Check log at $LOG_DIR\array3-node-1.log for details." (3) Offer the operator a choice: "Coordinator not responding. [R]etry / [A]bort?"
- **Verification:** Block port 11124; run deployer; verify workers are not started against a dead coordinator.

---

## 3. Enterprise Environment Compatibility

### Finding 10
- **Section:** Lines 46, 885-888 — Hardcoded paths and NTFS permissions
- **Severity:** IMPORTANT
- **Finding:** The script hardcodes `C:\PlenumNET` as the installation directory and `C:\ProgramData\PlenumNET` for LLM config. In enterprise environments: (a) C: drive may have restricted write permissions via Group Policy, (b) ProgramData may be redirected, (c) the deployer creates these directories without setting explicit ACLs, inheriting whatever the parent has. On a locked-down machine, `New-Item -ItemType Directory -Force -Path "C:\PlenumNET"` will fail with an access denied error that is not caught or explained. The `C:\ProgramData\PlenumNET` directory is created with default ACLs that grant write access to all Authenticated Users — this is the root cause of C1 (LLM restart_command injection).
- **Recommendation:** (1) Allow the installation path to be overridden via environment variable: `$RepoDir = if ($env:PLENUMNET_DIR) { $env:PLENUMNET_DIR } else { "C:\PlenumNET" }`. (2) After creating directories, set explicit ACLs restricting write access to SYSTEM and Administrators. (3) Catch access denied errors with actionable messages: "Cannot create C:\PlenumNET — check NTFS permissions or set $env:PLENUMNET_DIR to an alternative path."
- **Verification:** Test on a machine where C: root is write-protected; test with redirected ProgramData.

### Finding 11
- **Section:** Lines 286-292, 527-533 — Unsigned binary
- **Severity:** IMPORTANT
- **Finding:** The deployer builds `inter-cube-daemon.exe` from source and immediately registers it as a Windows Service running as SYSTEM. The binary is unsigned — no Authenticode signature, no TIS-27 hash verification. Enterprise antivirus/EDR (CrowdStrike, Defender ATP, Carbon Black) will quarantine or block unsigned binaries launched as SYSTEM services. There is no documentation telling the operator how to whitelist the binary or the installation directory. This will be the #1 support call in enterprise deployments.
- **Recommendation:** (1) Document AV exclusion requirements: "Add C:\PlenumNET\target\release\inter-cube-daemon.exe to your antivirus exclusion list." (2) Compute and display a TIS-27 hash of the built binary for the operator to verify. (3) Long-term: implement Authenticode signing in CI. (4) Add a post-build AV check: attempt to read the binary and warn if it was quarantined.
- **Verification:** Deploy on a machine with Windows Defender real-time protection enabled; verify the binary is not quarantined; verify the deployer warns if it is.

### Finding 12
- **Section:** Lines 242, 49 — Proxy and firewall
- **Severity:** MINOR
- **Finding:** The deployer accesses three external endpoints: `github.com` (git clone), `win.rustup.rs` (Rust install), and `plenumnet.replit.app` (CRS + relay). None of these operations are proxy-aware. Corporate environments using explicit proxies (`$env:HTTPS_PROXY`) may have these configured, but the deployer never checks or mentions proxy settings. The WebSocket relay connection (used post-deployment for NAT traversal) will also fail behind corporate firewalls that block WebSocket upgrades.
- **Recommendation:** (1) At the top of the script, detect and display proxy settings: "Proxy: $env:HTTPS_PROXY" or "Proxy: none detected". (2) Add a network connectivity pre-check for all three endpoints. (3) Document firewall requirements: "Outbound HTTPS (443) to github.com, win.rustup.rs, plenumnet.replit.app. WebSocket upgrade must be permitted to plenumnet.replit.app."
- **Verification:** Test behind a proxy; verify error messages mention proxy configuration.

---

## 4. Day-Two Operations

### Finding 13
- **Section:** Post-deployment — Health verification
- **Severity:** IMPORTANT
- **Finding:** After deployment, the operator has no documented way to verify all 3 nodes are healthy other than manually hitting `http://localhost:11124/health`, `http://localhost:11151/health`, and `http://localhost:11178/health`. There is no `plenumnet-status` command, no dashboard URL, no PowerShell one-liner. The watchdog runs silently as a scheduled task — the operator cannot see its output without knowing to check `$env:USERPROFILE\.plenumnet\logs\watchdog.log` (which is the wrong path when running as SYSTEM — see C7). The deployer summary mentions `$REMOTE_CRS/api/salvi/inter-cube/relay/deployments` but this is a remote monitoring endpoint, not a local health dashboard.
- **Recommendation:** (1) Create a `plenumnet-health.ps1` script that queries all 3 nodes and displays a formatted status table. (2) Include the health check URLs in the deployment summary. (3) Add a `plenumnet-service.ps1 -Action status` command. (4) Document the watchdog log location in the deployment summary (using the correct path).
- **Verification:** After deployment, an operator should be able to verify cluster health with a single command.

### Finding 14
- **Section:** Post-deployment — Upgrade procedure
- **Severity:** IMPORTANT
- **Finding:** There is no documented upgrade procedure. The deployer appears to support re-running (`git pull` if repo exists, stop running daemons before rebuild), but this is not documented. Questions an operator would ask: Does re-running the deployer preserve identities? (Yes, if `master.key` exists — line 370-383). Does it preserve service registrations? (It deletes and re-creates — lines 518-521). Does it preserve the watchdog scheduled task? (It unregisters and re-registers — lines 898-903). Is there downtime? (Yes, all nodes are stopped at line 264-268 before rebuild). Is there a rollback procedure? (No). Are identity keys backed up before upgrade? (No). Is there a key freshness check before upgrade? (No).
- **Recommendation:** (1) Document the upgrade procedure explicitly: "To upgrade, re-run the deployer. Identities are preserved. Expect 5-15 minutes of downtime during rebuild." (2) Add an identity backup step before upgrade. (3) Warn if keys are in Aging zone per key freshness lifecycle.
- **Verification:** Run the deployer twice; verify identities are preserved; verify services restart correctly.

### Finding 15
- **Section:** Post-deployment — Coordinator failure
- **Severity:** IMPORTANT
- **Finding:** If Node #1 (coordinator) dies, workers continue running but cannot re-register or discover new peers. The watchdog will restart the coordinator service, but there is no documentation on what happens to workers during coordinator downtime. Do workers queue registration requests? Do they operate independently? Do they lose their CRS-assigned addresses? If the coordinator's identity is compromised, there is no re-keying procedure documented — the operator would need to delete `identity-1/master.key` and re-run the deployer, but this changes the coordinator's Rep C address, breaking all worker registrations.
- **Recommendation:** (1) Document coordinator failure behavior. (2) Document re-keying procedure for compromised identities. (3) Document the impact of coordinator address change on workers.
- **Verification:** Stop Node #1 service; verify watchdog restarts it; verify workers reconnect.

---

## 5. Uninstall Experience

### Finding 16
- **Section:** Entire script — No uninstall procedure
- **Severity:** CRITICAL
- **Finding:** There is no uninstall procedure anywhere in the deployer or referenced by it. After deployment, the following artifacts exist on the machine with no documented removal process: (a) 3 Windows Services (`PlenumNET-Array3-1/2/3`), (b) 1 Scheduled Task (`PlenumNET-Array3-Watchdog`), (c) `C:\PlenumNET` directory (full git repo + build artifacts), (d) `C:\PlenumNET\plenumnet-data` (identity keys, logs), (e) `C:\ProgramData\PlenumNET` (LLM config, health counters), (f) `C:\PlenumNET\services\wrappers` (wrapper .bat files), (g) 2 Desktop launchers (`Start PlenumNET Array3.bat`, `Stop PlenumNET Array3.bat`), (h) Cargo/Rust toolchain (if installed by deployer), (i) LLVM toolchain (if installed by deployer). An operator who wants to cleanly remove PlenumNET must manually discover and remove all of these. There is no guidance on whether identity keys should be preserved or destroyed.
- **Recommendation:** Create an `uninstall-yoda.ps1` script that: (1) Stops and removes all 3 services. (2) Removes the watchdog scheduled task. (3) Removes desktop launchers. (4) Asks whether to preserve identity keys. (5) Removes `C:\ProgramData\PlenumNET`. (6) Optionally removes `C:\PlenumNET`. (7) Does NOT remove Rust/LLVM (they may be used by other tools). Include the uninstall script URL in the deployment summary.
- **Verification:** Run the uninstaller; verify all artifacts are removed; verify `Get-Service PlenumNET-Array3-*` returns nothing; verify the scheduled task is gone.

---

## 6. Documentation Gaps

### Finding 17
- **Section:** Entire script — Missing operator documentation
- **Severity:** IMPORTANT
- **Finding:** The deployer is the only documentation. There is no separate deployment guide, troubleshooting FAQ, architecture diagram, port allocation table, or log file reference. An operator deploying for the first time must read 1140 lines of PowerShell to understand: what ports are used (81 total: 27×3), what services are created, where logs are, how the watchdog works, what the relay does, how CRS registration works. The `.SYNOPSIS` block (lines 1-37) is excellent but only visible if the operator reads the source.
- **Recommendation:** Create the following companion documents: (1) `DEPLOY-GUIDE.md` — step-by-step prerequisites, deployment, verification, upgrade, uninstall. (2) `PORT-ALLOCATION.md` — table of all 81 ports with their purpose. (3) `TROUBLESHOOTING.md` — common errors and resolutions. (4) `ARCHITECTURE.md` — diagram showing coordinator/worker/relay/CRS relationships. (5) `LOG-REFERENCE.md` — log file locations, formats, rotation policy.
- **Recommendation:** These can be a single `docs/array3-operations.md` file.
- **Verification:** A new operator can deploy, verify, and troubleshoot using only the documentation (no source reading required).

### Finding 18
- **Section:** Lines 108-116 — Port allocation display
- **Severity:** MINOR
- **Finding:** The deployment banner displays gateway ports, terminal ports, and port ranges, but does not explain what each port type does. An operator sees "Gateway Ports: 11124, 11151, 11178" and "Terminal Ports: 11122, 11149, 11176" but has no context for what "gateway" vs "terminal" means, which ports need firewall rules, or which ports are exposed externally vs localhost-only.
- **Recommendation:** Add brief descriptions: "Gateway: HTTP API (localhost only). Terminal: PTY mux (localhost only). Relay: WebSocket to plenumnet.replit.app:443 (outbound only)."
- **Verification:** Operator can determine firewall requirements from the deployment output alone.

---

## 7. Audit Trail and Provenance

### Finding 19
- **Section:** Lines 997-1013 — Deployment payload (INVARIANT 9)
- **Severity:** CRITICAL
- **Finding:** The deployment payload sent to the remote CRS uses `hostname` and `ip` as top-level fields (lines 998-999). While `address` fields exist inside the `daemons` array (line 988), the payload structure places hostname/IP at the same level as — or above — Rep C addresses. The remote dashboard receiving this payload will index by hostname/IP, not by Rep C address. This directly violates INVARIANT 9: "No cryptographic operation may use hostname, IP address, Windows SID, or any non-Rep-C identifier as an identity binding." Even for monitoring-only payloads, using hostname/IP as primary identifiers creates ambiguity when machines change hostnames or IP addresses (DHCP lease renewal, VPN reconnect).
- **Recommendation:** (1) Make `address` (Rep C) the primary identifier at the top level of the deployment payload. (2) Move `hostname` and `ip` into a `metadata` sub-object. (3) If Rep C addresses are not yet available (coordinator not responding), defer the deployment payload until addresses are known. (4) Sign the payload with TL-DSA (cross-reference to Security Engineer).
- **Verification:** Inspect the JSON payload sent to the remote CRS; verify the top-level identifier is a Rep C address; verify hostname/IP are in a metadata sub-object.

### Finding 20
- **Section:** Lines 624-827 — Watchdog log entries (INVARIANT 9)
- **Severity:** CRITICAL
- **Finding:** Watchdog log entries reference nodes exclusively by Windows service name (`PlenumNET-Array3-1`, `PlenumNET-Array3-2`, `PlenumNET-Array3-3`) and by PID. No log entry contains a Rep C address. The `[SUMMARY]` JSON line contains aggregate counts but no node-level identity. An operator correlating watchdog events with CRS registration records, relay connections, or deployment payloads cannot join on any common identifier because the watchdog uses service names while CRS uses Rep C addresses. This violates INVARIANT 9's requirement that "all logs, audit records, and provenance entries reference nodes exclusively by their Rep C address."
- **Recommendation:** (1) At watchdog startup, read each node's Rep C address from its identity directory (or query its health endpoint). (2) Include the Rep C address in every log entry: `[2026-03-28T14:30:00-06:00] [111.222.333.111.1] Service PlenumNET-Array3-1 restarted`. (3) Include per-node Rep C addresses in the summary JSON.
- **Verification:** Grep watchdog log for Rep C address pattern (`\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\.\d`); verify every node-level entry includes one.

### Finding 21
- **Section:** Lines 953-970 — CRS registration
- **Severity:** IMPORTANT
- **Finding:** Worker registration with the local CRS sends `{publicKey, endpoint}` over plaintext HTTP to localhost. While localhost traffic is not network-exposed, the lack of TL-DSA signature means any local process can register rogue nodes with the coordinator. The registration response contains the assigned Rep C address, but the deployer only stores it in memory — if the deployer crashes after registration but before writing the deployment payload, the assigned address is lost. This is an operational concern beyond the security issue flagged in C3 — it means the operator cannot recover the assigned addresses without re-registering.
- **Recommendation:** (1) Persist assigned addresses to a file immediately after registration: `$IdentityBase\identity-N\address.txt`. (2) On re-run, read the address file instead of re-registering if the address is already assigned. (3) Cross-reference to C3 for the signature requirement.
- **Verification:** Kill the deployer mid-registration; re-run; verify addresses are recoverable.

---

## Round 1 Response

### C1: LLM `restart_command` Injection → SYSTEM Privilege Escalation
**AGREE.** This is the most operationally dangerous finding. From an infrastructure perspective, the default NTFS ACLs on `C:\ProgramData` are well-known to grant write access to Authenticated Users. Combined with SYSTEM execution via `cmd.exe /c` string interpolation, this is a textbook privilege escalation. The fix recommendations (ACL restriction, allowlist validation, `Start-Process -FilePath` instead of `cmd.exe /c`) are all operationally sound and should be implemented before any production deployment. I add: the deployer itself should set restrictive ACLs on `C:\ProgramData\PlenumNET` immediately after creating the directory (Finding 10 in this review).

### C2: LLM Server Path Planting → Privilege Escalation
**AGREE.** The `llama-server.exe` search path includes `$env:LOCALAPPDATA` (line 857), which is user-writable. A planted binary persisted into the SYSTEM-executed JSON config is a second privilege escalation vector. From an operator perspective, this is particularly insidious because the deployer reports `[OK] llama-server found at: <path>` — the operator sees a success message for a planted binary. The fix (pin search to admin-only directories + verify signature/hash) is correct. I add: the deployer should display a warning if the discovered path is in a user-writable directory.

### C3: Unsigned CRS Registration → Identity Spoofing (INVARIANT 7)
**PARTIALLY AGREE.** The finding is valid — registration should be signed. However, from an operational perspective, the CRS registration is localhost-only and happens during a brief window during deployment. The practical risk is lower than C1/C2 because exploitation requires a malicious process running on the same machine at exactly the right time. The recommendation to add TL-DSA signatures is correct but should be prioritized below C1/C2. I adjust: implement signature verification as a v0.6.0 requirement, but immediately restrict the CRS `/register` endpoint to accept connections only from `127.0.0.1` (if not already restricted).

### C4: Deployment Payload Uses Hostname/IP as Identity (INVARIANT 9)
**AGREE.** See Finding 19 in this review. The deployment payload structure places hostname/IP at the top level, violating INVARIANT 9. The recommendation to restructure with Rep C as primary identifier is correct and operationally necessary — when machines change hostnames or IPs, the monitoring dashboard will show orphaned entries that cannot be correlated with current nodes.

### C5: No TIS-27 Binary Integrity Checksum
**AGREE.** From an operator perspective, this is critical for day-two operations. When an AV quarantines the binary or a filesystem corruption occurs, the operator has no way to verify whether the binary on disk matches what was built. The recommendation to compute TIS-27 hash after build and re-verify before service start is operationally sound. I add: display the hash in the deployment summary so operators can record it in their change management system.

### C6: Unpinned Source Clone → Non-Reproducible Builds
**AGREE.** Two operators deploying hours apart can produce different binaries with no record of what changed. This is an operational nightmare for incident response — "which version is running on which machine?" has no answer. The recommendation to pin to a tagged release or commit SHA is correct. I add: the deployment payload (line 1012) includes `deployer: "deploy-yoda/v0.5.0"` but does not include the source commit SHA — add a `sourceCommitSha` field.

### C7: Watchdog Log Path Mismatch (SYSTEM vs. User Profile)
**AGREE.** This is the finding I care most about as an operator. The watchdog runs as SYSTEM (line 909), so `$env:USERPROFILE` resolves to `C:\Windows\system32\config\systemprofile`, not the deploying user's profile. The deployer displays the log path using the deploying user's `$env:USERPROFILE` (line 918), so the operator is told to look in the wrong location. The fix (hardcode to `C:\PlenumNET\plenumnet-data\logs\watchdog.log`) is exactly right. I add: the same issue affects the watchdog's `$logDir` variable at line 572 — it must also be changed.

---

## Operator Readiness Checklist

| # | Question | Answered? | Where |
|---|----------|-----------|-------|
| 1 | What are the hardware/software prerequisites? | PARTIALLY | Lines 127-233 check at runtime but no upfront list |
| 2 | What ports will be used and do any need firewall rules? | PARTIALLY | Lines 108-112 list ports but don't explain purpose |
| 3 | Does the deployer need admin privileges? | YES | Lines 417-431 |
| 4 | How long does deployment take? | NO | Not documented |
| 5 | What external endpoints must be reachable? | NO | github.com, win.rustup.rs, plenumnet.replit.app not listed |
| 6 | What disk space is required? | NO | Not documented (repo + build can exceed 5GB) |
| 7 | Can the installation path be customized? | NO | Hardcoded to C:\PlenumNET |
| 8 | What services will be created? | YES | Lines 1125-1127 |
| 9 | How do I verify the cluster is healthy after deployment? | NO | No health check command provided |
| 10 | Where are the log files? | PARTIALLY | Line 1134 shows daemon logs; watchdog log path is wrong (C7) |
| 11 | How do I upgrade to a new version? | NO | Not documented |
| 12 | How do I uninstall? | NO | No uninstall procedure exists |
| 13 | What happens if I re-run the deployer? | PARTIALLY | Implied by code but not documented |
| 14 | Are identity keys backed up? | NO | No backup procedure |
| 15 | What if a node's identity is compromised? | NO | No re-keying procedure |
| 16 | What if the coordinator dies? | NO | Not documented |
| 17 | Does the deployer work behind a corporate proxy? | NO | No proxy documentation |
| 18 | Does the deployer work on ARM64 Windows? | PARTIALLY | Architecture detected (line 157) but rustup URL is x86_64-only |
| 19 | What AV exclusions are needed? | NO | Not documented |
| 20 | How is the watchdog monitored? | PARTIALLY | Scheduled task name given but log path is wrong |
| 21 | Can I deploy to a non-default drive? | NO | Hardcoded C: paths |
| 22 | What happens on a machine with execution policy restrictions? | NO | No execution policy check |
| 23 | Are deployed nodes identified by Rep C address in all records? | NO | Hostname/IP used in deployment payload and watchdog logs |
| 24 | Is there a dry-run mode? | NO | All steps are destructive |
| 25 | What is the rollback procedure if deployment fails mid-way? | NO | No rollback; partial state left on machine |

**Score: 3 YES / 7 PARTIALLY / 15 NO**

---

## Summary Verdict: **FAIL**

The deployer is well-structured and the step-by-step flow is logically sound. The embedded watchdog is a genuinely useful operational component with good architecture (BFS orphan detection, two-tier LLM health checks, grace periods, exponential backoff). However, from an operator's perspective, the script has critical gaps that prevent production deployment:

1. **No uninstall procedure** (Finding 16) — an operator cannot cleanly remove PlenumNET from a machine.
2. **INVARIANT 9 violations** in both the deployment payload (Finding 19) and watchdog logs (Finding 20) — nodes are identified by hostname/IP/service-name instead of Rep C addresses, making cross-system correlation impossible.
3. **Watchdog log path mismatch** (C7, confirmed) — the operator is told to look in the wrong location for watchdog logs.
4. **Truncated `irm | iex` execution** (Finding 1) — partial downloads execute as truncated scripts with no integrity protection.
5. **Admin check too late** (Finding 5) — the most common invocation path (`irm | iex` as non-admin) wastes 10+ minutes of download/build before failing.
6. **15 of 25 operator readiness questions unanswered** — the operator cannot deploy confidently without reading the source code.

All 7 CRITICAL findings from QC-R1 are confirmed (6 AGREE, 1 PARTIALLY AGREE). This review adds 3 additional CRITICAL findings (Findings 1, 16, 19/20). The deployer must not proceed to production use until these are resolved.

---

*Capomastro Holdings Ltd. — Applied Physics Division*
*QC-R2 Agent 6 — Infrastructure Maintainer — 2026-03-28*
