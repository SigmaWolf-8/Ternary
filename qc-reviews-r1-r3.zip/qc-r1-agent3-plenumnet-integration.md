# QC-R1 Agent 3: PlenumNET Integration Specialist Review

**Document Under Review:** `services/inter-cube/deploy-yoda.ps1` (1140 lines)
**Revision:** deploy-yoda/v0.5.0
**Review Date:** 2026-03-28
**Reviewer:** PlenumNET Integration Specialist (Agent 3)
**Scope:** Array3 Deployer (Steps 1-8) + Embedded Watchdog Heredoc (lines 571-828)

---

### Finding 1
- **Finding ID:** R1-A3-1
- **Section:** Step 6 — CRS Registration (lines 953-970)
- **Severity:** CRITICAL
- **Finding:** CRS registration POST to `/api/salvi/inter-cube/crs/register` (line 956) sends `publicKey` and `endpoint` (hostname:port) as plain JSON without a TL-DSA signature. There is no cryptographic proof that the registering node actually possesses the corresponding private key. An attacker on the local network can register an arbitrary public key with a malicious endpoint, hijacking the node identity. Per INVARIANT 7, all identity-binding operations must use TL-DSA signatures. The registration payload should include a TL-DSA signature over (publicKey, endpoint, timestamp) signed by the registering node's private key, which the CRS coordinator verifies before accepting registration.
- **Recommendation:** Add a `signature` field to the CRS registration payload containing a TL-DSA signature over a canonical message `"CRS-REGISTER" || publicKey || endpoint || timestamp`, signed by the node's PT26-DSA private key. The CRS coordinator must verify this signature before accepting the registration. The deployer must invoke the daemon binary with a signing mode (e.g., `CUBE_MODE=sign-registration`) to produce this signature.
- **Verification:** Confirm that registration requests without a valid TL-DSA signature are rejected by the CRS coordinator with HTTP 401/403. Replay a captured registration payload and verify the CRS rejects it due to stale timestamp.
- **Crypto Status:** INCORRECT — registration lacks TL-DSA signature, violating INVARIANT 7.

### Finding 2
- **Finding ID:** R1-A3-2
- **Section:** Step 8 — Deployment Payload (lines 997-1013)
- **Severity:** CRITICAL
- **Finding:** The deployment payload posted to the remote PlenumNET Node Registry (line 1016) uses `hostname` (`$env:COMPUTERNAME`, line 978), `ip` (local IPv4 address, line 999), and `endpoint` (IP:port, line 990) as node identifiers. Per INVARIANT 9, all cryptographic operations that bind node identity must use Rep C (54-trit, binary-encoded) addressing exclusively. No cryptographic operation may use hostname, IP address, or any non-Rep-C identifier as an identity binding. The deployment payload does include an `address` field (line 988) that appears to be the CRS-assigned Rep C address, but the `hostname`, `ip`, and `endpoint` fields are also present and could be used by the registry for identity correlation, violating INVARIANT 9.
- **Recommendation:** (1) The deployment payload should use only the Rep C `address` field as the primary node identifier. (2) The `hostname`, `ip`, and `endpoint` fields may remain as operational metadata but must be clearly documented as non-identity, non-cryptographic fields. (3) The remote registry must not use hostname/IP for any cryptographic binding, authentication decision, or identity verification. (4) The payload should include a TL-DSA signature binding the Rep C address to the deployment summary to prevent spoofed deployment reports.
- **Verification:** Confirm that the remote registry indexes deployments by Rep C address, not hostname/IP. Confirm that the deployment POST includes a TL-DSA signature over the payload keyed to the coordinator's Rep C address.
- **Crypto Status:** INCORRECT — deployment identity uses hostname/IP rather than Rep C addresses for binding (INVARIANT 9 violation).

### Finding 3
- **Finding ID:** R1-A3-3
- **Section:** Step 3 — Build + Step 4 — Version Check (lines 286-292, 299-309)
- **Severity:** IMPORTANT
- **Finding:** After building the binary (line 274-280), the script checks that the file exists (line 286) and reports its size (line 291), but performs no integrity verification. Per the DevOps critical rules and INVARIANT 7, all integrity checks must use TIS-27 (not SHA-256, not BLAKE3). The binary `inter-cube-daemon.exe` has no TIS-27 checksum computed, stored, or verified at any point in the deployment flow. An attacker who compromises the build output directory or replaces the binary between build and service registration would not be detected. Cross-reference: Security Engineer (Agent 1) should assess the privilege escalation risk of unsigned binary execution as a SYSTEM-level Windows Service.
- **Recommendation:** After build, compute a TIS-27 checksum of the binary and log it. Before registering as a Windows Service, re-compute the TIS-27 checksum and compare. Optionally, the daemon binary should support a `--verify-self` mode that checks its own TIS-27 integrity at startup. Store the expected checksum in a protected location (e.g., the identity directory).
- **Verification:** Tamper with the binary after build (e.g., append a byte). Verify that the deployer detects the mismatch and refuses to register the service.
- **Crypto Status:** INCORRECT — no TIS-27 integrity check on the deployed binary.

### Finding 4
- **Finding ID:** R1-A3-4
- **Section:** Step 6 — Identity Generation (lines 370-384)
- **Severity:** IMPORTANT
- **Finding:** Identity generation via `CUBE_MODE=keygen` (line 372) creates a `master.key` file without setting a passphrase. The keygen invocation sets only `CUBE_MODE` and `CUBE_IDENTITY_DIR` — there is no `CUBE_PASSPHRASE` or interactive passphrase prompt. Per TM-2026-016 (PT26-DSA security analysis), key material should be protected at rest. An unencrypted `master.key` on disk means any local process with read access to the identity directory can exfiltrate the private key. This is especially concerning because the identity directory is under `C:\PlenumNET\plenumnet-data\identity-N`, which may be world-readable on default NTFS configurations. Cross-reference: Security Engineer (Agent 1) for credential-at-rest assessment.
- **Recommendation:** (1) The deployer should set a machine-derived passphrase (e.g., via DPAPI on Windows) and pass it to keygen via `CUBE_PASSPHRASE` environment variable. (2) Alternatively, the daemon's keygen mode should support passphrase-less keys that are encrypted using the OS credential store (Windows DPAPI). (3) At minimum, restrict the identity directory ACL to SYSTEM and Administrators only immediately after creation.
- **Verification:** After deployment, verify that `master.key` is either encrypted or that the identity directory has restrictive ACLs (no Users/Everyone read access). Attempt to read the key file from a non-admin user session and confirm it is denied.
- **Crypto Status:** UNVERIFIED — cannot confirm whether the daemon internally encrypts the key file; the deployer does not set any passphrase.

### Finding 5
- **Finding ID:** R1-A3-5
- **Section:** Step 6 — Identity Migration (lines 347-358)
- **Severity:** IMPORTANT
- **Finding:** Identity migration from `$env:USERPROFILE\.plenumnet` to `C:\PlenumNET\plenumnet-data` performs a raw `Copy-Item` of the entire `identity-N` directory (line 354) without any re-encryption, passphrase verification, or integrity check of the migrated `master.key`. If the source key was corrupted or tampered with, the corrupted key is silently propagated to the new location. Additionally, the old identity directory is not deleted after migration, leaving a second copy of the private key material on disk.
- **Recommendation:** (1) After copying, compute TIS-27 checksum of source and destination `master.key` and verify they match. (2) After successful migration and verification, securely delete the source identity directory (overwrite + remove, or at minimum remove with a warning to the operator). (3) If the daemon supports passphrase-protected keys in the future, the migration should prompt for the passphrase and re-encrypt under the new location's credential store.
- **Verification:** Corrupt a byte in the source `master.key` before migration. Verify that the deployer detects the mismatch. Verify that after successful migration, the old directory is removed or the operator is warned.
- **Crypto Status:** INCORRECT — no integrity verification during key migration.

### Finding 6
- **Finding ID:** R1-A3-6
- **Section:** Step 6 — PT26-DSA Public Key Extraction (lines 386-395)
- **Severity:** IMPORTANT
- **Finding:** The public key is extracted by re-running the daemon in `CUBE_MODE=keygen` and parsing stdout with a regex (`PT26-DSA Public Key|Public Key|pk:` on line 392, then hex extraction on line 393). This approach is fragile: (1) Any change to the daemon's stdout format (log prefix, localization, additional output) breaks extraction silently. (2) Running keygen a second time on an existing key directory may have side effects depending on daemon implementation (could overwrite keys, generate new ones, or error). (3) The regex allows multiple label patterns, indicating uncertainty about the actual output format. A structured output (JSON, exit code, or dedicated `--show-pubkey` mode) would be robust.
- **Recommendation:** (1) Add a `CUBE_MODE=info` or `CUBE_MODE=show-pubkey` mode to the daemon that outputs only the public key in a machine-readable format (e.g., single line hex or JSON `{"publicKey":"..."}`) and exits. (2) Alternatively, have keygen write the public key to a `public.key` file in the identity directory alongside `master.key`, and read it from there. (3) Remove the redundant keygen re-invocation.
- **Verification:** Change the daemon's log format (e.g., prefix "INFO:") and verify the deployer still correctly extracts the public key. If it fails, the finding is confirmed.
- **Crypto Status:** UNVERIFIED — cannot confirm correctness of key extraction without testing against actual daemon output format.

### Finding 7
- **Finding ID:** R1-A3-7
- **Section:** Step 4 — Version Detection (lines 300-309)
- **Severity:** MINOR
- **Finding:** Version detection runs the daemon in `CUBE_MODE=keygen` with a temporary directory (`plenumnet-version-probe` in TEMP) to extract a version string from stdout (line 307). This is an abuse of keygen mode — it generates a throwaway identity just to read a version line. The temporary identity directory is created (line 303) but never cleaned up. This leaves orphaned key material in the system TEMP directory. Additionally, the version regex on line 308 (`\d+\.\d+\.\d+`) may match version-like strings in dependency output or error messages.
- **Recommendation:** (1) Add a `--version` flag or `CUBE_MODE=version` to the daemon that prints only the version and exits without generating any key material. (2) Clean up the temporary directory after version detection (`Remove-Item` on the version-probe directory). (3) Until a dedicated version mode exists, ensure the temp directory is cleaned up in the `finally` block.
- **Verification:** After version detection, confirm that `$env:TEMP\plenumnet-version-probe` does not exist. Confirm that the version extracted matches the actual daemon version.
- **Crypto Status:** N/A — version detection is not a cryptographic operation, but the orphaned key material is a security hygiene concern.

### Finding 8
- **Finding ID:** R1-A3-8
- **Section:** Topology — Node Addressing (lines 13-20, 39-44, 361-410)
- **Severity:** MINOR
- **Finding:** The deployer correctly uses Rep C node IDs {1, 2, 3} for the three Array3 nodes, consistent with INVARIANT 3 (Rep C zero-exclusion). The gateway port formula `gateway = BASE_PORT + ((CUBE_NODE_ID - 1) * 27) + 13` (line 20) is correctly computed for all three nodes: Node 1 = 11124, Node 2 = 11151, Node 3 = 11178. The 27-slot range per node corresponds to 3^3, and the gateway offset of 13 places it at the center slot [2,2,2] as documented. However, the node IDs used in the deployer (1, 2, 3) are scalar integers, not full 54-trit Rep C TDNS addresses. The full Rep C addresses are only assigned later by the CRS coordinator during registration (lines 940-971). This is acceptable for local deployment but should be documented clearly: the integer IDs are deployment-time ordinals, not TDNS identity addresses.
- **Recommendation:** Add a comment in the deployer header clarifying that `CUBE_NODE_ID` values {1, 2, 3} are local ordinals within the Array3 cluster, not 54-trit Rep C TDNS addresses. The actual Rep C address is assigned by the CRS coordinator at registration time.
- **Verification:** Confirm that no cryptographic operation in the deployer uses `CUBE_NODE_ID` as an identity binding. Confirm that all crypto-relevant identity references use the CRS-assigned Rep C address.
- **Crypto Status:** VERIFIED — Rep C {1,2,3} ordinals are correctly used as deployment ordinals, not as cryptographic identity.

### Finding 9
- **Finding ID:** R1-A3-9
- **Section:** Watchdog — LLM Engine Config (lines 872-888)
- **Severity:** MINOR
- **Finding:** The LLM engine configuration is written to `C:\ProgramData\PlenumNET\llm-engines.json` (line 888). Each engine entry includes a `restart_command` field (line 882) that contains the full path to `llama-server` and the model file path. The watchdog executes this command via `cmd.exe /c` (line 749 in the heredoc). Two concerns: (1) The `restart_command` is stored in plain JSON and could be tampered with to execute arbitrary commands — this is a privilege escalation vector since the watchdog runs as SYSTEM (line 909). (2) The LLM port is computed as `gateway + 1` (line 873), which places LLM engines at ports 11125, 11152, 11179 — these fall within the 27-slot port range of each node but are not the gateway or terminal port. This is architecturally sound but undocumented in the header comment. Cross-reference: Security Engineer (Agent 1) for SYSTEM-privilege command injection assessment.
- **Recommendation:** (1) Restrict ACLs on `C:\ProgramData\PlenumNET\llm-engines.json` to SYSTEM and Administrators only. (2) The watchdog should validate that `restart_command` points to an expected executable path (whitelist `llama-server` variants) rather than executing arbitrary commands. (3) Document the LLM port allocation formula in the header comment alongside the gateway and terminal port formulas.
- **Verification:** Modify `llm-engines.json` to include `"restart_command": "calc.exe"` and verify whether the watchdog executes it. If it does, the privilege escalation vector is confirmed.
- **Crypto Status:** N/A — LLM watchdog configuration is not a cryptographic operation.

### Finding 10
- **Finding ID:** R1-A3-10
- **Section:** Service Wrapper Environment Variables (lines 454-514)
- **Severity:** MINOR
- **Finding:** The service wrapper `.bat` files set environment variables including `CUBE_IDENTITY_DIR`, `CUBE_MODE`, `RELAY_URL`, `CUBE_ARRAY3_PEERS`, `CUBE_ENDPOINT`, `CUBE_API_PORT`, and `CUBE_TERMINAL_PORT`. These are written to plain-text `.bat` files in `C:\PlenumNET\services\wrappers\`. The `RELAY_URL` value points to `https://plenumnet.replit.app` (line 464/495), which is the correct WebSocket relay endpoint. The peer list uses `127.0.0.1:terminal_port` format (line 449), which is appropriate for a local Array3 cluster. However, the `.bat` files are world-readable by default, and the `CUBE_IDENTITY_DIR` path reveals the location of private key material. This is a minor information disclosure.
- **Recommendation:** After creating the wrapper `.bat` files, restrict their ACLs to SYSTEM and Administrators only, consistent with the service registration that runs them under the current user's account (line 98).
- **Verification:** Check ACLs on `C:\PlenumNET\services\wrappers\array3-node-*-start.bat` from a non-admin user session. If readable, the finding is confirmed.
- **Crypto Status:** N/A — environment variable configuration is operational, not cryptographic.

### Finding 11
- **Finding ID:** R1-A3-11
- **Section:** Cross-Document Consistency — TM-2026-016 and plenumnet-repo-guide
- **Severity:** IMPORTANT
- **Finding:** The deployer names the key algorithm "PT26-DSA" in the public key extraction regex (line 392: `PT26-DSA Public Key`). The plenumnet-repo-guide and TM-2026-016 use both "TL-DSA" and "PT26-DSA" — TL-DSA is the algorithm family name, and PT26-DSA appears to be a specific parameter set or alias. The deployer should be consistent with the canonical naming. Additionally, the deployer references no key rotation mechanism. Per plenumnet-repo-guide Section 6.5, key rotation uses a 14-day period (`ARC_EPOCH_SECS` / `RADIAN_DEG` = 1,209,600 seconds). The deployer generates keys once and never rotates them. If the daemon handles rotation internally, this is acceptable — but it should be documented. If the daemon does NOT handle rotation, the deployer creates a long-lived key with no expiry, which contradicts the key lifecycle boundaries described in the repo guide.
- **Recommendation:** (1) Standardize on "TL-DSA" as the algorithm family name in all deployer output and comments; use "PT26-DSA-87" only when referring to the specific security level. (2) Document whether the daemon handles key rotation internally or whether an external rotation mechanism is needed. (3) If key rotation is daemon-managed, add a comment in the deployer noting that key rotation is delegated to the runtime.
- **Verification:** Grep the daemon source for key rotation logic (e.g., `ARC_EPOCH_SECS`, `key_rotation`). If absent, file a follow-up finding for the daemon review.
- **Crypto Status:** UNVERIFIED — cannot confirm key rotation lifecycle without daemon source review (out of scope for this review).

---

## Summary Verdict

**Verdict: FAIL**

The deployer script contains two CRITICAL findings that block implementation:

1. **R1-A3-1 (CRITICAL):** CRS registration sends node identity (public key + endpoint) without any TL-DSA signature, allowing unauthenticated identity registration. This violates INVARIANT 7.

2. **R1-A3-2 (CRITICAL):** The deployment payload to the remote Node Registry uses hostname and IP address as node identifiers rather than Rep C addresses, violating INVARIANT 9. The payload is also unsigned, allowing spoofed deployment reports.

Additionally, four IMPORTANT findings require resolution before release: no TIS-27 binary integrity check (R1-A3-3), unprotected key material at rest without passphrase (R1-A3-4), identity migration without integrity verification (R1-A3-5), fragile public key extraction via stdout parsing (R1-A3-6), and undocumented key rotation lifecycle (R1-A3-11).

The deployer correctly implements the Array3 topology (27-slot cube, Rep C {1,2,3} ordinals, gateway port formula), the watchdog heredoc is architecturally sound (service monitoring, orphan killing, LLM health checks with grace periods), and the Windows Service registration with exponential backoff restart is well-designed. The fundamental issue is that the deployer performs identity-critical operations (registration, deployment reporting) without the cryptographic guarantees (TL-DSA signatures, Rep C addressing, TIS-27 integrity) required by the PlenumNET invariant system.

The CRITICAL findings must be resolved and re-reviewed before this spec proceeds to QC-R2.

---

*Capomastro Holdings Ltd. — Applied Physics Division*
*Sherwood Park, Alberta, Canada*
