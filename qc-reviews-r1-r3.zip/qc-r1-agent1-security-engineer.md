# QC-R1 Agent 1: Security Engineer Review

**Spec Under Review:** `services/inter-cube/deploy-yoda.ps1` (1140 lines, revision v0.5.0)
**Review Scope:** Array3 Deployer + Embedded Watchdog (heredoc lines 571-828)
**Reviewer:** Security Engineer (Agent 1)
**Date:** 2026-03-28
**Template Version:** QC-R1 v1.1.2

---

### Finding 1
- **Finding ID:** R1-A1-1
- **Section:** Lines 749, 807 — Watchdog LLM restart_command injection
- **Severity:** CRITICAL
- **Finding:** The watchdog executes LLM engine restart commands via `Start-Process -FilePath "cmd.exe" -ArgumentList "/c $($engine.restart_command)"` where `restart_command` is read from a JSON file (`C:\ProgramData\PlenumNET\llm-engines.json`) without any validation or sanitization. The watchdog runs as SYSTEM via Scheduled Task (line 909). Any user or process that can write to `llm-engines.json` can inject arbitrary commands that execute as SYSTEM. The JSON file is written to `C:\ProgramData\PlenumNET\` which by default grants write access to all Authenticated Users on Windows. This is a direct privilege escalation vector: a low-privilege user writes a malicious `restart_command` into the JSON, the watchdog executes it as SYSTEM within 2 minutes.
- **Recommendation:** (1) After creating `C:\ProgramData\PlenumNET\`, set an explicit NTFS ACL restricting write access to SYSTEM and Administrators only. (2) Validate `restart_command` against an allowlist of known executable paths (e.g., must start with a path to `llama-server.exe`). (3) Never pass untrusted strings to `cmd.exe /c` — use `Start-Process` with `-FilePath` pointing to the validated executable and `-ArgumentList` as a proper array, avoiding shell interpretation entirely.
- **Verification:** Attempt to write a `restart_command` containing `& calc.exe` as a non-admin user. Confirm the watchdog rejects or does not execute it.

### Finding 2
- **Finding ID:** R1-A1-2
- **Section:** Lines 872-883 — LLM restart_command path construction
- **Severity:** CRITICAL
- **Finding:** At line 875, the restart command is constructed via string interpolation: `"\"$llamaServerPath\" --model \"$defaultModelPath\" --port $llmPort --host 127.0.0.1"`. If `$llamaServerPath` or `$defaultModelPath` contain characters that break `cmd.exe /c` parsing (e.g., `%`, `^`, `!`, `&`, parentheses), the command will either fail or be exploited for injection. The `$llamaServerPath` is discovered via filesystem search across multiple directories (lines 853-866), some of which are user-writable (e.g., `$env:LOCALAPPDATA`). A malicious user could plant a fake `llama-server.exe` in `$env:LOCALAPPDATA\llama.cpp\` with a path containing injection characters, or simply replace the binary with malware. Since this path is persisted into the JSON config and later executed as SYSTEM by the watchdog, this is a second privilege escalation vector.
- **Recommendation:** (1) Pin the llama-server path to an admin-only directory (e.g., `C:\PlenumNET\bin\`) and reject paths from user-writable locations when the watchdog will run as SYSTEM. (2) Verify the binary's Authenticode signature or TIS-27 hash before persisting the path. (3) Use array-based argument passing in `Start-Process` rather than `cmd.exe /c` string concatenation.
- **Verification:** Place a binary named `llama-server.exe` in `%LOCALAPPDATA%\llama.cpp\` as a standard user. Run the deployer as admin. Confirm the user-planted binary is NOT selected or is rejected.

### Finding 3
- **Finding ID:** R1-A1-3
- **Section:** Lines 455-514 — Wrapper .bat files expose environment variables in cleartext
- **Severity:** IMPORTANT
- **Finding:** The wrapper .bat files (e.g., `array3-node-1-start.bat`) set environment variables including `CUBE_IDENTITY_DIR`, `CUBE_ENDPOINT`, `RELAY_URL`, and `CUBE_CRS_URL` in plaintext. While `CUBE_IDENTITY_PASSPHRASE` is not currently set in these wrappers (the daemon reads the key file directly), the pattern establishes a precedent where any future passphrase-based authentication added to the daemon would naturally be added as a `set` line in these .bat files. The .bat files are stored in `C:\PlenumNET\services\wrappers\` — while this is an admin-created directory, the files are ASCII-encoded and readable by any authenticated user. The `CUBE_IDENTITY_DIR` path (e.g., `C:\PlenumNET\plenumnet-data\identity-1`) is exposed, revealing the exact location of cryptographic key material on disk.
- **Recommendation:** (1) Add a comment in the wrapper template explicitly prohibiting passphrase environment variables. (2) Set restrictive ACLs on the wrappers directory (`SYSTEM` and `Administrators` only). (3) Consider using a credential store (DPAPI-protected file or Windows Credential Manager) for any future passphrase delivery rather than environment variables. (4) Document that `CUBE_IDENTITY_DIR` paths in .bat files are intentional but that ACLs must restrict read access.
- **Verification:** Run `icacls C:\PlenumNET\services\wrappers\` and confirm only SYSTEM and Administrators have read access. Confirm no `CUBE_IDENTITY_PASSPHRASE` or similar secret appears in any .bat file.

### Finding 4
- **Finding ID:** R1-A1-4
- **Section:** Lines 905-936 — Watchdog runs as SYSTEM with Highest RunLevel
- **Severity:** IMPORTANT
- **Finding:** The watchdog scheduled task is registered with `-UserId "SYSTEM" -RunLevel Highest` (line 909). This grants the watchdog script — and anything it executes — full SYSTEM privileges. Combined with R1-A1-1 (the `restart_command` injection), this creates a privilege escalation chain. Even without the injection vector, the watchdog as SYSTEM can: (a) read/write any file on the system, (b) access all user credential stores, (c) generate crash dumps containing sensitive memory from any process. The watchdog's actual operations (service restart, process killing, health checks) require elevated privileges but not necessarily SYSTEM. Running as a dedicated service account with "Log on as a batch job" and minimal privileges would reduce the blast radius.
- **Recommendation:** (1) Create a dedicated `PlenumNET-Watchdog` service account with only the privileges needed: ability to start/stop PlenumNET services, kill orphan processes by name, read LLM config, write to log directory. (2) If SYSTEM is retained, harden the LLM config path per R1-A1-1 and document the threat model boundary explicitly. (3) Configure Windows Error Reporting to exclude PlenumNET processes from automatic crash dump generation (or restrict dump directory ACLs).
- **Verification:** Verify the scheduled task principal. If SYSTEM, confirm all writable paths (JSON config, log directory, watchdog script itself) are ACL-restricted to SYSTEM/Administrators only.

### Finding 5
- **Finding ID:** R1-A1-5
- **Section:** Lines 1024-1107 — Desktop launcher .bat files writable by any user
- **Severity:** IMPORTANT
- **Finding:** The deployer writes `Start PlenumNET Array3.bat` and `Stop PlenumNET Array3.bat` to the current user's Desktop folder (lines 1024, 1086). Desktop folders are writable by the owning user and potentially other users in shared-desktop configurations. The Start launcher requests admin elevation via `net session` check and then runs `net start` for the PlenumNET services. If an attacker modifies the .bat file to prepend malicious commands before the admin check, the next time an administrator double-clicks the launcher, those commands execute with admin privileges. This is a classic writable-launcher privilege escalation. The Stop launcher has the same issue.
- **Recommendation:** (1) After writing the .bat files, set their ACL to read-only for the owning user and Full Control only for Administrators. (2) Alternatively, install the launchers to a protected location (e.g., Start Menu under `C:\ProgramData\Microsoft\Windows\Start Menu\`) with admin-only write ACLs. (3) Sign the .bat files or embed a self-integrity check (TIS-27 hash of own content) that validates before executing privileged commands.
- **Verification:** As a standard user, attempt to modify `Start PlenumNET Array3.bat` on the Desktop. Confirm the modification is blocked by ACLs or that the integrity check detects tampering.

### Finding 6
- **Finding ID:** R1-A1-6
- **Section:** Lines 997-1013 — Deployment payload leaks operational details to remote server
- **Severity:** IMPORTANT
- **Finding:** The deployment summary posted to the remote CRS at `$REMOTE_CRS/api/salvi/inter-cube/relay/deployment` includes: hostname (`$env:COMPUTERNAME`), local IP address, CPU architecture, filesystem paths (`binaryPath`, `logDir`, `identityBase` — all containing `C:\PlenumNET\...`), binary size, all node gateway/terminal ports, public keys, identity directory paths, and the local CRS URL. This data is sent over HTTPS (the URL uses `https://plenumnet.replit.app`), but the remote server stores and exposes this data at `/api/salvi/inter-cube/relay/deployments`. An ?? attacker who gains read access to the remote CRS dashboard can enumerate all deployed nodes, their exact filesystem layouts, port assignments, and network topology. The `identityDir` field (line 991) reveals the exact path to cryptographic key material.
- **Recommendation:** (1) Remove `binaryPath`, `logDir`, `identityBase`, and `identityDir` from the deployment payload — these are internal filesystem details with no monitoring value. (2) Hash or anonymize the hostname (e.g., TIS-27 hash of hostname + a deployment salt). (3) Ensure the remote `/deployments` endpoint requires authentication. (4) Document the OPSEC trade-off: the monitoring dashboard needs port/address info, but filesystem paths provide no operational value and only aid attackers.
- **Verification:** Inspect the JSON payload at the `/deployments` endpoint. Confirm no filesystem paths or raw hostnames are present. Confirm the endpoint requires authentication.

### Finding 7
- **Finding ID:** R1-A1-7
- **Section:** Lines 63-93 — secedit policy injection risk in Grant-LogonAsService
- **Severity:** IMPORTANT
- **Finding:** The `Grant-LogonAsService` function exports the local security policy, performs a regex-based string replacement to add a SID to `SeServiceLogonRight`, and re-imports the policy via `secedit /configure`. The `$AccountName` parameter is passed directly to `NTAccount.Translate()` to obtain the SID, so the SID itself is safe. However, the regex replacement at line 80 (`$content -replace "(?m)^(SeServiceLogonRight\s*=\s*.*)$", "`$1,*$sid"`) operates on the full exported policy content. If the exported policy file contains unexpected content (e.g., malicious entries injected by another process modifying the temp directory), the regex could produce a malformed policy that grants unintended privileges. The temp directory (`$env:TEMP\plenumnet-secedit`) is user-writable — a race condition exists where an attacker could replace the exported `.inf` file between the `secedit /export` (line 71) and the `Get-Content` (line 73).
- **Recommendation:** (1) Use a temp directory under a SYSTEM-only path (e.g., `C:\PlenumNET\temp\`) instead of `$env:TEMP`. (2) Validate the exported `.inf` file structure before modification (check for expected sections, reject unexpected content). (3) Set restrictive ACLs on the temp directory immediately after creation.
- **Verification:** Monitor the temp directory during deployer execution. Confirm the `.inf` files are only accessible by the current admin user and are cleaned up in the `finally` block.

### Finding 8
- **Finding ID:** R1-A1-8
- **Section:** Lines 347-358 — Identity migration copies master.key without ACL preservation
- **Severity:** IMPORTANT
- **Finding:** The identity migration from `$env:USERPROFILE\.plenumnet\identity-N` to `C:\PlenumNET\plenumnet-data\identity-N` uses `Copy-Item -Recurse -Force` (line 354). This copies file content but inherits ACLs from the destination parent directory. If the destination directory (`C:\PlenumNET\plenumnet-data\`) has permissive inherited ACLs (which it will by default under `C:\PlenumNET`), the `master.key` files become readable by Authenticated Users. The `master.key` contains the PT26-DSA private key material — exposure of this file compromises the node's cryptographic identity.
- **Recommendation:** (1) After creating each `identity-N` directory, explicitly set ACLs to `SYSTEM:FullControl`, `Administrators:FullControl`, and remove all inherited permissions. (2) After the `Copy-Item`, verify the ACL on `master.key` and remediate if permissive. (3) Use `icacls` or `Set-Acl` to enforce: `icacls "$dir\master.key" /inheritance:r /grant:r "SYSTEM:(R)" "ADMINISTRATORS:(R)"`.
- **Verification:** After deployment, run `icacls C:\PlenumNET\plenumnet-data\identity-1\master.key` and confirm only SYSTEM and Administrators have access. Confirm `Users` and `Authenticated Users` are not listed.

### Finding 9
- **Finding ID:** R1-A1-9
- **Section:** Lines 571-594 — Watchdog log file permissions mismatch
- **Severity:** IMPORTANT
- **Finding:** The watchdog writes its log to `$env:USERPROFILE\.plenumnet\logs\watchdog.log` (line 574). However, the watchdog runs as SYSTEM (line 909). When running as SYSTEM, `$env:USERPROFILE` resolves to `C:\Windows\system32\config\systemprofile` — not the deploying user's profile. This means: (a) the log file is created in a SYSTEM-owned directory that standard users cannot read, making debugging impossible without admin access; (b) if the deployer user expects the log at `%USERPROFILE%\.plenumnet\logs\watchdog.log`, they will find nothing there; (c) the log path announced at line 918 (`$env:USERPROFILE\.plenumnet\logs\watchdog.log`) is the deployer's profile path, not the SYSTEM profile path — the announced path and actual path differ.
- **Recommendation:** (1) Change the watchdog log path to a fixed, well-known location such as `C:\PlenumNET\plenumnet-data\logs\watchdog.log` (matching `$LOG_DIR`). (2) Set ACLs on the log directory to allow SYSTEM write and Administrators read. (3) Update the display message at line 918 to reflect the actual log path.
- **Verification:** After deployment, check for the watchdog log at the SYSTEM profile path and at the announced path. Confirm the log exists at a predictable, documented location accessible to administrators.

### Finding 10
- **Finding ID:** R1-A1-10
- **Section:** Line 528 — Service binary path uses cmd.exe wrapper shim
- **Severity:** IMPORTANT
- **Finding:** The Windows service binary path is set to `cmd.exe /s /c " "$wrapperBat" "` (line 528). This creates a chain: SCM starts `cmd.exe`, which starts the .bat wrapper, which starts the daemon binary. The .bat file path (`$wrapperBat = C:\PlenumNET\services\wrappers\array3-node-N-start.bat`) is embedded in the service registration. If an attacker can modify the .bat file between service registration and service start (or during a reboot), they achieve code execution as the service account. The .bat file's parent directory ACLs depend on `C:\PlenumNET` defaults, which are permissive. Additionally, the `cmd.exe` shim means the service cannot be properly controlled by SCM (no service control handler), which is why the .bat wrapper includes its own restart loop — but this also means SCM's `Stop-Service` kills `cmd.exe` but the daemon child process may orphan (which the watchdog then cleans up, creating a circular dependency).
- **Recommendation:** (1) Set restrictive ACLs on `C:\PlenumNET\services\wrappers\` immediately after creation: `SYSTEM:FullControl`, `Administrators:FullControl`, no inherited permissions. (2) Verify the .bat file's TIS-27 hash before each service start, or better, register the daemon binary directly as the service with `srvany.exe` or a proper Windows service wrapper that implements the SCM control handler. (3) Document the orphan-process circular dependency between the .bat wrapper restart loop and the watchdog's orphan killer.
- **Verification:** Run `icacls C:\PlenumNET\services\wrappers\` and confirm only SYSTEM and Administrators have write access. Attempt to modify a wrapper .bat as a standard user and confirm it is denied.

### Finding 11
- **Finding ID:** R1-A1-11
- **Section:** Lines 597-708 — Orphan process killing false-positive risk
- **Severity:** MINOR
- **Finding:** The BFS tree walk for identifying legitimate daemon processes (lines 597-708) builds a process tree from `Win32_Process` and marks any `inter-cube-daemon.exe` process not in a service descendant tree as an orphan for killing, unless it is listening on a known daemon port. The port check (lines 684-695) uses `Get-NetTCPConnection` and checks if the listening port is in `$daemonPorts`. However, `$daemonPorts` is constructed from the deployer's `$daemonConfigs` array at line 676, which is baked into the watchdog script at generation time. If the daemon configuration changes (e.g., port reassignment) without regenerating the watchdog script, legitimate daemons on new ports will be killed as orphans. Additionally, the process tree walk uses `ParentProcessId` which can be reused by the OS after a process exits — in high-PID-churn environments, this could theoretically cause a false association, though this is a low-probability edge case.
- **Recommendation:** (1) Read daemon port assignments from the service registry or a config file at watchdog runtime rather than baking them into the script at generation time. (2) Add a safety check: before killing an orphan, verify it has been running for more than N seconds (e.g., 30s) to avoid killing a daemon that is mid-startup but hasn't registered with a service yet. (3) Log the full process command line of orphans before killing to aid post-incident forensics.
- **Verification:** Change a daemon's port assignment without regenerating the watchdog. Confirm the watchdog does not kill the reconfigured daemon.

### Finding 12
- **Finding ID:** R1-A1-12
- **Section:** Lines 300-309 — Version probe leaks keygen side effects
- **Severity:** MINOR
- **Finding:** The version check at lines 300-309 sets `CUBE_MODE=keygen` and `CUBE_IDENTITY_DIR` to a temp directory, then runs the binary to extract version information. If the binary's keygen mode generates key material as a side effect (which it does — line 374 confirms this), the version probe creates an unwanted identity directory at `$env:TEMP\plenumnet-version-probe\` containing a `master.key` file. This temp directory is not cleaned up (only the env vars are removed). The key material persists in the temp directory until the user or system cleanup removes it. On multi-user systems, the temp directory may be readable by other users depending on `$env:TEMP` configuration.
- **Recommendation:** (1) Clean up the temp identity directory after the version probe: `Remove-Item (Join-Path $env:TEMP "plenumnet-version-probe") -Recurse -Force -ErrorAction SilentlyContinue`. (2) Alternatively, use a `--version` flag on the daemon binary that does not trigger keygen.
- **Verification:** After running the deployer, check `$env:TEMP\plenumnet-version-probe\` and confirm it does not exist or does not contain key material.

### Finding 13
- **Finding ID:** R1-A1-13
- **Section:** Lines 956 — CRS registration over plaintext HTTP
- **Severity:** MINOR
- **Finding:** Worker nodes register with the local coordinator via `Invoke-RestMethod -Uri "$LOCAL_CRS_URL/api/salvi/inter-cube/crs/register"` where `$LOCAL_CRS_URL = "http://localhost:11124"` (line 45). The registration payload includes the node's public key (line 956). While this is localhost-only traffic and the public key is not secret, using plaintext HTTP for CRS registration means any local process can observe the registration via localhost traffic sniffing. On shared systems, this could allow a malicious process to learn node public keys and endpoints before they are published. The risk is low since public keys are by definition public, but the registration endpoint itself accepts unauthenticated POST requests — a local attacker could register rogue nodes.
- **Recommendation:** (1) Add authentication to the local CRS registration endpoint (e.g., a shared secret derived from the coordinator's identity). (2) Consider mTLS for local inter-node communication if the threat model includes malicious local processes.
- **Verification:** Attempt to POST a rogue registration to `http://localhost:11124/api/salvi/inter-cube/crs/register` with a fabricated public key. Confirm it is rejected or document the accepted threat model.

---

## Cryptographic Status Summary

| Claim | Status |
|-------|--------|
| PT26-DSA key generation via `CUBE_MODE=keygen` | UNVERIFIED (daemon binary behavior not in scope) |
| Identity key material (`master.key`) confidentiality | INCORRECT — ACLs not enforced after migration (R1-A1-8) |
| Deployment payload integrity (HTTPS to remote CRS) | VERIFIED — uses HTTPS URL |
| Local CRS registration security | UNVERIFIED — plaintext HTTP, no authentication (R1-A1-13) |

## `passphrase_entropy_minimum_bits`

Not applicable to this script — `deploy-yoda.ps1` does not implement passphrase-based authentication or key derivation. If `CUBE_IDENTITY_PASSPHRASE` support is added in the future, a minimum of **128 bits** of entropy should be required (equivalent to a 20-character random alphanumeric passphrase), enforced at input time with rejection of low-entropy passphrases.

---

## Summary Verdict

**FAIL** — Two CRITICAL findings (R1-A1-1, R1-A1-2) block implementation.

The Array3 watchdog runs as SYSTEM and executes commands from a JSON configuration file (`llm-engines.json`) stored in a directory writable by Authenticated Users. This is a direct local privilege escalation: any standard user can inject arbitrary commands that the watchdog will execute as SYSTEM within 2 minutes. The LLM server path discovery searches user-writable directories, creating a second privilege escalation vector where a planted binary is persisted into the SYSTEM-executed config. These two findings must be resolved before the deployer can be considered safe for production use. Additionally, six IMPORTANT findings address missing ACLs on key material, desktop launchers, wrapper scripts, log path mismatches, secedit race conditions, and deployment payload OPSEC — all of which should be resolved before first release.

---

*Capomastro Holdings Ltd. — Applied Physics Division*
*QC-R1 Agent 1: Security Engineer*
