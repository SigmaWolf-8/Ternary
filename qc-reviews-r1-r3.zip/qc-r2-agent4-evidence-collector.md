# QC-R2 Evidence Collector / QA Lead Review: Array3 Deployer & Watchdog

**Spec Under Review:** `services/inter-cube/deploy-yoda.ps1` (1542 lines, rev deploy-yoda/v0.5.0, REWRITTEN)  
**Also Reviewed:** `services/inter-cube/uninstall-yoda.ps1` (214 lines, NEW)  
**QC-R1 Reference:** `.local/qc-r1-watchdog/qc-r1-consolidated.md` (29 findings, ALL RESOLVED)  
**Review Date:** 2026-03-28  
**Reviewer:** Agent 4 -- Evidence Collector / QA Lead  
**Template Version:** QC-R2 v1.2.0

---

## Part 1: Round 1 Resolution Assessment

### C1: LLM `restart_command` Injection -> SYSTEM Privilege Escalation

**Verdict: AGREE** -- Resolution is adequate.

**Evidence reviewed:**
- `Test-LlmExecutable` (watchdog heredoc lines 870-885): Allowlist of 6 executables (`llama-server.exe`, `llama-server`, `ollama.exe`, `ollama`, `vllm.exe`, `koboldcpp.exe`). User-writable path blocking checks `$env:USERPROFILE`, `$env:APPDATA`, `$env:LOCALAPPDATA`, `$env:TEMP`.
- `Invoke-LlmRestart` (watchdog heredoc lines 888-904): Proper argument array parsing with quote-aware tokenizer. Uses `Start-Process -FilePath $exe -ArgumentList $argsList` instead of `cmd.exe /c`.
- `Restrict-FileAcl` applied to `llm-engines.json` (line 1203) and `Restrict-DirAcl` applied to `C:\ProgramData\PlenumNET` (line 1210).

**Pass criteria met:** Command injection via string interpolation eliminated. Allowlist blocks unknown executables. ACL restricts config file modification to SYSTEM+Admins. One residual concern noted in R2-2 below (SYSTEM context path resolution).

### C2: LLM Server Path Planting -> Privilege Escalation

**Verdict: AGREE** -- Resolution is adequate.

**Evidence reviewed:**
- Search paths (lines 1165-1176) limited to: `C:\llama.cpp\build\bin\Release\`, `C:\llama.cpp\`, and `$RepoDir` (C:\PlenumNET). No user-writable directories in the search set.
- `Test-LlmExecutable` in watchdog additionally validates resolved path against user-writable locations at runtime.

**Pass criteria met:** User-writable directories removed from search. Runtime validation blocks planted binaries. Residual issue noted in R2-2 regarding SYSTEM-context environment variable resolution.

### C3: Unsigned CRS Registration -> Identity Spoofing (INVARIANT 7)

**Verdict: AGREE** -- Resolution is adequate.

**Evidence reviewed:**
- `Get-TlDsaSignature` function (lines 152-172): Sets `CUBE_MODE=sign`, `CUBE_IDENTITY_DIR`, `CUBE_SIGN_PAYLOAD` env vars, invokes daemon binary, parses hex signature from output.
- Registration payload (lines 1283-1292): Includes `timestamp` and `signature` fields. Sign payload format: `"CRS-REGISTER||$publicKey||$endpoint||$timestamp"`.
- Env vars cleaned up in both success and error paths (lines 159-161 and 167-169).

**Pass criteria met:** Registration is now signed. Replay protection via ISO 8601 timestamp. Sign payload canonicalization follows `||`-delimited format.

### C4: Deployment Payload Uses Hostname/IP as Identity (INVARIANT 9)

**Verdict: AGREE** -- Resolution is adequate.

**Evidence reviewed:**
- Payload structure (lines 1343-1365): `addresses` array is top-level primary identifier. `hostname`, `ip`, `binaryPath`, `localCrsUrl`, `architecture`, `binarySizeMB`, `logDir`, `identityBase` moved into `metadata` sub-object.
- Payload signed via `Get-TlDsaSignature` using coordinator identity (lines 1337-1341).
- `deployer` field set to `"deploy-yoda/$DEPLOYER_VERSION"` (line 1353).

**Pass criteria met:** Rep C addresses are primary identifiers. Metadata is secondary. Payload is signed.

### C5: No TIS-27 Binary Integrity Checksum

**Verdict: AGREE** -- Resolution is adequate.

**Evidence reviewed:**
- SHA-256 computed immediately after build (line 502).
- TIS-27 attempted via `CUBE_MODE=hash` (lines 506-520) with SHA-256 fallback (`sha256:$binarySha256`, line 522).
- Pre-start re-verification (lines 527-535): SHA-256 recomputed and compared before service registration. Hard fail on mismatch with exit 1.
- Hash embedded in deployment payload as `binaryHash` (line 1349).

**Pass criteria met:** Integrity chain: build -> hash -> re-verify -> register. Tampering between build and service start is detected and blocked.

### C6: Unpinned Source Clone -> Non-Reproducible Builds

**Verdict: AGREE** -- Resolution is adequate.

**Evidence reviewed:**
- `$RELEASE_TAG = "v0.5.0"` defined at top (line 67).
- Fresh clone: `git clone --branch $RELEASE_TAG --depth 1` (line 416).
- Existing repo: `git fetch origin tag $RELEASE_TAG --force` + `git checkout $RELEASE_TAG` (lines 435-436).
- Deployment payload includes `releaseTag` (line 1350).

**Pass criteria met:** Build is pinned to tagged release. Source provenance is recorded in deployment payload.

### C7: Watchdog Log Path Mismatch (SYSTEM vs. User Profile)

**Verdict: AGREE** -- Resolution is adequate.

**Evidence reviewed:**
- Watchdog heredoc uses hardcoded `$logDir = '$LOG_DIR'` which resolves to `C:\PlenumNET\plenumnet-data\logs` at generation time (line 841).
- Completion summary shows correct path: `$LOG_DIR\watchdog.log` (line 1517).
- Watchdog task description mentions log location (line 1235).

**Pass criteria met:** No more `$env:USERPROFILE` dependency. Log path consistent between deployer output and watchdog runtime under SYSTEM context.

---

## Part 2: New Findings (QC-R2)

### Finding R2-1

| Field | Value |
|-------|-------|
| **Section** | `Restrict-DirAcl` call (line 1210) |
| **Severity** | MINOR |
| **Finding** | `Restrict-DirAcl` is called with `-FilePath $llmEnginesDir` but the function signature (line 190) declares parameter `[string]$DirPath`. This is a parameter name mismatch. PowerShell accepts positional binding so it works today, but it is a code smell and could break if the function later gains `[CmdletBinding()]` with strict parameter sets or additional parameters. |
| **Recommendation** | Change line 1210 from `Restrict-DirAcl -FilePath $llmEnginesDir` to `Restrict-DirAcl -DirPath $llmEnginesDir`. |
| **Verification** | Grep for all calls to `Restrict-DirAcl` and confirm parameter name matches function signature (`$DirPath`). |

### Finding R2-2

| Field | Value |
|-------|-------|
| **Section** | Watchdog `Test-LlmExecutable` (heredoc lines 870-885) |
| **Severity** | IMPORTANT |
| **Finding** | The user-writable path blocking check runs inside the SYSTEM context. When the watchdog executes as SYSTEM, `$env:USERPROFILE` resolves to `C:\Windows\system32\config\systemprofile`, `$env:APPDATA` to the SYSTEM appdata, etc. These are NOT the interactive user's directories that the check intends to block. A local user could plant a malicious binary at `C:\Users\<username>\AppData\Local\llama-server.exe`, set `restart_command` in the ACL-restricted JSON to that path (this requires the ACL restriction on the file to be bypassed or the file to be modified before ACL is applied), and the SYSTEM-context check would not match because SYSTEM's `$env:LOCALAPPDATA` points to a different path. The ACL on `llm-engines.json` mitigates this significantly (non-admins cannot modify the config), but if an admin user is compromised, this check provides no additional defense. |
| **Recommendation** | Hardcode the blocked path prefixes as: `@('C:\Users', "$env:PUBLIC")` instead of relying on SYSTEM-resolved environment variables. Alternatively, resolve all `C:\Users\*` profiles and check against each. |
| **Verification** | 1. Create a test binary at `C:\Users\testuser\AppData\Local\llama-server.exe`. 2. Manually set `restart_command` in `llm-engines.json` to that path (requires admin). 3. Trigger watchdog. 4. Verify the command is BLOCKED. Currently under SYSTEM context, the path check would NOT match SYSTEM's env vars but the path IS under `C:\Users` -- a hardcoded prefix check would catch it. |

### Finding R2-3

| Field | Value |
|-------|-------|
| **Section** | Watchdog LLM counter persistence (heredoc line 1132) |
| **Severity** | MINOR |
| **Finding** | The LLM health counter file (`llm-health-counters.json`) is written inside the ACL-restricted `C:\ProgramData\PlenumNET` directory, but the file itself is not explicitly ACL-restricted after creation. The directory ACL (set by `Restrict-DirAcl` at line 1210) should propagate `ContainerInherit,ObjectInherit` to new files, which is correct. However, the deployer explicitly removes stale counters (line 1216) and the watchdog creates a fresh file -- the new file inherits directory ACLs only if the directory was ACL-restricted BEFORE the watchdog first runs. During fresh deployment, the sequence is: (1) write `llm-engines.json` -> (2) ACL-restrict file -> (3) ACL-restrict directory -> (4) watchdog creates counter file. This is correct. But if the watchdog runs before step 3 completes (race on fresh install), the counter file may inherit default ACLs. |
| **Recommendation** | Apply `Restrict-FileAcl` to `$llmCounterPath` explicitly in the watchdog heredoc after writing, mirroring the pattern used for `llm-engines.json`. |
| **Verification** | Deploy fresh. Wait for first watchdog cycle. Check ACL of `C:\ProgramData\PlenumNET\llm-health-counters.json`. Verify only SYSTEM and Administrators have access. |

### Finding R2-4

| Field | Value |
|-------|-------|
| **Section** | `Get-TlDsaSignature` environment variable cleanup (lines 152-172) |
| **Severity** | MINOR |
| **Finding** | The `CUBE_SIGN_PAYLOAD` environment variable briefly contains identity material (public key + endpoint + timestamp) in the process environment. If the daemon binary crashes during signing and a crash dump is captured, the sign payload is exposed. This is low severity since the payload contains only public-domain information (public key is public, endpoint is the node's advertised address, timestamp is non-secret). No private key material is passed via environment. |
| **Recommendation** | No code change required. Document that `CUBE_SIGN_PAYLOAD` contains only public-domain identity material by design. |
| **Verification** | Review all calls to `Get-TlDsaSignature` -- confirmed: all payloads use public keys and endpoints only (lines 1284, 1337). No private key material in any payload. |

### Finding R2-5

| Field | Value |
|-------|-------|
| **Section** | Uninstaller identity deletion (uninstall-yoda.ps1 lines 146-168) |
| **Severity** | IMPORTANT |
| **Finding** | The uninstaller uses `Remove-Item $identityBase -Recurse -Force` to delete identity data containing `master.key` private keys. Standard `Remove-Item` does not securely wipe file contents -- the data remains recoverable via disk forensics until sectors are overwritten. For a deployment that handles PT26-DSA private keys, this is a gap in the security lifecycle. The double confirmation UX (`yes` then type `DELETE`) is excellent, but the underlying deletion mechanism is not cryptographically secure. On SSDs with TRIM, recovery is less likely but not guaranteed. On HDDs, recovery is trivial with standard forensic tools. |
| **Recommendation** | Before deleting, overwrite each `master.key` file with random bytes (e.g., `[byte[]]$random = New-Object byte[] (Get-Item $keyFile).Length; [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($random); Set-Content -Path $keyFile -Value $random -AsByteStream`), then delete. Add a comment noting this is best-effort on non-SSD storage. |
| **Verification** | 1. Run uninstaller with identity deletion confirmed. 2. Use disk recovery tool to attempt recovery of `master.key` from unallocated sectors. 3. Verify file content is overwritten with random data before deletion. |

### Finding R2-6

| Field | Value |
|-------|-------|
| **Section** | Uninstaller service removal order (uninstall-yoda.ps1 lines 59-73) |
| **Severity** | MINOR |
| **Finding** | Services are removed in reverse order (3, 2, 1), which is correct for graceful teardown (workers before coordinator). However, `sc.exe delete` is called immediately after `Stop-Service` with no sleep between them. On Windows, `sc.exe delete` marks the service for deletion but the SCM may not release the handle immediately if the service is still stopping. This can cause "The specified service has been marked for deletion" errors on rapid re-deploy. The deployer (line 774) already uses `Start-Sleep -Seconds 2` between stop and delete -- the uninstaller should match this pattern. |
| **Recommendation** | Add `Start-Sleep -Seconds 2` between `Stop-Service` and `sc.exe delete` in the uninstaller loop, matching the deployer's existing pattern. |
| **Verification** | Run uninstaller, then immediately run deployer. Verify no "marked for deletion" errors during service re-registration. |

### Finding R2-7

| Field | Value |
|-------|-------|
| **Section** | Upgrade path identity preservation (deploy-yoda.ps1 lines 596-618, 630-646, 648-657) |
| **Severity** | MINOR |
| **Finding** | During upgrade (`$isUpgrade = $true`), the deployer banner claims "Preserve existing node identities" (line 252). This is verified: keygen only runs if `master.key` does not exist (line 630). However, the public key re-extraction (lines 648-657) runs `CUBE_MODE=keygen` even when the key already exists. This relies on the daemon's contract that `CUBE_MODE=keygen` with an existing `master.key` is a read-only operation that outputs the existing public key without modifying the key. If a new daemon version changes this behavior (e.g., regenerates the key), existing identities could be silently destroyed during upgrade. The version probe at lines 544-551 demonstrates awareness of this pattern and cleans up its temp directory. |
| **Recommendation** | Add an explicit contract comment documenting that `CUBE_MODE=keygen` with an existing `master.key` MUST be read-only. Alternatively, use a separate `CUBE_MODE=info` or `CUBE_MODE=pubkey` if the daemon supports it. Add a test: record SHA-256 of `master.key` before and after keygen call, assert equality. |
| **Verification** | 1. Deploy v0.5.0 (fresh). 2. Record SHA-256 of all 3 `master.key` files. 3. Re-run deployer (upgrade). 4. Verify SHA-256 of all 3 `master.key` files unchanged. 5. Verify public keys extracted correctly. |

### Finding R2-8

| Field | Value |
|-------|-------|
| **Section** | Watchdog orphan port array (heredoc line 982) |
| **Severity** | IMPORTANT |
| **Finding** | The `$daemonPorts` array is constructed at heredoc generation time (line 982) via PowerShell string interpolation from `$daemonConfigs`. The resulting watchdog script contains a hardcoded port array literal. If the port configuration changes (e.g., `$BASE_PORT` modified in a future deployer version), the existing watchdog will use stale port values until the deployer is re-run. This is by-design (heredoc is generated once and baked into the watchdog script), but combined with the watchdog being a scheduled task that persists across reboots, a stale watchdog could incorrectly kill legitimate daemons listening on newly assigned ports or fail to detect orphans on old ports. There is no version stamp or config hash in the watchdog script to detect staleness. |
| **Recommendation** | Add a config hash or deployer version marker to the watchdog script header (e.g., `$watchdogConfigHash = 'sha256:...'`). Document that the watchdog MUST be re-deployed whenever port configuration changes. The deployer already re-creates the watchdog on each run (lines 1220-1226 unregister old task), so this is automatically handled on re-deploy. |
| **Verification** | 1. Deploy with default `BASE_PORT=11111`. 2. Inspect watchdog script, confirm port array matches 11124, 11122, 11151, 11149, 11178, 11176. 3. Modify `BASE_PORT` and re-deploy. 4. Verify old watchdog task is replaced and new port array is correct. |

### Finding R2-9

| Field | Value |
|-------|-------|
| **Section** | Deployer try/catch cleanup (lines 274-1539) |
| **Severity** | MINOR |
| **Finding** | The entire deployment (steps 1-10) is wrapped in a single try/catch (line 277 to line 1539). The catch block (lines 1524-1539) cleans up `$partialServices` (stops and deletes registered Windows services) but does not clean up: (a) wrapper `.bat` files in `$wrapperDir`, (b) desktop launchers on the desktop, (c) `llm-engines.json` config, (d) the watchdog scheduled task. A partial deployment that fails at step 9 or 10 leaves orphaned wrappers, launchers, and a potentially misconfigured watchdog. The uninstaller (`uninstall-yoda.ps1`) handles all of these, so the recovery path exists. |
| **Recommendation** | Either extend the catch block cleanup to remove wrapper files, desktop launchers, and the watchdog task, OR add a message in the catch block directing the user to run `uninstall-yoda.ps1` before re-attempting deployment. |
| **Verification** | 1. Inject a forced error at step 10 (e.g., unreachable remote CRS). 2. Verify catch block executes and services are cleaned up. 3. Check what other artifacts remain on disk (wrappers, launchers). 4. Run uninstaller and verify complete cleanup. |

### Finding R2-10

| Field | Value |
|-------|-------|
| **Section** | Uninstaller automation support (uninstall-yoda.ps1) |
| **Severity** | MINOR |
| **Finding** | The deployer supports `-Force` for automated/scripted invocation (line 57). The uninstaller has no equivalent -- it always requires interactive confirmation at multiple steps (lines 47, 134, 155, 157, 176, 191). This prevents automated teardown in CI/CD or orchestration scenarios. Enterprise deployments with fleet management tools cannot invoke the uninstaller non-interactively. |
| **Recommendation** | Add a `-Force` parameter to `uninstall-yoda.ps1` that skips all confirmation prompts except identity deletion (which should require `-RemoveIdentity` or similar explicit flag due to destructive nature). |
| **Verification** | Run `uninstall-yoda.ps1 -Force` and verify services, watchdog, launchers, and wrappers are removed without interactive prompts. Identity data should be preserved unless `-RemoveIdentity` is also specified. |

---

## Part 3: Coverage Matrix

### Test x Component Coverage

| Test Scenario | deploy-yoda.ps1 | Watchdog (heredoc) | uninstall-yoda.ps1 | Testable? |
|---|---|---|---|---|
| **Prerequisites** | | | | |
| Admin elevation (local script) | L212-231 | N/A | L29-36 | YES |
| Admin elevation (irm\|iex) | L219-229 | N/A | N/A | YES |
| Git detection | L284-291 | N/A | N/A | YES |
| Rust install flow | L293-314 | N/A | N/A | YES (requires no-cargo env) |
| LLVM install flow | L370-407 | N/A | N/A | YES (requires no-clang env) |
| **Build and Integrity** | | | | |
| Pinned tag clone | L414-439 | N/A | N/A | YES |
| ZIP-to-git conversion | L424-431 | N/A | N/A | YES |
| Existing repo tag update | L433-437 | N/A | N/A | YES |
| Build with progress heartbeat | L457-499 | N/A | N/A | YES |
| SHA-256 post-build | L502-503 | N/A | N/A | YES |
| TIS-27 hash (with SHA-256 fallback) | L505-524 | N/A | N/A | PARTIAL (depends on daemon hash mode) |
| Pre-start integrity re-verify | L527-535 | N/A | N/A | YES (tamper binary, expect exit 1) |
| **Identity and Keys** | | | | |
| Fresh keygen (3 nodes) | L630-643 | N/A | N/A | YES |
| master.key ACL restriction | L638 | N/A | N/A | YES (check NTFS ACL) |
| Identity migration (old to new) | L596-618 | N/A | N/A | YES |
| Migration integrity check (SHA-256) | L606-614 | N/A | N/A | YES (corrupt source, expect fail) |
| Upgrade preserves keys | L630 (skip if exists) | N/A | N/A | YES (compare hashes pre/post) |
| Public key extraction | L648-657 | N/A | N/A | PARTIAL (regex-dependent) |
| Identity secure deletion | N/A | N/A | L146-168 | NO (not securely wiped, see R2-5) |
| **Service Registration** | | | | |
| Wrapper .bat generation (CRS) | L702-732 | N/A | N/A | YES (parse file, verify env vars) |
| Wrapper .bat generation (worker) | L734-765 | N/A | N/A | YES (parse file, verify env vars) |
| Wrapper .bat ACL restriction | L768 | N/A | N/A | YES (check NTFS ACL) |
| Windows Service creation | L780-796 | N/A | N/A | YES |
| Service failure recovery policy | L788 | N/A | N/A | YES (sc.exe qfailure) |
| Service logon account config | L146-150 | N/A | N/A | YES (check SeServiceLogonRight) |
| secedit temp dir ACL restriction | L109-143 | N/A | N/A | YES (GUID-suffixed, ACL-restricted) |
| Coordinator start + health check | L801-820 | N/A | N/A | YES (15 attempts x 2s) |
| Worker conditional start | L822-832 | N/A | N/A | YES (skipped if CRS not ready) |
| **CRS Registration** | | | | |
| Signed registration payload | L1283-1292 | N/A | N/A | YES |
| Registration retry (5 attempts) | L1281-1310 | N/A | N/A | YES |
| TL-DSA signature generation | L152-172 | N/A | N/A | PARTIAL (depends on daemon sign mode) |
| **Watchdog** | | | | |
| Service health monitoring | N/A | L934-950 | N/A | YES |
| Stopped service restart | N/A | L938-948 | N/A | YES |
| BFS descendant PID walk | N/A | L907-922 | N/A | YES |
| Orphan detection (not in service tree) | N/A | L982-1019 | N/A | YES |
| Orphan startup grace period (30s) | N/A | L1007-1009 | N/A | YES |
| Port-based legitimate daemon detection | N/A | L989-1003 | N/A | YES |
| LLM process health check (TCP listen) | N/A | L1052-1070 | N/A | YES |
| LLM API health check (/v1/models) | N/A | L1074-1077 | N/A | YES |
| LLM grace period (300s / recent restart) | N/A | L1092-1111 | N/A | YES |
| LLM grace_used flag (prevents infinite grace) | N/A | L1104-1111 | N/A | YES |
| LLM stale kill + restart cycle | N/A | L1112-1128 | N/A | YES |
| LLM executable allowlist | N/A | L870-885 | N/A | YES |
| LLM user-writable path block | N/A | L876-883 | N/A | PARTIAL (see R2-2) |
| Log rotation (1MB threshold) | N/A | L850-863 | N/A | YES |
| Non-blocking log size check | N/A | L853-855 | N/A | YES |
| Summary JSON output (integer fields) | N/A | L1140 | N/A | YES |
| **Deployment Payload** | | | | |
| Rep C addresses as primary identifier | L1344 | N/A | N/A | YES (inspect JSON) |
| Metadata sub-object structure | L1355-1364 | N/A | N/A | YES (inspect JSON) |
| Payload TL-DSA signature | L1337-1341 | N/A | N/A | PARTIAL (depends on daemon) |
| HTTPS POST to node registry | L1368 | N/A | N/A | YES |
| Non-fatal registry POST failure | L1371-1374 | N/A | N/A | YES |
| **Desktop Launchers** | | | | |
| Start launcher creation (.cmd) | L1377-1434 | N/A | N/A | YES |
| Stop launcher creation (.cmd) | L1436-1480 | N/A | N/A | YES |
| Launcher ACL restriction | L1432, L1479 | N/A | N/A | YES (check NTFS ACL) |
| Launcher admin check (net session) | L1388-1394 | N/A | N/A | YES |
| Stop launcher confirmation prompt | L1455-1460 | N/A | N/A | YES |
| **Uninstaller** | | | | |
| Admin check | N/A | N/A | L29-36 | YES |
| Service stop + delete (reverse order 3,2,1) | N/A | N/A | L59-73 | YES |
| Watchdog task removal (with schtasks fallback) | N/A | N/A | L78-96 | YES |
| Desktop launcher removal (.cmd and .bat) | N/A | N/A | L101-115 | YES |
| Wrapper script removal | N/A | N/A | L118-127 | YES |
| LLM config removal (optional prompt) | N/A | N/A | L130-142 | YES |
| Identity removal (double confirmation) | N/A | N/A | L146-168 | YES |
| Source/binary removal (optional, shows size) | N/A | N/A | L170-184 | YES |
| Legacy identity cleanup ($HOME/.plenumnet) | N/A | N/A | L186-199 | YES |
| Removed component counter | N/A | N/A | L207 | YES |
| Toolchain preservation note (Rust/LLVM) | N/A | N/A | L209-212 | YES (informational) |
| **Error Handling** | | | | |
| Interruption cleanup (partial services) | L274-1539 | N/A | N/A | YES (partial -- see R2-9) |
| Consent prompt (skip with -Force) | L266-272 | N/A | N/A | YES |
| Per-step consent (Rust/LLVM installs) | L295-301, L371-377 | N/A | N/A | YES |
| Version mismatch warning | L568-571 | N/A | N/A | YES |
| Upgrade detection | L234-238 | N/A | N/A | YES |

### Product x Architecture Coverage

| Product | Windows x64 | Windows ARM64 | Linux | macOS |
|---|---|---|---|---|
| deploy-yoda.ps1 | Full coverage | Documented (vcvarsarm64.bat, line 343) | N/A (Windows-only) | N/A (Windows-only) |
| uninstall-yoda.ps1 | Full coverage | Expected (not explicitly tested) | N/A | N/A |
| Watchdog (heredoc) | Full coverage | Expected (not explicitly tested) | N/A | N/A |

---

## Part 4: Summary Verdict

### PASS WITH CONDITIONS

The rewritten `deploy-yoda.ps1` (1542 lines) and new `uninstall-yoda.ps1` (214 lines) adequately resolve all 29 QC-R1 findings. All 7 CRITICAL resolutions (C1-C7) are verified with evidence in the code. The security posture is substantially improved over the original:

- Command injection eliminated (C1)
- Path planting blocked (C2)
- CRS registration signed (C3)
- Payload restructured around Rep C identities (C4)
- Binary integrity chain complete (C5)
- Source pinned to tagged release (C6)
- Watchdog log path hardcoded (C7)

**Conditions for unconditional PASS (3 IMPORTANT findings):**

1. **R2-2 (IMPORTANT):** Fix the SYSTEM-context path check in `Test-LlmExecutable`. The current implementation uses `$env:USERPROFILE`, `$env:APPDATA`, `$env:LOCALAPPDATA`, `$env:TEMP` which resolve to SYSTEM paths, not interactive user paths. Hardcode `C:\Users` as the blocked prefix to cover all user profiles regardless of execution context.

2. **R2-5 (IMPORTANT):** Implement secure wipe of `master.key` files in the uninstaller before deletion. Current `Remove-Item` leaves private key material recoverable on disk via forensic tools.

3. **R2-8 (IMPORTANT):** Document that watchdog port configuration is static (generated at deploy time) and must be re-deployed when port assignments change. Consider adding a config version marker to the watchdog script for staleness detection.

**Non-blocking items (7 MINOR, fix at convenience):**

- R2-1: Parameter name mismatch on `Restrict-DirAcl` call (`-FilePath` vs `-DirPath`).
- R2-3: LLM health counter file depends on directory ACL inheritance -- consider explicit ACL.
- R2-4: Informational -- sign payload contains only public material (no action needed).
- R2-6: Add `Start-Sleep -Seconds 2` between Stop-Service and sc.exe delete in uninstaller.
- R2-7: Document `CUBE_MODE=keygen` is read-only when `master.key` exists.
- R2-9: Extend catch block cleanup scope or add uninstaller reference in error message.
- R2-10: Add `-Force` parameter to uninstaller for automated teardown support.

**Positive Verifications (no regressions from R1):**

1. All 7 CRITICAL resolutions verified with evidence in code.
2. ACL restriction pattern (`Restrict-FileAcl`, `Restrict-DirAcl`) consistently applied across security-sensitive files: `master.key`, wrapper `.bat` files, desktop launchers, `llm-engines.json`, `C:\ProgramData\PlenumNET` directory.
3. TL-DSA signature chain covers both CRS registration and deployment payloads.
4. Binary integrity chain (build -> hash -> re-verify -> register) is complete and tamper-resistant with explicit exit 1 on mismatch.
5. Upgrade path correctly preserves existing identities with SHA-256 integrity verification on migration.
6. Watchdog architecture (BFS orphan detection, two-tier LLM health, grace periods with `grace_used` flag, log rotation with non-blocking size check) is production-quality.
7. Uninstaller provides graduated teardown with appropriate warnings for destructive operations (double confirmation for identity deletion).
8. Color semantics documented (line 63) and consistently applied throughout deployer output.
9. Gateway port formula `BASE_PORT + ((CUBE_NODE_ID - 1) * 27) + 13` correctly computes 11124, 11151, 11178.
10. Rep C {1,2,3} ordinals correctly used for Array3 node IDs -- zero never used, documented in header.

---

*Capomastro Holdings Ltd. -- Applied Physics Division*  
*QC-R2 Evidence Collector Review -- 2026-03-28*  
*Reviewer: Agent 4 -- Evidence Collector / QA Lead*  
*Sed Quis Est Deus? Qui Commando IO.*
