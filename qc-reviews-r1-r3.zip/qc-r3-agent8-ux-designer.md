# QC-R3 Agent 8: UX Designer Review — `deploy-yoda.ps1`

**YODA Role ID:** `design/ux-designer`  
**Spec Under Review:** `services/inter-cube/deploy-yoda.ps1` (1140 lines, rev deploy-yoda/v0.5.0)  
**QC-R1 Input:** `.local/qc-r1-watchdog/qc-r1-consolidated.md` (7 CRITICAL, 14 IMPORTANT, 8 MINOR)  
**QC-R2 Input:** `.local/qc-r2-watchdog/qc-r2-consolidated.md` (10 CRITICAL, 19 IMPORTANT, 6 MINOR)  
**Review Date:** 2026-03-28  
**Round:** QC-R3  
**Reviewer Provenance:** `design/ux-designer` v1.2.0, schema v1  
**Integrity Note:** UNCOMMITTED — hash verification deferred to post-commit review  
**Sequencing Note:** R1/R2 CRITICALs are NOT yet resolved. Findings against unresolved CRITICAL sections are marked DEFERRED per QC-R3 protocol.

---

## Applicability

This specification describes an operator-driven CLI deployer workflow (8 steps), desktop launchers (Start/Stop .bat files), a watchdog scheduled task, and a CRS registration flow. All seven adapted review scope items apply. Uninstall UX is absent — flagged as a finding.

---

## Findings

### Finding 1
- **Section:** STEP 7/8, lines 417-431
- **Severity:** CRITICAL
- **Round:** R3
- **Finding:** Admin privilege check occurs at Step 7 — after Steps 1-6 have already executed (prerequisite checks, toolchain installs, git clone, cargo build, network detection, identity generation). If the operator runs the script non-elevated, they invest 10-30+ minutes in build time before discovering they lack privileges. When invoked via `irm | iex`, auto-elevation is impossible (line 427), and the operator must re-run the entire script from scratch.
- **Recommendation:** Move admin check to the top of the script, before Step 1. If not admin, display clear instructions and exit immediately. Do not execute any steps that will be wasted.
- **Impact:** Operator wastes significant time (cargo build alone can take 15+ minutes) only to be told they need admin. On re-run, Steps 1-3 repeat unnecessarily. This is a severe first-run frustration point.

### Finding 2
- **Section:** STEP 3/8, lines 271-278
- **Severity:** CRITICAL
- **Round:** R3
- **Finding:** `cargo build --release` produces no progress indication beyond individual `Compiling` lines filtered through regex. A release build of a Rust project typically takes 10-30 minutes. The operator sees sparse, irregularly-timed gray text with no indication of total progress, estimated time remaining, or percentage complete. No spinner, no progress bar, no crate count.
- **Recommendation:** (1) Before build, count total crates with `cargo build --release -p inter-cube --message-format=json 2>&1` dry run or parse Cargo.lock. (2) Display `Compiling [N/total] crate_name...` counter. (3) At minimum, add a periodic heartbeat message every 30 seconds: `Still building... (elapsed: Xm Ys)`. (4) Show a spinner on the current line during compilation gaps.
- **Impact:** Operator cannot distinguish "still building" from "build hung" from "build failed silently". During the longest operation in the entire deploy flow, the operator has zero confidence about progress.

### Finding 3
- **Section:** Lines 9-10, entire script
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** The `irm | iex` invocation pattern provides no pre-flight summary or consent prompt. The operator pastes a URL into PowerShell and the script immediately begins installing toolchains, cloning repositories, and registering Windows services — with no confirmation dialog, no summary of what will be done, and no opportunity to review parameters before execution.
- **Recommendation:** Add a pre-flight summary block after the banner: display planned actions (install Rust if missing, install LLVM if missing, clone to C:\PlenumNET, register 3 Windows services, create scheduled task), disk space estimate, and a `Press Y to continue or N to abort` prompt. Add a `-Force` or `-NoPrompt` parameter to skip for automation.
- **Impact:** Operator has no informed consent before the script modifies their system. Violates the critical rule: "Destructive actions require explicit confirmation proportional to the damage."

### Finding 4
- **Section:** Lines 136-148, 204-233
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** Automatic toolchain installation (Rust ~250MB, LLVM ~500MB) occurs with minimal warning. The Rust install (line 139) shows only `-> Rust not found -- installing rustup...` before downloading and executing an installer. The LLVM install (line 204-233) shows `-> clang not found -- installing LLVM via winget...` before a ~500MB download. No size warning, no consent prompt, no estimated duration, no download progress.
- **Recommendation:** (1) Warn operator about download size before each install. (2) Show download progress (PowerShell `Invoke-WebRequest` supports `-Progress`). (3) Ask for confirmation before each toolchain install. (4) Provide skip option with clear message about what will fail.
- **Impact:** Operator on metered connection or slow network faces unexpected large downloads. No ability to defer or skip.

### Finding 5
- **Section:** Entire script
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** No cancel/abort mechanism exists. Once the script starts, there is no graceful way to stop it. `Ctrl+C` during service registration or identity generation may leave the system in a partially configured state with some services registered, some not, and no cleanup path.
- **Recommendation:** (1) Implement `try/finally` blocks around service registration that clean up on interruption. (2) Document `Ctrl+C` behavior at each step. (3) Add a cleanup function that removes partially registered services.
- **Impact:** An interrupted deploy leaves ghost services, partial identities, and wrapper scripts with no documented recovery procedure.

### Finding 6
- **Section:** Lines 101-116
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** The opening banner displays 10 lines of dense technical information (port ranges, gateway ports, terminal ports, VM API paths, relay URLs) before any action occurs. This information is only meaningful after deployment completes. At step 0, the operator needs to know: what will happen, how long it will take, and what prerequisites are needed — not port numbers.
- **Recommendation:** Replace the pre-deploy banner with: (1) Product name and version. (2) Summary of what the script will do (3 bullet points). (3) Prerequisites list. Move port/endpoint details to the post-deploy summary (which already exists at lines 1110-1137 and does this correctly).
- **Impact:** Information overload at the wrong time. Operator cannot distinguish actionable information from reference data.

### Finding 7
- **Section:** Lines 1023-1108
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** Desktop launchers require admin elevation but provide poor guidance. The Start launcher (line 1036-1041) shows a generic error if not elevated. There is no UAC elevation prompt — the operator must manually right-click and select "Run as administrator." The Stop launcher similarly requires admin but provides no guidance about consequences (e.g., "stopping services will disconnect all relay clients").
- **Recommendation:** (1) Add self-elevation to launchers using `powershell -Command "Start-Process cmd -Verb RunAs -ArgumentList '/c %~f0'"`. (2) Add consequence description to Stop launcher: "This will stop all 3 PlenumNET nodes. Connected applications will lose relay connectivity." (3) Add confirmation prompt to Stop launcher before stopping services.
- **Impact:** Stop launcher is a destructive action (disconnects relay clients) with no confirmation and no consequence warning. Operator on the 50th use accidentally double-clicks Stop.

### Finding 8
- **Section:** Lines 380-381, 539, 560, 920, 968-969
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** Warning messages (`WARN:`) provide no actionable recovery guidance. Examples: "Node #1 keygen may have failed" (line 380) — what should the operator do? "Coordinator health check did not respond -- continuing anyway" (line 560) — is this safe? "Node #2 registration with coordinator failed" (line 969) — will the node work? Every warning leaves the operator uncertain whether to continue, retry, or abort.
- **Recommendation:** Every warning must answer three questions: (1) What happened? (2) Is it safe to continue? (3) What should the operator do if the issue persists? Example: `WARN: Node #1 keygen may have failed. Check C:\PlenumNET\plenumnet-data\identity-1\master.key exists. Re-run deployer to retry.`
- **Impact:** Violates the critical rule: "Error messages must answer: what happened, why, and what to do now."

### Finding 9
- **Section:** Lines 101-116, 128-133, 149, 200-201, 262, 292, 337, 383-384, 537, 558, 566, 842, 889, 916, 947, 966, 1017, 1084, 1108, 1112-1137
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** Status is conveyed exclusively through color coding: Green = success, Yellow = warning, Red = error, Cyan = headers, White = info, DarkGray = secondary. Screen readers do not announce color. Operators using high-contrast terminal themes or piping output to a file lose all status hierarchy. The `[OK]`, `WARN:`, and `ERROR:` text prefixes partially mitigate this, but are inconsistently applied — some success messages have `[OK]` prefix (line 133), others don't (line 262 "Source ready"). Some warnings use `WARN:` (line 560), others use `NOTE:` (line 321), others have no prefix at all (line 961).
- **Recommendation:** (1) Standardize all status prefixes: `[OK]` for success, `[WARN]` for warnings, `[FAIL]` for errors, `[INFO]` for informational. (2) Apply prefix to every status line without exception. (3) Add `-NoColor` parameter that strips `-ForegroundColor` for piped/redirected output.
- **Impact:** Operator using screen reader cannot distinguish success from failure. Color-blind operator cannot distinguish red warnings from green success in some terminal themes.

### Finding 10
- **Section:** Lines 1110-1137
- **Severity:** MINOR
- **Round:** R3
- **Finding:** The post-deployment summary is well-structured but displays `$($cfg.Address)` which may be empty if CRS registration failed (line 988 shows fallback to empty string). An empty address field in the summary reads as: `Node #1 (coordinator): gateway 11124, terminal 11122, address ` — trailing blank with no indication of failure.
- **Recommendation:** If address is empty, display `[not registered]` or `[pending]` instead of blank. Add a note suggesting re-run or manual registration.
- **Impact:** Operator sees successful-looking summary with silently missing data. No indication that a critical step failed.

### Finding 11
- **Section:** Lines 570-828 (watchdog heredoc)
- **Severity:** MINOR
- **Round:** R3
- **Finding:** The watchdog produces log output only. There is no operator-facing status command. The operator cannot ask "are my nodes healthy right now?" without reading raw log files. No `plenumnet status` equivalent exists. The log location displayed at line 918 (`$env:USERPROFILE\.plenumnet\logs\watchdog.log`) does not match the actual SYSTEM-context path (R1-C7 DEFERRED).
- **Recommendation:** (1) Create a `plenumnet-status.ps1` or `plenumnet-status.bat` that queries each node's `/health` endpoint and displays a formatted table. (2) Place on Desktop alongside Start/Stop launchers. (3) Include service status, last watchdog check time, and LLM engine status.
- **Impact:** Operator has no quick way to verify cluster health. Must parse raw log files or manually curl health endpoints.

### Finding 12
- **Section:** Entire script
- **Severity:** CRITICAL
- **Round:** R3
- **Finding:** No uninstall procedure exists. Per QC-R2 R2-C5, after deployment the machine has: 3 Windows services, 1 scheduled task, `C:\PlenumNET` directory tree, `C:\ProgramData\PlenumNET`, wrapper .bat files, 2 desktop launchers, identity keys, log files. There is no documented or scripted way to remove any of these artifacts. The operator who wants to cleanly remove PlenumNET must manually discover and delete each artifact.
- **Recommendation:** Create `uninstall-yoda.ps1` with: (1) List of all artifacts to be removed. (2) Confirmation prompt for each category (services, scheduled tasks, identity data, launchers). (3) Explicit warning about permanent key loss. (4) Option to preserve identity data while removing services. (5) Desktop shortcut for easy access.
- **Impact:** Violates the critical rule: "Destructive actions require explicit confirmation proportional to the damage." The inverse — inability to cleanly undo a destructive install — is equally severe. An operator who deployed to the wrong machine has no recovery path.

### Finding 13
- **Section:** Lines 256-262, entire re-run behavior
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** Re-run/upgrade behavior is undocumented and has surprising side effects. On re-run: (1) Existing services are stopped and deleted (line 519-521) without warning. (2) Identity keys are preserved (good) but this is not communicated. (3) The binary is rebuilt from `main` branch tip (not a pinned version). (4) Desktop launchers are silently overwritten. (5) Watchdog scheduled task is silently re-registered. The operator has no way to know what will change on re-run vs. first-run.
- **Recommendation:** (1) Detect existing deployment at script start. (2) Display "Existing deployment detected" with summary of what will be updated vs. preserved. (3) Require confirmation before proceeding with upgrade. (4) Document re-run behavior in the script synopsis.
- **Impact:** Operator re-running to fix one issue may unknowingly rebuild from a different commit, restart all services, and overwrite launcher customizations.

### Finding 14
- **Section:** Lines 264-268
- **Severity:** MINOR
- **Round:** R3
- **Finding:** Running daemon processes are killed with `Stop-Process -Force` and no warning. The operator sees only `Stopping running node(s)...` in yellow. There is no confirmation prompt, no list of which processes/services will be stopped, and no indication that connected clients will be disconnected.
- **Recommendation:** (1) List running daemon PIDs and their ports before stopping. (2) Warn about client disconnection. (3) Add 5-second countdown: `Stopping in 5 seconds... Press Ctrl+C to abort.`
- **Impact:** During upgrade, operator's running production nodes are killed without consent.

### Finding 15
- **Section:** Lines 546-561
- **Severity:** MINOR
- **Round:** R3
- **Finding:** Coordinator health check waits up to 30 seconds (15 iterations x 2 seconds) with no progress indication. The operator sees `Waiting for coordinator to be ready...` and then silence for up to 30 seconds. No countdown, no dots, no spinner.
- **Recommendation:** Display attempt count: `Waiting for coordinator... (attempt 3/15)` or add a simple dot-progress indicator every 2 seconds.
- **Impact:** 30 seconds of silence after `Waiting for coordinator to be ready...` — operator cannot tell if script is working or hung.

### Finding 16
- **Section:** Lines 954-963
- **Severity:** MINOR
- **Round:** R3
- **Finding:** Worker CRS registration retries 5 times with 3-second delays (15 seconds total) using default white text with no prefix. Line 961: `Node #2 registration attempt 1 failed -- retrying in 3s...` — no `[WARN]` prefix, no `-ForegroundColor`, inconsistent with the rest of the output style.
- **Recommendation:** Apply `[WARN]` prefix and `-ForegroundColor Yellow` to retry messages. Show attempt N/5 consistently.
- **Impact:** Minor inconsistency in output styling. Registration retry messages blend into informational output.

### Finding 17
- **Section:** Lines 39-51
- **Severity:** MINOR
- **Round:** R3
- **Finding:** All configuration is hardcoded with no operator override. `C:\PlenumNET` install path, port 11111 base, 3 daemon count — none configurable. The script synopsis documents the invocation as `irm ... | iex` with no parameter passing mechanism.
- **Recommendation:** Add parameters with defaults: `-InstallDir "C:\PlenumNET"`, `-BasePort 11111`, `-DaemonCount 3`. Document in synopsis. For `irm | iex` invocation, document environment variable overrides (e.g., `$env:PLENUMNET_DIR`).
- **Impact:** Enterprise operators who need non-default paths or ports cannot use the deployer without editing source.

### Finding 18 (DEFERRED)
- **Section:** Lines 749, 807, 875 (watchdog LLM restart_command)
- **Severity:** DEFERRED
- **Round:** R3
- **Finding:** The LLM restart mechanism uses `cmd.exe /c` with string interpolation from a user-writable JSON file. This is R1-C1 (privilege escalation). From a UX perspective, the operator has no visibility into what restart commands will be executed, no way to review or approve them, and no notification when a restart occurs. The watchdog silently restarts LLM engines with no operator notification channel.
- **Recommendation:** Deferred to R1-C1 resolution. UX recommendation: after fix, add event log entries or desktop notifications for watchdog restart actions.
- **Impact:** DEFERRED — R1-C1 must be resolved first.

### Finding 19 (DEFERRED)
- **Section:** Lines 953-970 (unsigned CRS registration)
- **Severity:** DEFERRED
- **Round:** R3
- **Finding:** CRS registration sends unsigned payload. From a UX perspective, registration success/failure messaging is adequate but the operator has no way to verify that the registered node is authentic. No fingerprint display, no registration receipt, no verification command.
- **Recommendation:** Deferred to R1-C3 resolution. UX recommendation: after fix, display a registration fingerprint the operator can verify.
- **Impact:** DEFERRED — R1-C3 must be resolved first.

### Finding 20 (DEFERRED)
- **Section:** Lines 271-292 (no binary integrity check)
- **Severity:** DEFERRED
- **Round:** R3
- **Finding:** After build, only file size is displayed. No integrity hash shown. From a UX perspective, the operator has no way to verify the binary they just built matches any reference. No build reproducibility feedback.
- **Recommendation:** Deferred to R1-C5 resolution. UX recommendation: after fix, display TIS-27 hash after build with a note about verification.
- **Impact:** DEFERRED — R1-C5 must be resolved first.

---

## Friction Map

| Phase | Action | Rating | Notes |
|-------|--------|--------|-------|
| install | Paste `irm \| iex` command | ROUGH | No pre-flight summary, no consent, no integrity check |
| install | Admin check (Step 7) | ROUGH | Occurs after 6 steps; wasted effort if non-admin |
| install | Prerequisite check (git) | SMOOTH | Clear error message with install URL |
| install | Rust auto-install | ROUGH | No size warning, no consent, no download progress |
| install | LLVM auto-install | ROUGH | ~500MB download with no size warning or consent |
| install | MSVC env detection | ACCEPTABLE | Silent success, clear failure path |
| install | Git clone/pull | ACCEPTABLE | Clear messages but git pull exit code not checked |
| install | Stop running daemons | ROUGH | Force-kill with no warning or confirmation |
| install | Cargo build | ROUGH | 10-30 min with no progress indicator |
| install | Version check | ACCEPTABLE | Clear display but no actionable guidance on mismatch |
| install | Network detection | SMOOTH | Automatic with clear display |
| install | Identity generation | ACCEPTABLE | Clear per-node status but no key format validation feedback |
| install | Identity migration | ACCEPTABLE | Automatic but no confirmation or integrity check |
| install | Service registration | ACCEPTABLE | Clear per-node status with fallback |
| install | Coordinator startup wait | ROUGH | Up to 30s silence with no progress indication |
| install | Worker startup | SMOOTH | Clear per-node status with delay |
| install | Watchdog registration | ACCEPTABLE | Has fallback path, but log path mismatch (R1-C7) |
| install | CRS registration | ACCEPTABLE | Retry logic with messages, but no prefix styling |
| install | Deployment summary POST | SMOOTH | Non-blocking, graceful on failure |
| install | Desktop launcher creation | SMOOTH | Clear confirmation messages |
| install | Post-deploy summary | SMOOTH | Well-structured, comprehensive |
| configure | First-run experience | ROUGH | No pre-flight summary, no parameter customization |
| configure | Identity key review | ROUGH | No way to view/export keys after creation |
| configure | LLM engine config | ACCEPTABLE | Auto-discovered, fallback documented |
| operate | Start services (launcher) | ACCEPTABLE | Requires manual admin elevation; clear feedback |
| operate | Stop services (launcher) | ROUGH | No consequence warning, no confirmation |
| operate | Check cluster health | ROUGH | No status command exists; must read raw logs |
| operate | View watchdog logs | ROUGH | Displayed path wrong under SYSTEM context (R1-C7) |
| operate | Watchdog restart notification | ROUGH | Silent; operator not notified of restarts |
| update | Re-run deployer | ROUGH | Undocumented; silently rebuilds, restarts, overwrites |
| update | Version migration | ROUGH | No documented procedure, no rollback |
| uninstall | Remove PlenumNET | ROUGH | No uninstall procedure exists |

**action_count:** 32

---

## Summary Verdict

**FAIL**

The deployer has three CRITICAL UX findings (admin check placement, missing build progress, missing uninstall) and ten IMPORTANT findings. The operator experience is designed for the first demo, not the 50th use. The deploy flow works for the happy path but provides inadequate feedback during long operations, no recovery from interruption, no uninstall, and no upgrade documentation. Warning messages do not meet the "what happened, why, what to do" standard. The toolchain auto-install behavior is aggressive and unconsented.

---

## Brand Score: 4/10

**Rationale:** The script demonstrates competent engineering (watchdog architecture, BFS orphan detection, exponential backoff) but poor operator empathy. The banner is professional. The post-deploy summary is well-structured. However, the overall experience communicates "internal tool" rather than "product." A 10-30 minute build with no progress bar, admin check at step 7 instead of step 1, force-killing running processes without consent, 500MB toolchain installs without warning, and no uninstall path collectively communicate that operator time and system state are not valued. The color-only status system and inconsistent prefix formatting further erode brand quality.

---

## Top 3 Quick Wins

1. **Move admin check to line 1** (before the banner). If not admin, print clear instructions and exit. Zero implementation risk, prevents 100% of the "wasted 20 minutes building before discovering I need admin" frustration. Estimated effort: 10 lines moved, 5 minutes.

2. **Add elapsed-time heartbeat during cargo build.** Wrap the build loop with a background timer that prints `Still building... (elapsed: Xm Ys)` every 30 seconds. Converts the worst UX moment (silent 15-minute wait) into an acceptable one. Estimated effort: 15 lines added, 20 minutes.

3. **Standardize all status prefixes to `[OK]`/`[WARN]`/`[FAIL]`/`[INFO]`.** Global find-and-replace to ensure every `Write-Host` status line has a consistent prefix. Immediately improves screen reader accessibility and log-file readability. Estimated effort: 30 minutes of careful editing.

---

## Review Complete

- **Summary Verdict:** FAIL
- **Brand Score:** 4/10
- **Finding Count:** 20 total (3 CRITICAL, 10 IMPORTANT, 7 MINOR, 3 DEFERRED, excludes DEFERRED from counts)
- **DEFERRED findings:** 3 (blocked on R1-C1, R1-C3, R1-C5)
- **Friction Map actions:** 32 (7 SMOOTH, 10 ACCEPTABLE, 15 ROUGH)

---

*Capomastro Holdings Ltd. — Applied Physics Division*  
*QC-R3 UX Designer Review — 2026-03-28*
