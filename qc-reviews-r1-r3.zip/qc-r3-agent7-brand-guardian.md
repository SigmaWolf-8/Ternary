# QC-R3 Agent 7: Brand Guardian Review — `deploy-yoda.ps1`

**YODA Role ID:** `design/brand-guardian`  
**Spec Under Review:** `services/inter-cube/deploy-yoda.ps1` (1140 lines, rev deploy-yoda/v0.5.0)  
**Review Date:** 2026-03-28  
**Template Version:** QC-R3 v1.2.0 / Brand Guardian v1.2.0  
**QC-R1 Input:** `.local/qc-r1-watchdog/qc-r1-consolidated.md` (7 CRITICAL)  
**QC-R2 Input:** `.local/qc-r2-watchdog/qc-r2-consolidated.md` (10 CRITICAL)  
**Reviewer Provenance:** UNCOMMITTED — hash verification deferred to post-commit review  
**Integrity Status:** Spec file is present and non-placeholder. R1/R2 CRITICALs are NOT yet resolved.

---

## Applicability Assessment

This specification describes a PowerShell CLI deployer and embedded watchdog script. It has no GUI, no installer wizard, no launcher panel, no icon system, and no typography surfaces. The following Review Scope items are evaluated:

| Scope Item | Applicable? | Notes |
|------------|-------------|-------|
| 1. Color system | YES | Terminal `ForegroundColor` usage across ~60 Write-Host calls |
| 2. Icon system | N/A | CLI — no icons. No Readability Matrix required. |
| 3. Launcher panel | N/A | CLI — no launcher panel. |
| 4. Typography | N/A | CLI — no font choices (terminal default). |
| 5. Animation/transitions | N/A | CLI — no animation. |
| 6. CLI-specific brand | YES | Banners, step numbering, status indicators, naming, log format, summary |

---

## Findings

### Finding 1
- **Section:** Lines 101-116 (Opening banner)
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** The opening banner uses a double-rule line of `=` characters (58 chars) but the closing deployment-complete banner (lines 1112-1114) uses an identical `=` rule of the same width. There is no version string, no deployer revision, and no timestamp in the opening banner. The operator cannot tell at a glance which version of the deployer they are running. The `deployer = "deploy-yoda/v0.5.0"` string appears only in the deployment payload (line 1012), never in operator-visible output.
- **Recommendation:** Add a version line to the opening banner: `"  deploy-yoda/v0.5.0"` in Cyan, aligned with the other banner lines. This makes version identification instant during support triage.
- **Impact:** Operators troubleshooting deployment issues cannot confirm deployer version without reading the script source.

### Finding 2
- **Section:** Lines 101-116, 1112-1114, 1029-1032, 1062-1063, 1070-1071 (All banners)
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** The project has three distinct banner styles with inconsistent formatting:
  - **PowerShell deployer** (lines 102-106): Double `=` rule, 58 chars, Cyan, centered text with 2-space indent.
  - **Start launcher .bat** (lines 1029-1032): Single `=` rule, 40 chars (`========================================`), no color, left-aligned `echo`.
  - **Stop launcher .bat** (lines 1089, 1098): No banner at all — just a `title` string.
  - **Deployment-complete banner** (lines 1112-1114): Same double `=` rule as opening, but Green instead of Cyan.
  
  The `.bat` launcher banners use a different width and layout than the PowerShell banners. The brand identity "PlenumNET Array3" renders differently in each context. This is a multi-surface brand inconsistency.
- **Recommendation:** Standardize banner width to 58 characters across all surfaces. Use consistent naming: `"PlenumNET Array3 Deployer"` (PS opening), `"PlenumNET Array3 -- Service Manager"` (launcher), `"PlenumNET Array3 Deployment Complete"` (closing). Ensure all banners include the organizational name `"Capomastro Holdings Ltd."` or at minimum `"PlenumNET"`.
- **Impact:** The operator's mental model of the product identity shifts between script surfaces, weakening brand recognition.

### Finding 3
- **Section:** Lines 101-116 (Color system — banner)
- **Severity:** MINOR
- **Round:** R3
- **Finding:** The opening banner uses `Cyan` for all 5 header lines (including the organizational name). The closing banner uses `Green` for all 3 header lines. The color shift from Cyan (informational) to Green (success) is a reasonable semantic choice but is not documented as intentional brand language. There is no color key or legend for the operator.
- **Recommendation:** This is acceptable as-is but should be documented in a comment block: `# Color semantics: Cyan=brand/header, Yellow=step/action, Green=success, Red=error, DarkGray=detail, White=data`.
- **Impact:** Low — operators intuit color meaning, but future contributors may introduce inconsistent colors without a reference.

### Finding 4
- **Section:** Lines 123-149, 152-233, 237-292, 294-325, 328-337, 340-411, 413-568, 973-1021 (Step numbering system)
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** Steps are numbered `STEP 1/8` through `STEP 8/8` using `Yellow` ForegroundColor with a `---` separator. This is a strong, consistent brand pattern. However, Step 7 (lines 413-971) encompasses ~558 lines and includes identity generation, service registration, coordinator startup, worker startup, watchdog registration, CRS registration, LLM engine configuration — at least 6 logically distinct operations. The step numbering loses its value as a progress indicator when one step consumes 50% of the script.
- **Recommendation:** Either sub-number the operations within Step 7 (e.g., `STEP 7a/8: Registering services`, `STEP 7b/8: Starting coordinator`, `STEP 7c/8: Watchdog registration`, `STEP 7d/8: CRS registration`, `STEP 7e/8: LLM engine config`) or split into more steps. The current 8-step structure is too coarse for the actual work distribution.
- **Impact:** Operators waiting during the long Step 7 have no progress feedback for ~60 seconds of elapsed time. During failures, support staff cannot pinpoint which sub-operation within Step 7 failed from operator screenshots.

### Finding 5
- **Section:** Lines 128, 144, 229, 244, 282, 287, 427, 539, 920, 923, 931, 934 (Error/warning message format inconsistency)
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** Error and warning messages use at least 4 different formats:
  - `'ERROR: git is not installed...'` (line 128) — all-caps prefix, single-quoted
  - `'ERROR: cargo not found...'` (line 144) — same format
  - `"ERROR: Binary not found at $BinaryPath"` (line 287) — double-quoted for interpolation
  - `"  [WARN] Could not register node..."` (line 539) — bracketed prefix with indent
  - `"  WARN: Coordinator health check..."` (line 560) — unbracketed, indented
  - `"  ERROR: Watchdog registration failed..."` (line 931) — indented, unbracketed
  - `"  WARN: Could not post deployment summary..."` (line 1020) — unbracketed
  
  The `[OK]` indicator is consistently bracketed. The `[WARN]` indicator alternates between `[WARN]` and bare `WARN:`. The `ERROR` indicator is never bracketed to `[FAIL]` or `[ERROR]` to match the `[OK]` convention. The watchdog log (line 825) uses `[OK]`, `[WARN]`, `[FAIL]` — a different convention than the deployer itself.
- **Recommendation:** Standardize all deployer output to use bracketed indicators: `[OK]`, `[WARN]`, `[FAIL]`. Replace all bare `ERROR:` with `[FAIL]` and all bare `WARN:` with `[WARN]`. Align indentation: all status lines should use 2-space indent (`"  [OK] ..."`). This matches the watchdog's own convention.
- **Impact:** Operators grepping logs or screenshots for failure patterns need to search for multiple string variants. Automated log parsers break on inconsistent prefixes.

### Finding 6
- **Section:** Lines 592-594, 824-827 (Watchdog log format)
- **Severity:** IMPORTANT
- **Round:** R3
- **Finding:** The watchdog log uses the timestamp format `yyyy-MM-dd HH:mm:ss` (line 593) which has no timezone indicator. The deployer's deployment payload uses ISO 8601 format `(Get-Date -Format "o")` (line 1011) which includes timezone. The wrapper `.bat` log entries (lines 470, 501) use `%date% %time%` which is locale-dependent and inconsistent with both other formats. Three different timestamp formats across three output surfaces is a brand consistency failure.
- **Recommendation:** Standardize all timestamps to ISO 8601 with timezone (`Get-Date -Format "o"` in PowerShell, or a fixed `yyyy-MM-ddTHH:mm:ss.fffzzz` pattern). For the `.bat` wrappers, use PowerShell to format the timestamp or accept the `.bat` limitation and document it.
- **Impact:** Operators correlating events across daemon logs, watchdog logs, and deployment records must mentally convert between 3 timestamp formats. Timezone-unaware watchdog timestamps are ambiguous for distributed deployments.

### Finding 7
- **Section:** Lines 442, 525, 897, 1024, 1086 (Brand name consistency)
- **Severity:** MINOR
- **Round:** R3
- **Finding:** The product naming is mostly consistent but has minor variations:
  - Service names: `PlenumNET-Array3-1` (hyphenated, correct)
  - Display names: `PlenumNET Array3 Node #1 (coordinator)` (space-separated, correct)
  - Desktop launcher: `Start PlenumNET Array3.bat` (correct)
  - Launcher title: `PlenumNET Array3 Service Manager` (correct)
  - Watchdog task: `PlenumNET-Array3-Watchdog` (hyphenated, correct)
  - Deployer banner: `PlenumNET Array3 Deployer` (correct)
  - `.bat` echo: `PlenumNET Array3 -- Service Manager` (em-dash style with spaces)
  - `.bat` echo: `PlenumNET Array3 Services Active` (no separator)
  
  Overall naming is good. The organizational attribution `"Applied Physics Division -- Capomastro Holdings Ltd."` appears only in the opening banner (line 105). It does not appear in the closing summary, desktop launchers, or service descriptions.
- **Recommendation:** Add `Capomastro Holdings Ltd.` to the service description field (line 532) and as a footer line in the closing deployment summary banner. This ensures the organizational identity persists in the Windows Services MMC and in operator-visible output.
- **Impact:** Low — the organizational identity is present at script start but fades from visibility in all downstream artifacts.

### Finding 8
- **Section:** Lines 108-115, 1116-1134 (Deployment summary formatting)
- **Severity:** MINOR
- **Round:** R3
- **Finding:** The opening info block (lines 108-115) and closing summary block (lines 1116-1134) use a consistent label-value format with 2-space indent and colon separator. Label alignment is inconsistent:
  - Opening: `"  Nodes        : "`, `"  Coordinator  : "`, `"  Gateway Ports: "` (variable padding to colon)
  - Closing: `"  Node #1 (coordinator): "`, `"  VM API         : "`, `"  Services       : "` (different variable padding)
  
  The opening block pads to column 17 (approximately). The closing block uses different padding widths. Neither block is perfectly column-aligned.
- **Recommendation:** Pick a fixed column position (e.g., column 18) and pad all labels to that position in both blocks. Use `.PadRight(18)` or equivalent formatting.
- **Impact:** Visual polish issue only. The information is readable but appears hastily formatted.

### Finding 9
- **Section:** Lines 470-482, 500-513 (Wrapper .bat log format)
- **Severity:** DEFERRED
- **Round:** R3
- **Finding:** The wrapper `.bat` heredoc log entries use format `[%date% %time%] Starting PlenumNET Node #N (CRS/Cube)...`. The `%date%` and `%time%` environment variables are locale-dependent — on some Windows locales, `%date%` produces `DD/MM/YYYY` and on others `MM/DD/YYYY`. This log format is inconsistent with the watchdog log format (Finding 6) and with ISO 8601. However, this section overlaps with QC-R1 C7 (watchdog log path mismatch) and QC-R2 R2-WD1 (no timezone in timestamps). **DEFERRED pending R1/R2 CRITICAL resolution.**
- **Recommendation:** When R1 C7 and R2 R2-WD1 are resolved, standardize the `.bat` wrapper timestamps as part of the same fix.
- **Impact:** Deferred.

### Finding 10
- **Section:** Lines 824-827 (Watchdog summary line format)
- **Severity:** DEFERRED
- **Round:** R3
- **Finding:** The watchdog summary JSON line (line 827) uses string ratios (`"3/3"`) for daemon and LLM counts instead of separate integer fields. This was identified in QC-R1 M7 and QC-R2 R2-M2. From a brand perspective, the summary line mixes human-readable prefix (`[OK] 3/3 daemons | 3/3 LLM engines`) with machine-readable JSON (`[SUMMARY] {"daemons":"3/3",...}`) on two consecutive lines. The JSON line is not valid as a standalone record because it uses string ratios. **DEFERRED — overlaps with R1 M7 / R2 R2-M2.**
- **Recommendation:** When R1/R2 findings are resolved, split into integer fields: `{"daemons_healthy":3,"daemons_total":3,...}`.
- **Impact:** Deferred.

### Finding 11
- **Section:** Lines 749, 807 (LLM restart via cmd.exe)
- **Severity:** DEFERRED
- **Round:** R3
- **Finding:** The watchdog restarts LLM engines via `cmd.exe /c $engine.restart_command`. From a brand/presentation perspective, if the restart command fails, the error message in the watchdog log is generic (`"FAILED to restart: $_"`). There is no operator-friendly guidance. However, this section is subject to QC-R1 C1 (command injection) and QC-R2 C8 (SYSTEM privilege). **DEFERRED pending R1/R2 CRITICAL resolution.**
- **Recommendation:** When C1/C8 are resolved, add structured error classification to restart failure messages.
- **Impact:** Deferred.

### Finding 12
- **Section:** Lines 1023-1108 (Desktop launcher .bat files)
- **Severity:** MINOR
- **Round:** R3
- **Finding:** The Stop launcher `.bat` (lines 1087-1107) has no banner at all — it is purely functional. The Start launcher has a banner. The asymmetry means the operator experience differs between start and stop operations. The Stop launcher also lacks a confirmation message format matching the Start launcher's `[OK]` convention — it just says `"All Array3 services stopped."` with no status brackets.
- **Recommendation:** Add a minimal banner to the Stop launcher matching the Start launcher's style. Use `[OK] All Array3 services stopped.` for consistency.
- **Impact:** Minor polish — operators who use the Stop launcher get a terser, less branded experience.

### Finding 13
- **Section:** Lines 102-106 (Color palette completeness)
- **Severity:** MINOR
- **Round:** R3
- **Finding:** The script uses exactly 6 terminal colors across all Write-Host calls:
  - `Cyan` — banner headers (6 uses)
  - `Yellow` — step headers, warnings, action prompts (~20 uses)
  - `Green` — success indicators, closing banner (~25 uses)
  - `Red` — error messages (~8 uses)
  - `White` — data/information lines (~20 uses)
  - `DarkGray` — detail/supplementary info (~10 uses)
  
  This is a well-chosen, semantically clear 6-color palette. No color is misused (e.g., Red is never used for non-error content). However, the palette is not formally declared — it exists only by convention across 1140 lines. A future contributor could introduce `Magenta` or `DarkYellow` without realizing the palette is intentional.
- **Recommendation:** Add a comment block at the top of the script documenting the color semantics (see Finding 3 recommendation).
- **Impact:** Future maintainability — the implicit palette works today but is fragile.

### Finding 14
- **Section:** Lines 961, 1020, 1048, 1053, 1058 (Non-colored output)
- **Severity:** MINOR
- **Round:** R3
- **Finding:** Several Write-Host calls omit the `-ForegroundColor` parameter entirely:
  - Line 961: `"  Node #$($cfg.Id) registration attempt $attempt failed -- retrying in 3s..."` (no color — defaults to console foreground)
  - Line 125: `Write-Host "---"` (no color)
  - Lines 1048, 1053, 1058 inside `.bat` heredocs: These are `echo` statements and cannot use PowerShell colors (acceptable).
  
  The line 961 registration retry message is a warning-class message that should use `Yellow` to match other warnings. The `---` separator lines (used after every step header) have no color, which is acceptable but could use `DarkGray` for visual hierarchy.
- **Recommendation:** Add `-ForegroundColor Yellow` to line 961. Optionally add `-ForegroundColor DarkGray` to `---` separators for visual consistency.
- **Impact:** The retry message blends with surrounding text instead of standing out as a warning.

---

## Scope Items: N/A

| Scope Item | Status | Notes |
|------------|--------|-------|
| 2. Icon system | N/A | CLI — no icons. No Readability Matrix produced. |
| 3. Launcher panel | N/A | CLI — no launcher panel. |
| 4. Typography | N/A | CLI — terminal monospace default. |
| 5. Animation/transitions | N/A | CLI — no animation or transition surfaces. |

---

## Summary Verdict: **PASS WITH CONDITIONS**

The deployer script demonstrates a strong, intuitive color system and consistent step-numbering pattern. The brand names (`PlenumNET`, `Array3`, `Capomastro Holdings Ltd.`) are used correctly throughout. The `[OK]` status indicator convention is well-established. The 6-color terminal palette is semantically sound.

The conditions for full PASS are:
1. Standardize error/warning indicators to `[OK]`/`[WARN]`/`[FAIL]` bracket format (Finding 5)
2. Add deployer version to the opening banner (Finding 1)
3. Standardize timestamp format across all three output surfaces (Finding 6)

Three findings are DEFERRED pending R1/R2 CRITICAL resolution (Findings 9, 10, 11). These do not affect the verdict or Brand Score.

---

## Brand Score: **6 / 10**

| Criterion | Score | Weight | Notes |
|-----------|-------|--------|-------|
| Color consistency | 8/10 | High | Strong 6-color palette, minor gaps (Finding 14) |
| Status indicator consistency | 5/10 | High | `[OK]` is great; `ERROR`/`WARN` inconsistent (Finding 5) |
| Banner/header identity | 5/10 | Medium | Three different banner styles across surfaces (Finding 2) |
| Naming consistency | 8/10 | Medium | `PlenumNET Array3` used correctly throughout |
| Summary/data formatting | 6/10 | Medium | Readable but column alignment inconsistent (Finding 8) |
| Timestamp consistency | 3/10 | Medium | Three different timestamp formats (Finding 6) |
| Version visibility | 3/10 | Low | Version absent from all operator-visible output (Finding 1) |

**Weighted average: 6/10** — The script has a good foundation but needs a consistency pass.

---

## Top 3 Quick Wins

1. **Standardize status indicators** (Finding 5) — Replace all bare `ERROR:` with `[FAIL]` and bare `WARN:` with `[WARN]` across the script. ~12 line edits. Immediate impact on log parseability and visual consistency. Effort: 15 minutes.

2. **Add version to opening banner** (Finding 1) — Insert `Write-Host "  deploy-yoda/v0.5.0" -ForegroundColor Cyan` after line 104. One line edit. Immediate impact on support triage. Effort: 2 minutes.

3. **Add color to uncolored warning** (Finding 14) — Add `-ForegroundColor Yellow` to line 961 (registration retry). One parameter addition. Prevents warning from being invisible in output. Effort: 1 minute.

---

## Review Complete

- **Summary Verdict:** PASS WITH CONDITIONS
- **Brand Score:** 6 / 10
- **Findings:** 14 total (0 CRITICAL, 4 IMPORTANT, 7 MINOR, 3 DEFERRED)
- **DEFERRED findings:** 3 (Findings 9, 10, 11 — blocked by unresolved R1/R2 CRITICALs)
- **Quick Wins:** 3 identified (combined effort: ~20 minutes)

---

*Capomastro Holdings Ltd. — Applied Physics Division*  
*QC-R3 Brand Guardian Review — 2026-03-28*  
*Reviewer: design/brand-guardian (YODA Role ID)*
