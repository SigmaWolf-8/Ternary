# QC-R2 Senior Developer Review: Array3 Deployer & Watchdog

**Reviewer:** Agent 5 — Senior Developer (Build Systems / Windows Platform / Architecture)  
**Spec Under Review:** `services/inter-cube/deploy-yoda.ps1` (1542 lines, rev deploy-yoda/v0.5.0, REWRITTEN)  
**Also Reviewed:** `services/inter-cube/uninstall-yoda.ps1` (214 lines, NEW)  
**QC-R1 Reference:** `.local/qc-r1-watchdog/qc-r1-consolidated.md` (29 findings, ALL RESOLVED)  
**Review Date:** 2026-03-28  
**Template Version:** QC-R2 v1.2.0  

---

## Part 1: Round 1 Response — Critical Finding Resolutions

### C1: LLM `restart_command` Injection → SYSTEM Privilege Escalation

**Verdict: AGREE** with resolution.

The implementation is sound. `Test-LlmExecutable` (watchdog heredoc, line ~870) validates against an allowlist of known executables (`llama-server.exe`, `ollama.exe`, `vllm.exe`, `koboldcpp.exe`) and blocks paths under user-writable directories (`$env:USERPROFILE`, `$env:APPDATA`, `$env:LOCALAPPDATA`, `$env:TEMP`). `Invoke-LlmRestart` (line ~888) uses proper argument array parsing with a quote-aware character-by-character parser and `Start-Process -FilePath` instead of `cmd.exe /c` string interpolation. `Restrict-FileAcl` is applied to `llm-engines.json` (line 1203). `Restrict-DirAcl` is applied to `C:\ProgramData\PlenumNET` (line 1210). This is a complete remediation of the injection vector. The defense-in-depth (allowlist + path validation + ACL + process isolation) is well-layered.

### C2: LLM Server Path Planting → Privilege Escalation

**Verdict: AGREE** with resolution.

Search paths for `llama-server.exe` are now limited to PATH, `C:\llama.cpp\build\bin\Release\`, `C:\llama.cpp\`, and `$RepoDir` (lines 1165-1177). All user-writable locations (`$env:LOCALAPPDATA`, etc.) have been removed from the search. The `Test-LlmExecutable` function in the watchdog provides a secondary runtime validation layer. Adequate remediation.

### C3: Unsigned CRS Registration → Identity Spoofing (INVARIANT 7)

**Verdict: AGREE** with resolution.

`Get-TlDsaSignature` (lines 152-172) correctly delegates signing to the daemon binary via `CUBE_MODE=sign`, `CUBE_IDENTITY_DIR`, and `CUBE_SIGN_PAYLOAD` environment variables. Registration payload (lines 1283-1292) includes `timestamp` and `signature` fields with sign payload format `"CRS-REGISTER||$publicKey||$endpoint||$timestamp"`. This correctly uses TL-DSA via the daemon binary — no Node.js `crypto.sign/verify` is used anywhere in the script. INVARIANT 7 is satisfied. The `||` delimiter in the sign payload provides adequate domain separation.

### C4: Deployment Payload Uses Hostname/IP as Identity (INVARIANT 9)

**Verdict: AGREE** with resolution.

The deployment payload (lines 1343-1365) uses `addresses` (Rep C addresses array) as the primary top-level identifier. `hostname`, `ip`, `architecture`, `binaryPath`, `binarySizeMB`, `logDir`, `identityBase` are correctly relegated to a `metadata` sub-object. The payload is signed with TL-DSA via coordinator identity (lines 1337-1341). Sign payload format `"DEPLOYMENT||$addr1||$addr2||...||$timestamp"` binds the signature to Rep C addresses. INVARIANT 9 is satisfied — Rep C addresses are the identity binding, hostname/IP are operational metadata only.

### C5: No TIS-27 Binary Integrity Checksum

**Verdict: AGREE** with resolution.

SHA-256 is computed immediately after build (line 502). TIS-27 hash is attempted via `CUBE_MODE=hash` with `CUBE_HASH_TARGET` (lines 506-520) with SHA-256 fallback prefixed as `sha256:` (line 522). Binary integrity is re-verified before service registration via SHA-256 comparison (lines 527-535), with hard abort on mismatch. Hash is embedded in the deployment payload as `binaryHash` (line 1349). The dual-hash approach with graceful fallback is pragmatic and the re-verification closes the TOCTOU window between build and service registration.

### C6: Unpinned Source Clone → Non-Reproducible Builds

**Verdict: AGREE** with resolution.

`$RELEASE_TAG = "v0.5.0"` is defined at the top (line 67). `git clone --branch $RELEASE_TAG --depth 1` (line 416). Existing repos use `git fetch origin tag $RELEASE_TAG --force` + `git checkout $RELEASE_TAG` (lines 435-437). Deployment payload includes `releaseTag` (line 1350). The step header shows the pinned tag. Builds are now reproducible and auditable.

### C7: Watchdog Log Path Mismatch (SYSTEM vs. User Profile)

**Verdict: AGREE** with resolution.

Watchdog heredoc uses hardcoded `$logDir = '$LOG_DIR'` (line 841) which is expanded at heredoc generation time to the absolute path `C:\PlenumNET\plenumnet-data\logs`. Completion summary shows the correct path (line 1517: `Watchdog Log : $LOG_DIR\watchdog.log`). No `$env:USERPROFILE` dependency remains in the watchdog. All PlenumNET logs are now consolidated under one directory. Correct fix.

---

## Part 2: New Findings

### Finding 1

- **Section:** Line 1210 — `Restrict-DirAcl` parameter name mismatch
- **Severity:** MINOR
- **Finding:** Line 1210 calls `Restrict-DirAcl -FilePath $llmEnginesDir` but the function signature at line 190 declares the parameter as `-DirPath`, not `-FilePath`. PowerShell's positional parameter binding will still work since there's only one parameter, but this is a naming inconsistency that will produce a warning under `Set-StrictMode -Version Latest` and could confuse future maintainers.
- **Recommendation:** Change `Restrict-DirAcl -FilePath $llmEnginesDir` to `Restrict-DirAcl -DirPath $llmEnginesDir`.
- **Verification:** `Select-String -Pattern 'Restrict-DirAcl' deploy-yoda.ps1` — all calls should use `-DirPath`.

### Finding 2

- **Section:** Lines 649-657 — Public key extraction re-invokes keygen mode
- **Severity:** IMPORTANT
- **Finding:** Lines 649-653 re-invoke `CUBE_MODE=keygen` on every identity (including existing ones with `master.key` present) to extract the public key. Whether this overwrites, appends, or safely reads the existing key depends entirely on the daemon's keygen idempotency behavior. If the daemon's keygen mode regenerates the key when one already exists, this silently destroys existing identities during upgrades. The R1 resolution documents this as a limitation (I13 — "fragile stdout regex parsing") but does not address the destructive side-effect risk.
- **Recommendation:** Either (a) add a dedicated `CUBE_MODE=pubkey` or `CUBE_MODE=info` mode to the daemon for safe key extraction without side effects, or (b) as a short-term mitigation, compute SHA-256 of `master.key` before and after the extraction call and abort with a FAIL if it changed.
- **Verification:** Hash `master.key` before line 649, hash again after line 657, compare. Alert if different.

### Finding 3

- **Section:** Lines 717, 721, 750, 754 — Wrapper .bat timestamp parsing
- **Severity:** MINOR
- **Finding:** The wrapper .bat timestamp extraction uses `for /f "tokens=1-4 delims=/ "` to parse the output of `powershell -NoProfile -Command "Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz'"`. The PowerShell output is a single ISO 8601 string (e.g., `2026-03-28T14:30:00+00:00`) which contains no `/` or space delimiters. The `%%a` variable captures the entire string correctly (since there's nothing to split), but the `tokens=1-4` clause is dead logic — `%%b`, `%%c`, `%%d` are always empty. This works but is misleading.
- **Recommendation:** Simplify to `for /f "delims=" %%a in (...)` to make the intent clear.
- **Verification:** Review generated .bat wrapper content and confirm timestamps render correctly in log files.

### Finding 4

- **Section:** Line 982 — Watchdog heredoc `$daemonPorts` array generation
- **Severity:** IMPORTANT
- **Finding:** Line 982 generates `$daemonPorts` inside the watchdog heredoc using deployer-time variable expansion: `$daemonPorts = @($(($daemonConfigs | ForEach-Object { "$($_.GatewayPort), $($_.TerminalPort)" }) -join ', '))`. This produces a single-element array containing one comma-separated string, e.g., `@("11124, 11122, 11151, 11149, 11178, 11176")` rather than a flat array of integers `@(11124, 11122, 11151, 11149, 11178, 11176)`. The `-contains` check on line 994 (`$daemonPorts -contains $c.LocalPort`) compares an integer `LocalPort` against a string, which will never match. This means the orphan detector's port-based legitimacy check always fails, and every non-service-tree daemon process older than 30 seconds will be killed — even if it's listening on a valid daemon port. The 30-second grace period (Finding M1 from R1) was added to mitigate false positives, but the underlying port check is broken.
- **Recommendation:** Generate port values as a proper PowerShell integer array in the heredoc. Replace the `ForEach-Object` join with explicit enumeration: `$daemonPorts = @(11124, 11122, 11151, 11149, 11178, 11176)` (computed at heredoc generation time).
- **Verification:** In the generated watchdog script at `$wrapperDir\array3-watchdog.ps1`, verify `$daemonPorts` is a flat integer array. Test: `@(11124, 11122) -contains 11124` returns `$true`; `@("11124, 11122") -contains 11124` returns `$false`.

### Finding 5

- **Section:** Uninstaller Steps 6 and 7 — Identity deletion bypass
- **Severity:** IMPORTANT (data safety)
- **Finding:** The uninstaller asks the user to confirm identity data deletion in Step 6 with a double-confirmation ("DELETE" keyword). If the user declines, identity data at `C:\PlenumNET\plenumnet-data` is preserved. However, Step 7 then offers to remove the entire repo directory `C:\PlenumNET` via `Remove-Item $repoDir -Recurse -Force`, which will recursively delete `plenumnet-data` (a subdirectory of `$repoDir`) even if the user explicitly declined deletion in Step 6. This completely bypasses the double-confirmation safeguard.
- **Recommendation:** If identity data was preserved in Step 6, either (a) move identity data to a safe temporary location before Step 7, or (b) in Step 7, use `-Exclude plenumnet-data` or skip the recursive delete and enumerate only non-identity subdirectories, or (c) reorder steps so repo deletion is offered first and identity deletion is offered afterward only if the user declined repo deletion.
- **Verification:** Run uninstaller, decline identity deletion (Step 6), accept repo deletion (Step 7). Verify identity data still exists at original or backup location.

### Finding 6

- **Section:** Lines 1524-1539 — Catch block cleanup scope
- **Severity:** MINOR
- **Finding:** The try/catch block wrapping steps 1-10 (starting at line 277) cleans up only `$partialServices` on failure. If the interruption occurs during or after Step 9, the following artifacts are left orphaned: (1) watchdog scheduled task `PlenumNET-Array3-Watchdog`, (2) `llm-engines.json` at `C:\ProgramData\PlenumNET`, (3) desktop launchers created in Step 10. The cleanup does not account for these later-stage artifacts.
- **Recommendation:** Track all created artifacts in a `$cleanupArtifacts` list throughout the script. In the catch block, iterate and remove all tracked artifacts (services, scheduled tasks, files, launchers).
- **Verification:** Simulate failure at Step 10 (e.g., throw after watchdog registration), verify no orphaned scheduled task or launchers remain.

### Finding 7

- **Section:** Lines 581-585 — `$ip` fallback to `0.0.0.0`
- **Severity:** MINOR
- **Finding:** If `Get-NetIPAddress` returns no valid addresses, `$ip` falls back to `"0.0.0.0"` (line 585). This value is used in endpoint strings (`${ip}:${gatewayPort}` at line 626), which produces `"0.0.0.0:11124"` — not a routable address. Worker registration with this endpoint registers unreachable nodes. The deployment payload's `metadata.ip` field also contains `"0.0.0.0"`. No validation guards against this.
- **Recommendation:** If `$ip` resolves to `"0.0.0.0"`, substitute `"127.0.0.1"` for local cluster operations and emit a `[WARN]` that external connectivity is unavailable.
- **Verification:** Test on a machine with disabled network adapters. Verify endpoint uses `127.0.0.1` and a warning is displayed.

### Finding 8

- **Section:** Lines 1336-1341 — Empty-address deployment signing
- **Severity:** MINOR
- **Finding:** If all CRS registrations fail, `$registeredAddresses` is empty. The sign payload `"DEPLOYMENT||||$timestamp"` (with empty address portion) is technically valid but semantically meaningless — it signs a deployment with no registered nodes. The POST to the remote CRS proceeds anyway. A verifier expecting at least one address in the signed payload could reject this.
- **Recommendation:** Guard the deployment POST: skip the remote CRS notification if `$registeredAddresses` is empty, and warn the operator that no nodes were registered.
- **Verification:** Simulate all registration failures. Verify no deployment POST is sent and a `[WARN]` is displayed.

---

## Part 3: Invariant Compliance Summary

| Invariant | Status | Evidence |
|-----------|--------|----------|
| **INVARIANT 7:** All signatures use TL-DSA. No Node.js crypto.sign/verify. | **PASS** | `Get-TlDsaSignature` delegates to daemon binary via `CUBE_MODE=sign`. No `crypto.sign/verify` anywhere in the PowerShell layer. CRS registration (line 1285) and deployment (line 1340) payloads both signed via daemon. |
| **INVARIANT 8:** No raw binary integers into sponge absorb. | **PASS** | No sponge operations in the PowerShell layer. TIS-27 hash is delegated to daemon binary via `CUBE_MODE=hash`. All data passed to sponge operations goes through the daemon's Rust implementation. |
| **INVARIANT 9:** All identity bindings use Rep C addressing. No hostname/IP as identity. | **PASS** | Deployment payload uses `addresses` (Rep C array) as primary identifier (line 1344). Hostname/IP are in `metadata` sub-object (lines 1355-1364). Node IDs are Rep C ordinals {1,2,3} as documented in `.DESCRIPTION`. |

---

## Part 4: Feasibility Risk Table

| Implementation Task | Complexity | Risk | Notes |
|---------------------|-----------|------|-------|
| Prerequisite detection (git, cargo, clang) | Low | Low | Standard `Get-Command` checks with installer fallbacks. Well-tested pattern. |
| LLVM/Rust auto-installation | Medium | Medium | Depends on external package managers (winget) and GitHub API. Fallback paths exist for both. |
| Source clone with tag pinning | Low | Low | Standard `git clone --branch --depth 1`. Correct. |
| Cargo release build with progress | Low | Low | Straightforward pipeline with heartbeat. `CARGO_BUILD_JOBS=1` prevents OOM. |
| Binary integrity (SHA-256 + TIS-27) | Low | Low | SHA-256 is native PowerShell. TIS-27 delegates to daemon with SHA-256 fallback. Re-verify before service start. |
| Identity generation (PT26-DSA keygen) | Medium | **Medium** | **Finding 2** — keygen re-invocation on existing identities depends on daemon idempotency. Must verify before production. |
| Windows Service registration via sc.exe | Low | Low | Well-tested pattern. Failure/recovery actions configured. |
| Wrapper .bat service shims | Low | Low | Necessary for env-var injection. Restart loop with exponential backoff is correct. ACL-restricted. |
| Watchdog heredoc generation | Medium | **High** | **Finding 4** — `$daemonPorts` array generation is broken. Orphan port-check always fails. Must fix before deployment. |
| LLM engine config with ACL restriction | Low | Low | `Restrict-FileAcl` and `Restrict-DirAcl` applied. Allowlist validation in watchdog is comprehensive. |
| TL-DSA signed CRS registration | Medium | Low | Delegates to daemon binary via env vars. Sign payload format is clear. 5-retry loop with 3s backoff. |
| Deployment payload POST to remote CRS | Low | Low | Non-critical — failure is graceful (warn-only). Payload schema is complete. |
| Desktop launcher generation | Low | Low | Admin check in launchers. ACL-restricted via `Restrict-FileAcl`. `.cmd` extension. |
| Uninstaller | Low | **Medium** | **Finding 5** — Step 7 recursive delete can bypass Step 6 identity preservation safeguard. |
| Interrupt cleanup | Low | Medium | **Finding 6** — Only services cleaned up, not watchdog task or launchers. Acceptable for v0.5.0. |
| Coordinator health check blocking | Low | Low | 15-attempt loop with 2s intervals. Workers skipped if coordinator unhealthy. Correct. |
| Service account configuration | Low | Low | `Grant-LogonAsService` uses GUID-suffixed temp dir with restricted ACL. secedit TOCTOU resolved. |

---

## Part 5: Summary Verdict

### **PASS WITH CONDITIONS**

The rewritten `deploy-yoda.ps1` represents a substantial improvement over the R1 version. All 7 CRITICAL findings have been adequately resolved with well-implemented fixes:

- **Security:** TL-DSA signatures on both CRS registration and deployment payloads, LLM executable allowlist with path validation, ACL restrictions on all sensitive files (keys, configs, wrappers, launchers), binary integrity re-verification before service start.
- **Reproducibility:** Pinned release tag, SHA-256/TIS-27 dual hashing, version alignment checks.
- **Operational:** Coordinator-first startup with blocking health check, worker skip on CRS failure, watchdog with service restart + orphan detection + LLM two-tier health checking + log rotation.
- **Identity:** Rep C addresses as primary identifiers in deployment payload, hostname/IP relegated to metadata, Node IDs documented as Rep C ordinals.

The uninstaller (`uninstall-yoda.ps1`) is clean and well-structured with proper admin check, service teardown order (3→2→1), double-confirmation for identity deletion, and legacy data cleanup.

### Conditions for Full Pass

1. **Finding 4 (IMPORTANT — must fix):** Fix `$daemonPorts` array generation in the watchdog heredoc. The current implementation produces a single comma-separated string element, not a flat integer array. The `-contains` port check always fails, causing false-positive orphan kills of legitimate daemon processes. This is a functional bug that will cause service disruption in production.

2. **Finding 2 (IMPORTANT — must verify):** Verify that `CUBE_MODE=keygen` is idempotent when `master.key` already exists, or add pre/post SHA-256 integrity check on `master.key` during public key extraction. Identity destruction during upgrades would be a data-loss scenario.

3. **Finding 5 (IMPORTANT — should fix):** Fix uninstaller Step 6/7 ordering to prevent `Remove-Item $repoDir -Recurse -Force` from bypassing the identity deletion double-confirmation safeguard. This is a data-safety issue in the uninstall path.

### Items Acceptable as-is for v0.5.0

- **Finding 1** (parameter name mismatch): Cosmetic, works via positional binding.
- **Finding 3** (bat timestamp parsing): Works correctly despite misleading syntax.
- **Finding 6** (incomplete cleanup): Low likelihood of mid-Step-9/10 failure. Acceptable.
- **Finding 7** (`0.0.0.0` endpoint fallback): Edge case on machines with no network.
- **Finding 8** (empty-address deployment signing): Edge case when all registrations fail.

### Overall Assessment

The deployer is implementable as described. The architecture is sound: 10-step linear deployment with proper error boundaries, coordinator-first startup sequencing, signed identity operations, ACL-hardened filesystem, and a well-designed watchdog with LLM two-tier health checking and BFS orphan detection. The two mandatory-fix findings (4 and 2) are localized bugs — not architectural flaws — and can be resolved with minimal code changes. The uninstaller is complete and covers all deployer-created artifacts including legacy data migration paths.

---

*Capomastro Holdings Ltd. — Applied Physics Division*  
*QC-R2 Senior Developer Review — 2026-03-28*  
*Reviewer: Agent 5 — Build Systems / Windows Platform / Architecture*  
*Sed Quis Est Deus? Qui Commando IO.*
