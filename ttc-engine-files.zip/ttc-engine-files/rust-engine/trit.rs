// Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
// Patent(s) Pending — All Rights Reserved
// Applied Physics Division
//
// PROPRIETARY AND CONFIDENTIAL
// All Rights Reserved.
//
// This file is part of the Salvi Framework / PlenumNET platform.
// Unauthorized copying, modification, distribution, or use of this file,
// via any medium, is strictly prohibited without the prior written
// permission of Capomastro Holdings Ltd.
//
// See LICENSE in the repository root for full terms.

//! # Trit — Three-Vector Algebraic Value Type
//!
//! The foundational value type for the Salvi Framework. Wraps three
//! [`TritInt`] vectors representing an element of the form `a + bφ + cω`:
//!
//! - `v[0]` — coefficient of **1** (integer ground ring ℤ)
//! - `v[1]` — coefficient of **φ** (golden ratio, ℤ\[φ\] extension)
//! - `v[2]` — coefficient of **ω** (cube root of unity, ℤ\[ω\] extension)
//!
//! All three vectors are always live — no caps, no sentinels, no modes.
//! For a plain integer, `v[1]` and `v[2]` hold the additive identity.
//!
//! **Multiplication is algebra-specific:** `mul_golden` applies φ² = φ + 1,
//! `mul_scalar` operates on `v[0]` only. Eisenstein multiplication
//! (ω² = −1 − ω) is deferred to Phase 3 (requires signed arithmetic).
//!
//! **Position in the type chain:**
//! - `TritInt` — one ternary integer (Phase 1)
//! - `Trit` — three TritInts: v\[0\] = ℤ, v\[1\] = φ, v\[2\] = ω (this module)
//! - `[Trit; 3]` — one vertex coordinate
//! - Triangles, meshes, manifolds — built on Trit

use crate::trit_int::{TritInt, Overflow};
use crate::gf3_algebra::{AlgebraicTrit, gf3_add, gf3_sub, gf3_mul, gf3_square};
use crate::constants;
use zeroize::Zeroize;
use std::fmt;
use std::hash::{Hash, Hasher};
use std::ops::{Add, Sub, AddAssign, SubAssign};

// ══════════════════════════════════════════════════════════════
// TYPE DEFINITION
// ══════════════════════════════════════════════════════════════

/// A three-vector algebraic value: `a + bφ + cω`.
///
/// `v[0]` = integer part (ℤ), `v[1]` = golden ratio coefficient (φ),
/// `v[2]` = cube root of unity coefficient (ω).
///
/// Three vectors because the system is base 3. Three algebraic components
/// because the framework operates in three algebraic domains.
pub struct Trit {
    pub v: [TritInt; 3],
}

// ══════════════════════════════════════════════════════════════
// CONSTRUCTORS (all const fn)
// ══════════════════════════════════════════════════════════════

impl Trit {
    /// Zero: the additive identity in all three components.
    pub const fn zero() -> Self {
        Trit { v: [TritInt::zero(), TritInt::zero(), TritInt::zero()] }
    }

    /// One: the multiplicative identity (1 + 0φ + 0ω).
    pub const fn one() -> Self {
        Trit { v: [TritInt::one(), TritInt::zero(), TritInt::zero()] }
    }

    /// Scalar: a plain integer (a + 0φ + 0ω).
    pub const fn scalar(a: TritInt) -> Self {
        Trit { v: [a, TritInt::zero(), TritInt::zero()] }
    }

    /// Golden: a ℤ[φ] element (a + bφ + 0ω).
    pub const fn golden(a: TritInt, b: TritInt) -> Self {
        Trit { v: [a, b, TritInt::zero()] }
    }

    /// Eisenstein: a ℤ[ω] element (a + 0φ + cω).
    /// Note: mul_eisenstein is deferred to Phase 3 (requires signed arithmetic).
    /// This constructor is provided so the slot is addressable.
    pub const fn eisenstein(a: TritInt, c: TritInt) -> Self {
        Trit { v: [a, TritInt::zero(), c] }
    }

    /// Full: all three components live (a + bφ + cω).
    pub const fn new(a: TritInt, b: TritInt, c: TritInt) -> Self {
        Trit { v: [a, b, c] }
    }

    /// Construct a scalar Trit from a trit slice. Rep B {0,1,2}, LSB-first.
    /// Populates v[0] only. For multi-component values, use `golden`, `eisenstein`, or `new`.
    pub const fn from_trits(trits: &[u8]) -> Self {
        Self::scalar(TritInt::from_trits(trits))
    }

    /// Scalar repunit: R_n = 111...1₃ (n ones) + 0φ + 0ω.
    pub const fn repunit(n: usize) -> Self {
        Self::scalar(TritInt::repunit(n))
    }

    /// Scalar from u64 (BOUNDARY CROSSING: binary → ternary).
    pub const fn from_u64(val: u64) -> Self {
        Self::scalar(TritInt::from_u64(val))
    }

    // ── Const accessors (take self by value for const fn compatibility) ──

    /// Extract v[0] (integer part). Const fn — takes self by value.
    pub const fn v0(self) -> TritInt {
        let Trit { v: [a, _b, _c] } = self;
        a
    }

    /// Extract v[1] (φ-coefficient). Const fn — takes self by value.
    pub const fn v1(self) -> TritInt {
        let Trit { v: [_a, b, _c] } = self;
        b
    }

    /// Extract v[2] (ω-coefficient). Const fn — takes self by value.
    pub const fn v2(self) -> TritInt {
        let Trit { v: [_a, _b, c] } = self;
        c
    }
}

// ══════════════════════════════════════════════════════════════
// FRAMEWORK CONSTANTS
// ══════════════════════════════════════════════════════════════

/// Archimedean solid circumradius squared: R² = 14 + 5φ.
/// Integer part (14) IS π_Salvi. φ-coefficient (5) IS the pentagon generator.
/// Norm: N(14, 5) = 14² + 14×5 − 5² = 196 + 70 − 25 = 241 (prime, irreducible).
pub const R_SQUARED_T: Trit = Trit::golden(TritInt::from_u64(14), TritInt::from_u64(5));

/// Full circle: R₆ = 364 = 111111₃ (scalar).
pub const FULL_CIRCLE_T: Trit = Trit::repunit(6);

/// Pi: π = 14 = 112₃ (scalar).
pub const PI_T: Trit = Trit::scalar(TritInt::from_trits(&[2, 1, 1]));

/// Half-turn: 182 = π × R₃ (scalar).
pub const HALF_TURN_T: Trit = Trit::scalar(TritInt::from_u64(182));

/// φ² = 1 + φ = (1, 1) — the defining relation as a Trit constant.
pub const PHI_SQUARED_T: Trit = Trit::golden(TritInt::one(), TritInt::one());

// ── Phase 4 _T companions (values match u32 constants in constants.rs) ──

/// R₆ = 364 = 111111₃. Full circle as Trit.
pub const REPUNIT_6_T: Trit = Trit::repunit(6);

/// π = 14 = 112₃.
pub const ROOT_X1_T: Trit = Trit::scalar(TritInt::from_trits(&[2, 1, 1]));

/// Half-turn = 182 = 20022₃.
pub const ARC_ROOT_SEMI_T: Trit = Trit::scalar(TritInt::from_u64(182));

/// Δ₂ = 729 = 1000000₃. Sponge state width, escalation multiplier.
pub const DISCRIMINANT_2_T: Trit = Trit::scalar(TritInt::from_trits(&[0, 0, 0, 0, 0, 0, 1]));

/// Icosahedral circumradius squared: 2 + φ.
pub const ICOSA_CIRCUMRADIUS_SQ_T: Trit = Trit::golden(
    TritInt::from_trits(&[2]),
    TritInt::from_trits(&[1]),
);

/// Duty cycle numerator = 1. HModal dispatch ratio.
pub const DUTY_NUM_T: Trit = Trit::scalar(TritInt::from_u64(1));

/// Duty cycle denominator = 4 = 11₃.
pub const DUTY_DEN_T: Trit = Trit::scalar(TritInt::from_trits(&[1, 1]));

// ══════════════════════════════════════════════════════════════
// COMPONENT-WISE ARITHMETIC (always valid, algebra-independent)
// ══════════════════════════════════════════════════════════════

impl Trit {
    /// Component-wise addition. Always valid regardless of which algebra is active.
    pub fn add(&self, other: &Trit) -> Trit {
        Trit {
            v: [
                TritInt::add(&self.v[0], &other.v[0]),
                TritInt::add(&self.v[1], &other.v[1]),
                TritInt::add(&self.v[2], &other.v[2]),
            ]
        }
    }

    /// Component-wise subtraction. Panics if any component of other exceeds
    /// the corresponding component of self (unsigned underflow). Phase 3
    /// provides signed arithmetic for operations requiring negative intermediates.
    pub fn sub(&self, other: &Trit) -> Trit {
        Trit {
            v: [
                TritInt::sub(&self.v[0], &other.v[0]),
                TritInt::sub(&self.v[1], &other.v[1]),
                TritInt::sub(&self.v[2], &other.v[2]),
            ]
        }
    }

    /// Multiply all three vectors by a TritInt scalar.
    /// Does NOT require the Trit to be scalar — scales any element uniformly.
    pub fn scale(&self, scalar: &TritInt) -> Trit {
        Trit {
            v: [
                TritInt::mul(&self.v[0], scalar),
                TritInt::mul(&self.v[1], scalar),
                TritInt::mul(&self.v[2], scalar),
            ]
        }
    }
}

// ══════════════════════════════════════════════════════════════
// ALGEBRA-SPECIFIC MULTIPLICATION
// ══════════════════════════════════════════════════════════════

impl Trit {
    /// ℤ[φ] multiplication. Applies the reduction rule φ² = φ + 1.
    ///
    /// (a₁ + b₁φ)(a₂ + b₂φ) = (a₁a₂ + b₁b₂) + (a₁b₂ + a₂b₁ + b₁b₂)φ
    ///
    /// Uses 4 TritInt multiplications and 3 TritInt additions.
    /// The reduction is addition-only, so unsigned TritInt handles it cleanly.
    ///
    /// Panics if either operand has a non-zero ω-component (v[2] ≠ 0).
    pub fn mul_golden(&self, other: &Trit) -> Trit {
        assert!(self.v[2].is_zero(), "mul_golden: self has non-zero ω-component");
        assert!(other.v[2].is_zero(), "mul_golden: other has non-zero ω-component");

        let a1a2 = TritInt::mul(&self.v[0], &other.v[0]);
        let b1b2 = TritInt::mul(&self.v[1], &other.v[1]);
        let a1b2 = TritInt::mul(&self.v[0], &other.v[1]);
        let a2b1 = TritInt::mul(&other.v[0], &self.v[1]);

        Trit {
            v: [
                // Integer part: a₁a₂ + b₁b₂ (from φ² = φ + 1 reduction)
                TritInt::add(&a1a2, &b1b2),
                // φ-coefficient: a₁b₂ + a₂b₁ + b₁b₂
                TritInt::add(&TritInt::add(&a1b2, &a2b1), &b1b2),
                // ω-component stays zero
                TritInt::zero(),
            ]
        }
    }

    /// Plain integer multiplication. Multiplies v[0] components only.
    ///
    /// Panics if either operand has non-zero φ or ω components.
    /// For multiplying any Trit by a TritInt without this restriction, use `scale`.
    pub fn mul_scalar(&self, other: &Trit) -> Trit {
        assert!(self.is_scalar(), "mul_scalar: self is not scalar");
        assert!(other.is_scalar(), "mul_scalar: other is not scalar");
        Trit::scalar(TritInt::mul(&self.v[0], &other.v[0]))
    }
}

// ══════════════════════════════════════════════════════════════
// NORMS
// ══════════════════════════════════════════════════════════════

impl Trit {
    /// ℤ[φ] norm: N(a + bφ) = a² + ab − b².
    ///
    /// Returns a scalar Trit. The norm maps ℤ[φ] → ℤ.
    ///
    /// Panics if:
    /// - The ω-component is non-zero (v[2] ≠ 0)
    /// - The norm is negative (b² > a² + ab), which occurs for elements
    ///   with large φ-coefficient relative to integer part.
    ///   All framework constants produce positive norms.
    pub fn norm_golden(&self) -> Trit {
        assert!(self.v[2].is_zero(), "norm_golden: non-zero ω-component");

        let a = &self.v[0];
        let b = &self.v[1];
        let a_sq = TritInt::mul(a, a);
        let ab = TritInt::mul(a, b);
        let b_sq = TritInt::mul(b, b);

        let sum = TritInt::add(&a_sq, &ab); // a² + ab
        assert!(sum >= b_sq, "norm_golden: negative norm (b² > a² + ab)");

        Trit::scalar(TritInt::sub(&sum, &b_sq)) // a² + ab − b²
    }
}

// ══════════════════════════════════════════════════════════════
// EISENSTEIN ARITHMETIC — GF(3) LEVEL (Phase 3)
//
// ℤ[ω] multiplication and norm, operating at the GF(3) level
// (individual trits, mod 3). The defining relation ω²+ω+1=0
// produces ω² = −1−ω ≡ 2+2ω (mod 3). The existing gf3_sub
// handles this via (a+3−b) — subtraction mod 3 never underflows.
//
// General signed Eisenstein arithmetic on multi-digit values is
// future work requiring SignedTritInt or balanced ternary storage.
// ══════════════════════════════════════════════════════════════

impl Trit {
    /// ℤ[ω] multiplication mod 3. Per-trit, using existing GF(3) ops.
    ///
    /// (a₁ + c₁ω)(a₂ + c₂ω) = (a₁a₂ − c₁c₂) + (a₁c₂ + a₂c₁ − c₁c₂)ω
    ///
    /// In mod-3 arithmetic (gf3_sub never underflows):
    ///   integer part: gf3_sub(gf3_mul(a₁,a₂), gf3_mul(c₁,c₂))
    ///   ω-coefficient: gf3_sub(gf3_add(gf3_mul(a₁,c₂), gf3_mul(a₂,c₁)), gf3_mul(c₁,c₂))
    ///
    /// Asserts both operands have v[1]=0 (pure Eisenstein or scalar).
    /// Asserts both operands are GF(3)-scale (v[0] and v[2] each ≤ 2).
    pub fn mul_eisenstein(&self, other: &Trit) -> Trit {
        assert!(self.v[1].is_zero(), "mul_eisenstein: self has non-zero φ-component");
        assert!(other.v[1].is_zero(), "mul_eisenstein: other has non-zero φ-component");

        let a1 = self.v[0].to_decimal() as u8;
        let c1 = self.v[2].to_decimal() as u8;
        let a2 = other.v[0].to_decimal() as u8;
        let c2 = other.v[2].to_decimal() as u8;

        assert!(a1 <= 2, "mul_eisenstein: self v[0] exceeds GF(3) scale (> 2)");
        assert!(c1 <= 2, "mul_eisenstein: self v[2] exceeds GF(3) scale (> 2)");
        assert!(a2 <= 2, "mul_eisenstein: other v[0] exceeds GF(3) scale (> 2)");
        assert!(c2 <= 2, "mul_eisenstein: other v[2] exceeds GF(3) scale (> 2)");

        // Integer part: (a₁a₂ − c₁c₂) mod 3
        let result_a = gf3_sub(gf3_mul(a1, a2), gf3_mul(c1, c2));

        // ω-coefficient: (a₁c₂ + a₂c₁ − c₁c₂) mod 3
        let result_c = gf3_sub(gf3_add(gf3_mul(a1, c2), gf3_mul(a2, c1)), gf3_mul(c1, c2));

        Trit::eisenstein(
            TritInt::from_u64(result_a as u64),
            TritInt::from_u64(result_c as u64),
        )
    }

    /// ℤ[ω] norm mod 3: N(a + cω) = a² − ac + c².
    ///
    /// In mod-3: gf3_sub(gf3_add(gf3_square(a), gf3_square(c)), gf3_mul(a, c)).
    /// Computation order (a²+c²)−ac avoids intermediate underflow since
    /// a²+c² ≥ ac for all non-negative a, c.
    ///
    /// Returns scalar Trit. Asserts v[1]=0 and GF(3)-scale.
    pub fn norm_eisenstein(&self) -> Trit {
        assert!(self.v[1].is_zero(), "norm_eisenstein: non-zero φ-component");

        let a = self.v[0].to_decimal() as u8;
        let c = self.v[2].to_decimal() as u8;

        assert!(a <= 2, "norm_eisenstein: v[0] exceeds GF(3) scale (> 2)");
        assert!(c <= 2, "norm_eisenstein: v[2] exceeds GF(3) scale (> 2)");

        // (a² + c²) − ac, computed in safe order
        let a_sq = gf3_square(a);
        let c_sq = gf3_square(c);
        let ac = gf3_mul(a, c);
        let sum = gf3_add(a_sq, c_sq);
        let result = gf3_sub(sum, ac);

        Trit::scalar(TritInt::from_u64(result as u64))
    }
}

// ══════════════════════════════════════════════════════════════
// AlgebraicTrit ↔ Trit CONVERSION (Phase 3)
//
// Forward: AlgebraicTrit → Trit creates unit elements.
// Reverse: Trit → Option<AlgebraicTrit> returns Some for unit
// elements, None for multi-digit values.
// ══════════════════════════════════════════════════════════════

impl From<AlgebraicTrit> for Trit {
    /// Convert AlgebraicTrit to a unit Trit element.
    ///
    /// Zero → Trit::zero()
    /// One → Trit::one() (v[0]=1, v[1]=0, v[2]=0)
    /// Omega → Trit::eisenstein(0, 1) (v[0]=0, v[1]=0, v[2]=1)
    fn from(at: AlgebraicTrit) -> Self {
        match at {
            AlgebraicTrit::Zero => Trit::zero(),
            AlgebraicTrit::One => Trit::one(),
            AlgebraicTrit::Omega => Trit::eisenstein(TritInt::zero(), TritInt::one()),
        }
    }
}

impl Trit {
    /// Try to convert this Trit to an AlgebraicTrit.
    ///
    /// Returns Some(variant) for unit elements:
    /// - (0, 0, 0) → Some(Zero)
    /// - (1, 0, 0) → Some(One)
    /// - (0, 0, 1) → Some(Omega)
    ///
    /// Returns None for all other values (non-unit, multi-digit,
    /// golden components, etc.)
    pub fn to_algebraic_trit(&self) -> Option<AlgebraicTrit> {
        let a = self.v[0].to_decimal();
        let b = self.v[1].to_decimal();
        let c = self.v[2].to_decimal();

        match (a, b, c) {
            (0, 0, 0) => Some(AlgebraicTrit::Zero),
            (1, 0, 0) => Some(AlgebraicTrit::One),
            (0, 0, 1) => Some(AlgebraicTrit::Omega),
            _ => None,
        }
    }
}

// ══════════════════════════════════════════════════════════════
// ACCESSORS
// ══════════════════════════════════════════════════════════════

impl Trit {
    /// True if all three components are zero.
    pub fn is_zero(&self) -> bool {
        self.v[0].is_zero() && self.v[1].is_zero() && self.v[2].is_zero()
    }

    /// True if v[1] and v[2] are both zero (pure integer).
    pub fn is_scalar(&self) -> bool {
        self.v[1].is_zero() && self.v[2].is_zero()
    }

    /// True if v[1] is non-zero and v[2] is zero (ℤ[φ] element with live φ part).
    pub fn is_golden(&self) -> bool {
        !self.v[1].is_zero() && self.v[2].is_zero()
    }

    /// True if v[2] is non-zero and v[1] is zero (ℤ[ω] element with live ω part).
    pub fn is_eisenstein(&self) -> bool {
        self.v[1].is_zero() && !self.v[2].is_zero()
    }

    /// Reference to v[0] (integer part).
    pub fn integer_part(&self) -> &TritInt { &self.v[0] }

    /// Reference to v[1] (φ-coefficient).
    pub fn golden_part(&self) -> &TritInt { &self.v[1] }

    /// Reference to v[2] (ω-coefficient).
    pub fn eisenstein_part(&self) -> &TritInt { &self.v[2] }

    /// Reference to any component by index.
    pub fn vector(&self, i: usize) -> &TritInt { &self.v[i] }
}

// ══════════════════════════════════════════════════════════════
// BOUNDARY CROSSINGS
// ══════════════════════════════════════════════════════════════

impl Trit {
    /// Evaluate as f64: a + b·φ + c·ω_real.
    ///
    /// BOUNDARY CROSSING — exits exact ternary arithmetic into floating point.
    /// φ = (1+√5)/2, ω_real = Re(ω) = −1/2. Both derived from their defining
    /// algebraic relations (φ²=φ+1 and ω²+ω+1=0), independent of the 364° circle.
    pub fn to_f64(&self) -> f64 {
        const PHI: f64 = 1.618_033_988_749_895;
        const OMEGA_REAL: f64 = -0.5;
        let a = self.v[0].to_decimal() as f64;
        let b = self.v[1].to_decimal() as f64;
        let c = self.v[2].to_decimal() as f64;
        a + b * PHI + c * OMEGA_REAL
    }

    /// Convert a scalar Trit to u64. Returns Err if the Trit is not scalar
    /// (has non-zero φ or ω components).
    pub fn to_u64(&self) -> Result<u64, Overflow> {
        if !self.is_scalar() {
            return Err(Overflow(0)); // 0 signals non-scalar, not a bit-width
        }
        self.v[0].to_u64()
    }
}

// ══════════════════════════════════════════════════════════════
// TRAIT IMPLEMENTATIONS
// ══════════════════════════════════════════════════════════════

// ── Clone ───────────────────────────────────────────────────

impl Clone for Trit {
    fn clone(&self) -> Self {
        Trit {
            v: [self.v[0].clone(), self.v[1].clone(), self.v[2].clone()]
        }
    }
}

// ── Display ─────────────────────────────────────────────────

impl fmt::Display for Trit {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.is_zero() {
            return write!(f, "0₃");
        }

        let mut wrote_term = false;

        // Integer part
        if !self.v[0].is_zero() {
            write!(f, "{}", self.v[0])?;
            wrote_term = true;
        }

        // φ-coefficient
        if !self.v[1].is_zero() {
            if wrote_term { write!(f, " + ")?; }
            write!(f, "{}φ", self.v[1])?;
            wrote_term = true;
        }

        // ω-coefficient
        if !self.v[2].is_zero() {
            if wrote_term { write!(f, " + ")?; }
            write!(f, "{}ω", self.v[2])?;
        }

        Ok(())
    }
}

impl fmt::Debug for Trit {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Trit({})", self)
    }
}

// ── PartialEq, Eq ───────────────────────────────────────────

impl PartialEq for Trit {
    fn eq(&self, other: &Self) -> bool {
        self.v[0] == other.v[0] && self.v[1] == other.v[1] && self.v[2] == other.v[2]
    }
}

impl Eq for Trit {}

// ── Hash ────────────────────────────────────────────────────

impl Hash for Trit {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.v[0].hash(state);
        self.v[1].hash(state);
        self.v[2].hash(state);
    }
}

// ── Add / Sub operator traits ───────────────────────────────

impl Add for Trit {
    type Output = Trit;
    fn add(self, rhs: Trit) -> Trit { Trit::add(&self, &rhs) }
}

impl Add for &Trit {
    type Output = Trit;
    fn add(self, rhs: &Trit) -> Trit { Trit::add(self, rhs) }
}

impl Sub for Trit {
    type Output = Trit;
    fn sub(self, rhs: Trit) -> Trit { Trit::sub(&self, &rhs) }
}

impl Sub for &Trit {
    type Output = Trit;
    fn sub(self, rhs: &Trit) -> Trit { Trit::sub(self, rhs) }
}

impl AddAssign for Trit {
    fn add_assign(&mut self, rhs: Trit) { *self = Trit::add(self, &rhs); }
}

impl SubAssign for Trit {
    fn sub_assign(&mut self, rhs: Trit) { *self = Trit::sub(self, &rhs); }
}

// ══════════════════════════════════════════════════════════════
// PHASE 5: ZEROIZE
// ══════════════════════════════════════════════════════════════

impl Zeroize for Trit {
    fn zeroize(&mut self) {
        self.v[0].zeroize();
        self.v[1].zeroize();
        self.v[2].zeroize();
    }
}

// ══════════════════════════════════════════════════════════════
// PHASE 5: SERDE (behind #[cfg(feature = "serde")])
//
// Trit serializes as { "v": [repr_c_0, repr_c_1, repr_c_2] }.
// Each component is a TritInt serialized as a Rep C array.
// Deserialization uses try_from_repr_c — never panics.
// ══════════════════════════════════════════════════════════════

#[cfg(feature = "serde")]
impl serde::Serialize for Trit {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use serde::ser::SerializeStruct;
        let mut s = serializer.serialize_struct("Trit", 1)?;
        let arrays: [Vec<u8>; 3] = [
            self.v[0].to_repr_c(),
            self.v[1].to_repr_c(),
            self.v[2].to_repr_c(),
        ];
        s.serialize_field("v", &arrays)?;
        s.end()
    }
}

#[cfg(feature = "serde")]
impl<'de> serde::Deserialize<'de> for Trit {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        use serde::de::{self, MapAccess, Visitor};
        use crate::trit_int::TritInt;

        struct TritVisitor;

        impl<'de> Visitor<'de> for TritVisitor {
            type Value = Trit;

            fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
                f.write_str("a Trit with field 'v' containing three Rep C arrays")
            }

            fn visit_map<A: MapAccess<'de>>(self, mut map: A) -> Result<Trit, A::Error> {
                let mut v: Option<Vec<Vec<u8>>> = None;
                while let Some(key) = map.next_key::<String>()? {
                    match key.as_str() {
                        "v" => {
                            if v.is_some() {
                                return Err(de::Error::duplicate_field("v"));
                            }
                            v = Some(map.next_value()?);
                        }
                        other => return Err(de::Error::unknown_field(other, &["v"])),
                    }
                }
                let v = v.ok_or_else(|| de::Error::missing_field("v"))?;
                if v.len() != 3 {
                    return Err(de::Error::custom(
                        format!("expected 3 Rep C arrays, got {}", v.len())
                    ));
                }
                let v0 = TritInt::try_from_repr_c(&v[0]).map_err(de::Error::custom)?;
                let v1 = TritInt::try_from_repr_c(&v[1]).map_err(de::Error::custom)?;
                let v2 = TritInt::try_from_repr_c(&v[2]).map_err(de::Error::custom)?;
                Ok(Trit::new(v0, v1, v2))
            }
        }

        deserializer.deserialize_struct("Trit", &["v"], TritVisitor)
    }
}

// ══════════════════════════════════════════════════════════════
// COMPILE-TIME CONST ASSERTIONS
// ══════════════════════════════════════════════════════════════

const _: () = {
    // R² = 14 + 5φ — integer part is π
    assert!(R_SQUARED_T.v0().to_u32_const() == 14);
    assert!(R_SQUARED_T.v1().to_u32_const() == 5);
    assert!(R_SQUARED_T.v2().to_u32_const() == 0);

    // Full circle = 364 (scalar)
    assert!(FULL_CIRCLE_T.v0().to_u32_const() == 364);
    assert!(FULL_CIRCLE_T.v1().to_u32_const() == 0);

    // Pi = 14
    assert!(PI_T.v0().to_u32_const() == 14);

    // Half-turn = 182
    assert!(HALF_TURN_T.v0().to_u32_const() == 182);

    // φ² = 1 + φ
    assert!(PHI_SQUARED_T.v0().to_u32_const() == 1);
    assert!(PHI_SQUARED_T.v1().to_u32_const() == 1);

    // Phase 4: _T companions verified against u32 values in constants.rs
    assert!(REPUNIT_6_T.v0().to_u32_const() == constants::REPUNIT_6);
    assert!(ROOT_X1_T.v0().to_u32_const() == constants::ROOT_X1);
    assert!(ARC_ROOT_SEMI_T.v0().to_u32_const() == constants::ARC_ROOT_SEMI);
    assert!(DISCRIMINANT_2_T.v0().to_u32_const() == constants::DISCRIMINANT_2);
    assert!(DUTY_NUM_T.v0().to_u32_const() == constants::DUTY_NUM);
    assert!(DUTY_DEN_T.v0().to_u32_const() == constants::DUTY_DEN);

    // Verify all _T companions are scalar (v[1] = v[2] = 0)
    assert!(REPUNIT_6_T.v1().to_u32_const() == 0);
    assert!(REPUNIT_6_T.v2().to_u32_const() == 0);
    assert!(ROOT_X1_T.v1().to_u32_const() == 0);
    assert!(DISCRIMINANT_2_T.v1().to_u32_const() == 0);

    // ICOSA_CIRCUMRADIUS_SQ_T is golden (not scalar)
    assert!(ICOSA_CIRCUMRADIUS_SQ_T.v0().to_u32_const() == 2);
    assert!(ICOSA_CIRCUMRADIUS_SQ_T.v1().to_u32_const() == 1);
    assert!(ICOSA_CIRCUMRADIUS_SQ_T.v2().to_u32_const() == 0);
};

// ══════════════════════════════════════════════════════════════
// TESTS
// ══════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    // ── Helpers ──────────────────────────────────────────────

    /// Create a golden Trit from decimal values for concise tests.
    fn g(a: u64, b: u64) -> Trit {
        Trit::golden(TritInt::from_u64(a), TritInt::from_u64(b))
    }

    /// Create a scalar Trit from a decimal value.
    fn s(val: u64) -> Trit {
        Trit::from_u64(val)
    }

    /// φ as a Trit value: 0 + 1·φ.
    fn phi() -> Trit {
        Trit::golden(TritInt::zero(), TritInt::one())
    }

    // ── Constructors ────────────────────────────────────────

    #[test]
    fn zero_is_zero() {
        let z = Trit::zero();
        assert!(z.is_zero());
        assert!(z.is_scalar());
        assert_eq!(z.v[0].to_decimal(), 0);
    }

    #[test]
    fn one_is_scalar_one() {
        let o = Trit::one();
        assert!(!o.is_zero());
        assert!(o.is_scalar());
        assert_eq!(o.v[0].to_decimal(), 1);
    }

    #[test]
    fn scalar_constructor() {
        let t = Trit::scalar(TritInt::from_u64(364));
        assert!(t.is_scalar());
        assert_eq!(t.v[0].to_decimal(), 364);
        assert!(t.v[1].is_zero());
        assert!(t.v[2].is_zero());
    }

    #[test]
    fn golden_constructor() {
        let t = g(14, 5);
        assert!(t.is_golden());
        assert!(!t.is_scalar());
        assert_eq!(t.v[0].to_decimal(), 14);
        assert_eq!(t.v[1].to_decimal(), 5);
        assert!(t.v[2].is_zero());
    }

    #[test]
    fn eisenstein_constructor() {
        let t = Trit::eisenstein(TritInt::from_u64(3), TritInt::from_u64(2));
        assert!(t.is_eisenstein());
        assert_eq!(t.v[0].to_decimal(), 3);
        assert!(t.v[1].is_zero());
        assert_eq!(t.v[2].to_decimal(), 2);
    }

    #[test]
    fn new_full_constructor() {
        let t = Trit::new(TritInt::from_u64(1), TritInt::from_u64(2), TritInt::from_u64(3));
        assert!(!t.is_scalar());
        assert!(!t.is_golden());
        assert!(!t.is_eisenstein());
        assert_eq!(t.v[0].to_decimal(), 1);
        assert_eq!(t.v[1].to_decimal(), 2);
        assert_eq!(t.v[2].to_decimal(), 3);
    }

    #[test]
    fn from_trits_makes_scalar() {
        let t = Trit::from_trits(&[2, 1, 1]); // 14
        assert!(t.is_scalar());
        assert_eq!(t.v[0].to_decimal(), 14);
    }

    #[test]
    fn repunit_makes_scalar() {
        let t = Trit::repunit(6);
        assert!(t.is_scalar());
        assert_eq!(t.v[0].to_decimal(), 364);
    }

    #[test]
    fn from_u64_makes_scalar() {
        let t = Trit::from_u64(182);
        assert!(t.is_scalar());
        assert_eq!(t.v[0].to_decimal(), 182);
    }

    // ── Component-wise add / sub ────────────────────────────

    #[test]
    fn add_scalars() {
        let result = Trit::add(&s(13), &s(1));
        assert_eq!(result.v[0].to_decimal(), 14);
        assert!(result.is_scalar());
    }

    #[test]
    fn add_golden_values() {
        let a = g(14, 5);
        let b = g(3, 2);
        let result = Trit::add(&a, &b);
        assert_eq!(result.v[0].to_decimal(), 17);
        assert_eq!(result.v[1].to_decimal(), 7);
        assert!(result.v[2].is_zero());
    }

    #[test]
    fn sub_scalars() {
        let result = Trit::sub(&s(182), &s(14));
        assert_eq!(result.v[0].to_decimal(), 168);
    }

    #[test]
    fn add_sub_identity() {
        let a = g(14, 5);
        let zero = Trit::zero();
        assert_eq!(Trit::add(&a, &zero), a);
        assert_eq!(Trit::sub(&a, &zero), a);
    }

    // ── Scale ───────────────────────────────────────────────

    #[test]
    fn scale_golden_by_integer() {
        let t = g(2, 3);
        let scalar = TritInt::from_u64(5);
        let result = t.scale(&scalar);
        assert_eq!(result.v[0].to_decimal(), 10);
        assert_eq!(result.v[1].to_decimal(), 15);
        assert!(result.v[2].is_zero());
    }

    #[test]
    fn scale_by_zero() {
        let t = g(14, 5);
        let result = t.scale(&TritInt::zero());
        assert!(result.is_zero());
    }

    // ── mul_golden: φ² = φ + 1 ──────────────────────────────

    #[test]
    fn phi_squared_is_phi_plus_one() {
        // φ × φ = (0 + 1φ) × (0 + 1φ) = (0·0 + 1·1) + (0·1 + 0·1 + 1·1)φ = 1 + φ
        let result = phi().mul_golden(&phi());
        assert_eq!(result.v[0].to_decimal(), 1);
        assert_eq!(result.v[1].to_decimal(), 1);
        assert!(result.v[2].is_zero(), "v[2] must stay zero through mul_golden");
    }

    #[test]
    fn phi_cubed_is_one_plus_two_phi() {
        // φ³ = φ · φ² = φ · (1 + φ) = φ + φ² = φ + 1 + φ = 1 + 2φ
        let phi_sq = phi().mul_golden(&phi());
        let result = phi().mul_golden(&phi_sq);
        assert_eq!(result.v[0].to_decimal(), 1);
        assert_eq!(result.v[1].to_decimal(), 2);
        assert!(result.v[2].is_zero(), "v[2] must stay zero through mul_golden");
    }

    #[test]
    fn fibonacci_powers_of_phi() {
        // φⁿ = F(n-1) + F(n)·φ  where F is the Fibonacci sequence
        let expected: [(u64, u64); 6] = [
            (1, 0),  // φ⁰ = 1
            (0, 1),  // φ¹ = φ
            (1, 1),  // φ² = 1 + φ
            (1, 2),  // φ³ = 1 + 2φ
            (2, 3),  // φ⁴ = 2 + 3φ
            (3, 5),  // φ⁵ = 3 + 5φ
        ];

        let mut power = Trit::one();
        for (n, (exp_a, exp_b)) in expected.iter().enumerate() {
            assert_eq!(power.v[0].to_decimal(), *exp_a, "φ^{}: integer part wrong", n);
            assert_eq!(power.v[1].to_decimal(), *exp_b, "φ^{}: φ-coefficient wrong", n);
            assert!(power.v[2].is_zero(), "φ^{}: v[2] must stay zero", n);
            power = power.mul_golden(&phi());
        }
    }

    #[test]
    fn mul_golden_by_one_is_identity() {
        let one = Trit::one();
        let r_sq = g(14, 5);
        let result = r_sq.mul_golden(&one);
        assert_eq!(result, r_sq);
        assert!(result.v[2].is_zero(), "v[2] must stay zero through mul_golden");
    }

    #[test]
    fn mul_golden_by_scalar() {
        // 3 × (14 + 5φ) = 42 + 15φ
        let three = s(3);
        let result = three.mul_golden(&g(14, 5));
        assert_eq!(result.v[0].to_decimal(), 42);
        assert_eq!(result.v[1].to_decimal(), 15);
        assert!(result.v[2].is_zero(), "v[2] must stay zero through mul_golden");
    }

    #[test]
    fn mul_golden_commutativity() {
        let a = g(14, 5);
        let b = g(3, 2);
        let ab = a.mul_golden(&b);
        let ba = b.mul_golden(&a);
        assert_eq!(ab, ba);
        assert!(ab.v[2].is_zero(), "v[2] must stay zero through mul_golden");
    }

    #[test]
    fn mul_golden_associativity() {
        let a = g(2, 1);
        let b = g(3, 1);
        let c = g(1, 2);
        let ab_c = a.mul_golden(&b).mul_golden(&c);
        let a_bc = a.mul_golden(&b.mul_golden(&c));
        assert_eq!(ab_c, a_bc);
        assert!(ab_c.v[2].is_zero(), "v[2] must stay zero through mul_golden");
    }

    // ── mul_scalar ──────────────────────────────────────────

    #[test]
    fn mul_scalar_basic() {
        let result = s(14).mul_scalar(&s(13));
        assert_eq!(result.v[0].to_decimal(), 182);
        assert!(result.is_scalar());
    }

    // ── norm_golden ─────────────────────────────────────────

    #[test]
    fn norm_golden_r_squared() {
        // N(14 + 5φ) = 14² + 14×5 − 5² = 196 + 70 − 25 = 241
        let norm = g(14, 5).norm_golden();
        assert!(norm.is_scalar());
        assert_eq!(norm.v[0].to_decimal(), 241);
    }

    #[test]
    fn norm_golden_of_phi() {
        // N(0 + 1φ) = 0 + 0 − 1 = −1 → should panic (negative norm)
        // Tested separately with should_panic
    }

    #[test]
    fn norm_golden_of_one() {
        // N(1 + 0φ) = 1 + 0 − 0 = 1
        let norm = Trit::one().norm_golden();
        assert_eq!(norm.v[0].to_decimal(), 1);
    }

    #[test]
    fn norm_golden_of_integer() {
        // N(7 + 0φ) = 49 + 0 − 0 = 49
        let norm = s(7).norm_golden();
        assert_eq!(norm.v[0].to_decimal(), 49);
    }

    #[test]
    fn norm_golden_241_is_prime() {
        // N(R²) = 241 — verify primality via trial division
        let n: u64 = 241;
        let is_prime = (2..16).all(|d| n % d != 0);
        assert!(is_prime, "241 should be prime");
    }

    // ── Accessors ───────────────────────────────────────────

    #[test]
    fn accessor_integer_part() {
        let t = g(14, 5);
        assert_eq!(t.integer_part().to_decimal(), 14);
    }

    #[test]
    fn accessor_golden_part() {
        let t = g(14, 5);
        assert_eq!(t.golden_part().to_decimal(), 5);
    }

    #[test]
    fn accessor_eisenstein_part() {
        let t = Trit::eisenstein(TritInt::from_u64(3), TritInt::from_u64(7));
        assert_eq!(t.eisenstein_part().to_decimal(), 7);
    }

    #[test]
    fn accessor_vector_indexing() {
        let t = Trit::new(TritInt::from_u64(1), TritInt::from_u64(2), TritInt::from_u64(3));
        assert_eq!(t.vector(0).to_decimal(), 1);
        assert_eq!(t.vector(1).to_decimal(), 2);
        assert_eq!(t.vector(2).to_decimal(), 3);
    }

    // ── Boundary crossings ──────────────────────────────────

    #[test]
    fn to_f64_golden() {
        // 1 + 1φ = 1 + (1+√5)/2 = (3+√5)/2 ≈ 2.618
        let t = g(1, 1);
        let val = t.to_f64();
        assert!((val - 2.618_033_988_749_895).abs() < 1e-10);
    }

    #[test]
    fn to_f64_r_squared() {
        // R² = 14 + 5φ ≈ 22.090
        let val = R_SQUARED_T.to_f64();
        assert!((val - 22.090_169_943_749_47).abs() < 1e-10);
    }

    #[test]
    fn to_u64_scalar() {
        assert_eq!(s(364).to_u64().unwrap(), 364);
    }

    #[test]
    fn to_u64_non_scalar_errors() {
        assert!(g(14, 5).to_u64().is_err());
    }

    // ── Display ─────────────────────────────────────────────

    #[test]
    fn display_zero() {
        assert_eq!(format!("{}", Trit::zero()), "0₃");
    }

    #[test]
    fn display_scalar() {
        assert_eq!(format!("{}", s(14)), "112₃");
    }

    #[test]
    fn display_golden() {
        let t = g(14, 5);
        assert_eq!(format!("{}", t), "112₃ + 12₃φ");
    }

    #[test]
    fn display_pure_phi() {
        let t = phi();
        assert_eq!(format!("{}", t), "1₃φ");
    }

    #[test]
    fn display_eisenstein() {
        let t = Trit::eisenstein(TritInt::from_u64(7), TritInt::from_u64(2));
        assert_eq!(format!("{}", t), "21₃ + 2₃ω");
    }

    // ── Operator traits ─────────────────────────────────────

    #[test]
    fn operator_add() {
        let c = s(13) + s(1);
        assert_eq!(c.v[0].to_decimal(), 14);
    }

    #[test]
    fn operator_sub() {
        let c = s(182) - s(40);
        assert_eq!(c.v[0].to_decimal(), 142);
    }

    #[test]
    fn operator_add_ref() {
        let a = s(13);
        let b = s(1);
        let c = &a + &b;
        assert_eq!(c.v[0].to_decimal(), 14);
    }

    #[test]
    fn operator_add_assign() {
        let mut a = s(13);
        a += s(1);
        assert_eq!(a.v[0].to_decimal(), 14);
    }

    // ── Equality and hashing ────────────────────────────────

    #[test]
    fn equality_same_values() {
        assert_eq!(g(14, 5), g(14, 5));
        assert_ne!(g(14, 5), g(14, 6));
        assert_ne!(g(14, 5), s(14));
    }

    #[test]
    fn hash_consistency() {
        use std::collections::HashSet;
        let mut set = HashSet::new();
        set.insert(g(14, 5));
        assert!(set.contains(&g(14, 5)));
        assert!(!set.contains(&g(14, 6)));
    }

    // ── Should-panic tests ──────────────────────────────────

    #[test]
    #[should_panic(expected = "negative norm")]
    fn norm_golden_negative_panics() {
        // N(0 + 1φ) = 0 + 0 − 1 = −1 → negative, panic
        phi().norm_golden();
    }

    #[test]
    #[should_panic(expected = "not scalar")]
    fn mul_scalar_non_scalar_panics() {
        g(14, 5).mul_scalar(&s(3));
    }

    #[test]
    #[should_panic(expected = "non-zero ω-component")]
    fn mul_golden_with_omega_panics() {
        let with_omega = Trit::new(TritInt::one(), TritInt::one(), TritInt::one());
        with_omega.mul_golden(&Trit::one());
    }

    #[test]
    #[should_panic(expected = "non-zero ω-component")]
    fn norm_golden_with_omega_panics() {
        let with_omega = Trit::eisenstein(TritInt::from_u64(3), TritInt::from_u64(2));
        with_omega.norm_golden();
    }

    // ── Phase 3: Eisenstein arithmetic tests ────────────────

    /// Create an Eisenstein Trit from GF(3) values for concise tests.
    fn e(a: u64, c: u64) -> Trit {
        Trit::eisenstein(TritInt::from_u64(a), TritInt::from_u64(c))
    }

    /// ω as a Trit value: 0 + 0φ + 1ω.
    fn omega() -> Trit {
        Trit::eisenstein(TritInt::zero(), TritInt::one())
    }

    #[test]
    fn omega_squared_gf3() {
        // ω² = −1 − ω ≡ 2 + 2ω (mod 3)
        // In GF(3): gf3_mul(2, 2) = 1 (since 4 mod 3 = 1)
        // So ω × ω in GF(3) single-element: element 2 × element 2 = element 1.
        // But at the two-component level (a + cω):
        // (0 + 1ω)(0 + 1ω) = (0·0 − 1·1) + (0·1 + 0·1 − 1·1)ω
        //                   = (−1) + (−1)ω
        //                   ≡ 2 + 2ω (mod 3)
        let result = omega().mul_eisenstein(&omega());
        assert_eq!(result.v[0].to_decimal(), 2, "ω²: integer part should be 2");
        assert_eq!(result.v[2].to_decimal(), 2, "ω²: ω-coefficient should be 2");
        assert!(result.v[1].is_zero(), "v[1] must stay zero through mul_eisenstein");
    }

    #[test]
    fn omega_cubed_is_one_in_eisenstein() {
        // ω³ = ω · ω² = (0+1ω)(2+2ω)
        // = (0·2 − 1·2) + (0·2 + 2·1 − 1·2)ω
        // = (−2) + (0)ω ≡ 1 + 0ω (mod 3)
        let w2 = omega().mul_eisenstein(&omega());
        let w3 = omega().mul_eisenstein(&w2);
        assert_eq!(w3.v[0].to_decimal(), 1, "ω³ should be 1");
        assert_eq!(w3.v[2].to_decimal(), 0, "ω³ should have no ω-component");
        assert!(w3.v[1].is_zero(), "v[1] must stay zero through mul_eisenstein");
    }

    #[test]
    fn mul_eisenstein_identity() {
        // 1 × x = x for all GF(3) Eisenstein values
        let one_e = Trit::one(); // (1, 0, 0)
        let vals = [Trit::zero(), Trit::one(), omega(), e(1, 1), e(2, 1), e(1, 2)];
        for x in &vals {
            let result = one_e.mul_eisenstein(x);
            assert_eq!(result, *x, "1 × {:?} should equal {:?}", x, x);
        }
    }

    #[test]
    fn mul_eisenstein_commutativity() {
        let test_pairs: [(Trit, Trit); 4] = [
            (e(1, 1), e(2, 1)),
            (e(0, 2), e(1, 0)),
            (omega(), e(2, 2)),
            (e(1, 2), e(2, 0)),
        ];
        for (a, b) in &test_pairs {
            let ab = a.mul_eisenstein(b);
            let ba = b.mul_eisenstein(a);
            assert_eq!(ab, ba, "commutativity failed for {:?} × {:?}", a, b);
            assert!(ab.v[1].is_zero(), "v[1] must stay zero");
        }
    }

    #[test]
    fn mul_eisenstein_associativity() {
        let a = e(1, 2);
        let b = e(2, 1);
        let c = e(1, 1);
        let ab_c = a.mul_eisenstein(&b).mul_eisenstein(&c);
        let a_bc = a.mul_eisenstein(&b.mul_eisenstein(&c));
        assert_eq!(ab_c, a_bc, "associativity failed");
        assert!(ab_c.v[1].is_zero(), "v[1] must stay zero");
    }

    #[test]
    fn mul_eisenstein_exhaustive_gf3() {
        // All 9 GF(3)×GF(3) pairs for the two-component form
        for a1 in 0..3u64 {
            for c1 in 0..3u64 {
                for a2 in 0..3u64 {
                    for c2 in 0..3u64 {
                        let x = e(a1, c1);
                        let y = e(a2, c2);
                        let result = x.mul_eisenstein(&y);

                        // Verify against manual formula
                        let exp_a = gf3_sub(gf3_mul(a1 as u8, a2 as u8), gf3_mul(c1 as u8, c2 as u8));
                        let exp_c = gf3_sub(
                            gf3_add(gf3_mul(a1 as u8, c2 as u8), gf3_mul(a2 as u8, c1 as u8)),
                            gf3_mul(c1 as u8, c2 as u8),
                        );

                        assert_eq!(result.v[0].to_decimal(), exp_a as u64,
                            "({},{}ω)×({},{}ω): integer part", a1, c1, a2, c2);
                        assert_eq!(result.v[2].to_decimal(), exp_c as u64,
                            "({},{}ω)×({},{}ω): ω-coefficient", a1, c1, a2, c2);
                        assert!(result.v[1].is_zero(),
                            "v[1] must stay zero: ({},{}ω)×({},{}ω)", a1, c1, a2, c2);
                    }
                }
            }
        }
    }

    #[test]
    fn norm_eisenstein_values() {
        // N(0 + 0ω) = 0
        assert_eq!(Trit::zero().norm_eisenstein().v[0].to_decimal(), 0);

        // N(1 + 0ω) = 1² − 1·0 + 0² = 1
        assert_eq!(Trit::one().norm_eisenstein().v[0].to_decimal(), 1);

        // N(0 + 1ω) = 0 − 0 + 1 = 1
        assert_eq!(omega().norm_eisenstein().v[0].to_decimal(), 1);

        // N(1 + 1ω) = 1 − 1 + 1 = 1
        assert_eq!(e(1, 1).norm_eisenstein().v[0].to_decimal(), 1);

        // N(2 + 1ω) = 4 − 2 + 1 = 3 ≡ 0 (mod 3)
        assert_eq!(e(2, 1).norm_eisenstein().v[0].to_decimal(), 0);
    }

    #[test]
    fn norm_eisenstein_multiplicativity() {
        // N(a·b) = N(a)·N(b) mod 3
        let test_triples: [(Trit, Trit); 4] = [
            (e(1, 0), e(0, 1)),
            (e(1, 1), e(2, 0)),
            (e(2, 1), e(1, 2)),
            (e(0, 2), e(2, 2)),
        ];
        for (a, b) in &test_triples {
            let n_ab = a.mul_eisenstein(b).norm_eisenstein().v[0].to_decimal() as u8;
            let n_a = a.norm_eisenstein().v[0].to_decimal() as u8;
            let n_b = b.norm_eisenstein().v[0].to_decimal() as u8;
            let n_a_times_n_b = gf3_mul(n_a, n_b);
            assert_eq!(n_ab, n_a_times_n_b,
                "N(a·b) = {} but N(a)·N(b) = {} for {:?}×{:?}", n_ab, n_a_times_n_b, a, b);
        }
    }

    // ── Phase 3: AlgebraicTrit ↔ Trit conversion tests ──────

    #[test]
    fn algebraic_trit_to_trit_forward() {
        let zero: Trit = AlgebraicTrit::Zero.into();
        assert!(zero.is_zero());

        let one: Trit = AlgebraicTrit::One.into();
        assert_eq!(one, Trit::one());

        let omega_t: Trit = AlgebraicTrit::Omega.into();
        assert_eq!(omega_t.v[0].to_decimal(), 0);
        assert_eq!(omega_t.v[2].to_decimal(), 1);
    }

    #[test]
    fn algebraic_trit_to_trit_reverse() {
        assert_eq!(Trit::zero().to_algebraic_trit(), Some(AlgebraicTrit::Zero));
        assert_eq!(Trit::one().to_algebraic_trit(), Some(AlgebraicTrit::One));
        assert_eq!(omega().to_algebraic_trit(), Some(AlgebraicTrit::Omega));
    }

    #[test]
    fn algebraic_trit_reverse_none_for_non_unit() {
        assert_eq!(g(14, 5).to_algebraic_trit(), None);
        assert_eq!(s(364).to_algebraic_trit(), None);
        assert_eq!(e(2, 2).to_algebraic_trit(), None);
    }

    #[test]
    fn algebraic_trit_roundtrip() {
        let variants = [AlgebraicTrit::Zero, AlgebraicTrit::One, AlgebraicTrit::Omega];
        for &at in &variants {
            let trit: Trit = at.into();
            let back = trit.to_algebraic_trit().unwrap();
            assert_eq!(back, at);
        }
    }

    // ── Phase 3: should-panic tests for Eisenstein ──────────

    #[test]
    #[should_panic(expected = "non-zero φ-component")]
    fn mul_eisenstein_with_phi_panics() {
        let golden = g(1, 1);
        golden.mul_eisenstein(&Trit::one());
    }

    #[test]
    #[should_panic(expected = "exceeds GF(3) scale")]
    fn mul_eisenstein_non_gf3_scale_panics() {
        let big = Trit::eisenstein(TritInt::from_u64(14), TritInt::zero());
        big.mul_eisenstein(&Trit::one());
    }

    #[test]
    #[should_panic(expected = "non-zero φ-component")]
    fn norm_eisenstein_with_phi_panics() {
        g(1, 1).norm_eisenstein();
    }

    #[test]
    #[should_panic(expected = "exceeds GF(3) scale")]
    fn norm_eisenstein_non_gf3_scale_panics() {
        Trit::eisenstein(TritInt::from_u64(5), TritInt::zero()).norm_eisenstein();
    }

    // ── Phase 5: Zeroize test ───────────────────────────────

    #[test]
    fn zeroize_clears_trit() {
        let mut t = Trit::golden(TritInt::from_u64(14), TritInt::from_u64(5));
        assert!(!t.is_zero());
        t.zeroize();
        assert!(t.is_zero());
    }

    // ── Phase 5: Serde tests ────────────────────────────────

    #[cfg(feature = "serde")]
    mod serde_tests {
        use super::*;

        #[test]
        fn serde_roundtrip_zero() {
            let t = Trit::zero();
            let json = serde_json::to_string(&t).unwrap();
            let back: Trit = serde_json::from_str(&json).unwrap();
            assert_eq!(back, t);
        }

        #[test]
        fn serde_roundtrip_scalar_364() {
            let t = Trit::from_u64(364);
            let json = serde_json::to_string(&t).unwrap();
            let back: Trit = serde_json::from_str(&json).unwrap();
            assert_eq!(back, t);
        }

        #[test]
        fn serde_roundtrip_golden_r_squared() {
            let t = Trit::golden(TritInt::from_u64(14), TritInt::from_u64(5));
            let json = serde_json::to_string(&t).unwrap();
            let back: Trit = serde_json::from_str(&json).unwrap();
            assert_eq!(back, t);
            // Verify v[0] matches 14's Rep C
            let expected_v0 = TritInt::from_u64(14).to_repr_c();
            assert!(json.contains(&format!("[{},{},{}]", expected_v0[0], expected_v0[1], expected_v0[2])));
        }

        #[test]
        fn serde_roundtrip_eisenstein() {
            let t = Trit::eisenstein(TritInt::from_u64(2), TritInt::from_u64(1));
            let json = serde_json::to_string(&t).unwrap();
            let back: Trit = serde_json::from_str(&json).unwrap();
            assert_eq!(back, t);
        }

        #[test]
        fn serde_roundtrip_full() {
            let t = Trit::new(TritInt::from_u64(7), TritInt::from_u64(3), TritInt::from_u64(2));
            let json = serde_json::to_string(&t).unwrap();
            let back: Trit = serde_json::from_str(&json).unwrap();
            assert_eq!(back, t);
        }

        #[test]
        fn serde_deserialize_rejects_forgery() {
            // v[0] contains a zero digit → forgery
            let bad = r#"{"v":[[1,0,3],[],[]]}"#;
            let result: Result<Trit, _> = serde_json::from_str(bad);
            assert!(result.is_err());
        }
    }
}
