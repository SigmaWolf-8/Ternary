# TTC v5.1.0 Pre-Read Package — Rust Source Files for Audit

  **Date**: 2026-04-13  
  **Purpose**: These 8 Rust source files were NOT included in the original TTC source zip.  
  You need to read them before writing any TritInt rANS integration code.

  ---

  ## File Inventory

  | # | File | Lines | What It Is |
  |---|------|-------|-----------|
  | 1 | trit_int.rs | 2,734 | TritInt arbitrary-precision ternary integer. Full arithmetic API, heap/inline paths, serialization. |
  | 2 | constants.rs | 1,788 | Framework constants — field sizes, magic numbers, container dimensions. |
  | 3 | plenum_checksum.rs | 398 | Checksum primitive — you read 60 lines and assumed TDNS-only. The remaining 338 may contain general-purpose data integrity logic. |
  | 4 | ctx_ans.rs | 531 | Context-1 rANS entropy coder — serialization format, how it encodes/decodes. |
  | 5 | ttc.rs | 2,754 | Full TTC container builder/parser — header, chunk payloads, build_container, parse_container. You read the header constants and build_container but not the complete picture. |
  | 6 | trit.rs | 1,438 | Core trit type — the foundation TritInt builds on. |
  | 7 | gf3_algebra.rs | 478 | GF(3) algebra — how TritInt interacts with the finite field layer. |
  | 8 | wasm_exports.rs | 636 | WASM FFI boundary — precedent for how TritInt values cross FFI boundaries. |

  **Total: 10,757 lines**

  ---

  ## Your Four Open Questions

  These files should answer all four:

  ### 1. Does TritInt have a wire serialization format, or does to_repr_c() / packed bytes serve that purpose?
  **Read**: trit_int.rs — look for to_repr_c(), to_bytes(), from_bytes(), any Serialize/Deserialize impl, and the Display trait impl.

  ### 2. What's the actual heap path capacity and what triggers it?
  **Read**: trit_int.rs — look for the struct definition. TritInt likely uses a small-buffer optimization (inline for small values, heap-allocated Vec for large). The threshold constant will tell you when it switches. Cross-reference with constants.rs for any TRITINT_INLINE_CAP or similar.

  ### 3. Is there a ternary-native integrity primitive that scales to arbitrary data sizes?
  **Read**: plenum_checksum.rs — the full 398 lines. After line 60 there may be a streaming or chunked mode. Also check if it composes with TL-Sponge for large data, or if it's purely a fixed-width TDNS address check. Cross-reference with constants.rs for checksum field sizes.

  ### 4. How does wasm_exports.rs handle TritInt across the FFI boundary?
  **Read**: wasm_exports.rs — look for any functions that accept or return TritInt. The pattern used there (probably to_repr_c() string or packed byte array) sets the precedent for how the N-API boundary should handle TritInt in the rANS integration.

  ---

  ## Cross-Reference Map

  | Question | Primary File | Supporting Files |
  |----------|-------------|-----------------|
  | Wire serialization | trit_int.rs | constants.rs, wasm_exports.rs |
  | Heap path trigger | trit_int.rs | constants.rs |
  | Integrity primitive | plenum_checksum.rs | constants.rs, trit.rs |
  | FFI boundary precedent | wasm_exports.rs | trit_int.rs |
  | rANS encoding format | ctx_ans.rs | ttc.rs |
  | Container chunk layout | ttc.rs | trit_int.rs, ctx_ans.rs |
  | TritInt algebra usage | gf3_algebra.rs | trit.rs, trit_int.rs |

  ---

  ## Recommended Reading Order

  1. **trit.rs** (1,438 lines) — Foundation. Understand the core trit type first.
  2. **trit_int.rs** (2,734 lines) — The big one. Arithmetic, heap path, serialization.
  3. **constants.rs** (1,788 lines) — Framework constants. Skim for field sizes and TritInt thresholds.
  4. **plenum_checksum.rs** (398 lines) — Quick read. Answers the integrity primitive question.
  5. **ctx_ans.rs** (531 lines) — rANS entropy coder. How serialization works today.
  6. **gf3_algebra.rs** (478 lines) — How TritInt interacts with GF(3).
  7. **wasm_exports.rs** (636 lines) — FFI boundary precedent.
  8. **ttc.rs** (2,754 lines) — Container format. You've seen parts; now read the rest.

  ---

  ## What Was In The Original TTC Source Zip (For Reference)

  The zip I sent earlier contained only the N-API bridge layer and core compression files:
  - ternary-math/napi/src/lib.rs — N-API bindings
  - ternary-math/napi/Cargo.toml — N-API crate config
  - ternary-math/napi/build.rs — Build script
  - Core TTC/sponge files from ternary-math/src/ (tlsponge385.rs, ttc.rs partial, phase_encryption.rs)

  These 8 files were NOT included because they weren't directly part of the TTC compression pipeline. But for the v5.1.0 TritInt rANS integration, they're essential context.

  ---

  ## Current State Reminder

  - **Rust toolchain**: Available (cargo 1.77.1, rustc 1.77.2)
  - **Audit fix files**: Staged in /tmp/ttc-audit/ — NOT YET APPLIED
  - **Task #120**: Proposed — apply audit fixes + write impact analysis doc
  - **TS decommission**: Held per your request
  - **TritInt rANS integration**: v5.1.0 scope, design doc at /tmp/ttc-audit/tritint-rans-integration-scope.txt
  