# Task #27 — Replit Instructions

## What This Is

WebSocket relay server upgrade. All new code is **Rust**. The existing TypeScript relay handler in `server/index.ts` is being replaced, not extended.

## Decision Needed from Salvi

**Where does the Rust relay server live?**
- **Option A (recommended):** Extend `services/inter-cube/` — add relay server modules alongside the existing relay client (`ws_relay.rs`). Same binary, same process, shared identity/keys.
- **Option B:** New standalone crate (like `ninja-exec/`). Separate binary, separate deployment.

## What Replit Wires

1. **WebSocket endpoint** — Route `/ws/relay` to the Rust relay server (wherever it lives). During migration, the TS handler can be disabled and the Rust handler takes over.
2. **Prometheus metrics** — Internal port (default 9090), endpoints `/metrics/relay` and `/metrics/all`.
3. **Health endpoint** — Returns 503 with draining body during shutdown.
4. **React frontend** — No changes needed. The relay protocol is backward-compatible. Existing clients connect the same way.

## New Cargo Dependencies

Add to whichever crate houses the relay server:
```toml
bincode = "1"
prometheus = "0.13"
```

`ternary-math`, `tokio`, `axum`, `tokio-tungstenite`, `serde`, `futures-util`, `uuid`, `hex`, `subtle` are already present in `inter-cube`.

## What Claude Produces

~13 new Rust source files (relay server modules) + 1 modified file (`ninja-exec/src/server.rs` for coprime route) + integration tests + protocol documentation.

## What Replit Does NOT Need to Do

- No TypeScript modifications for Task #27
- No N-API bindings
- No new npm packages
- No shared audit log file with the TS codebase
- The TS `capability-audit-events.ts` SHA-3 violation is a separate remediation task

## NinjaExec Change

One route added: `POST /coprime_options` accepting `{ axis, min, max }`, returning `{ values: [u64], count }`. This is for external consumers — the Rust relay server calls `ternary_math::coprime::coprime_options()` directly.

## Deployment

The Rust relay server runs as part of the inter-cube daemon (Option A) or as a standalone binary (Option B). Either way, it's a Rust process on Replit, same as NinjaExec and inter-cube today.
