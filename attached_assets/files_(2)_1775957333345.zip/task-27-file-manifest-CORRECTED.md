# Task #27 — Updated File Manifest (Rust-Native Build)

## Files Claude Builds

All new Rust source files. Location depends on Salvi's architecture decision (Option A: inter-cube, Option B: standalone crate).

### Assuming Option A — extend `services/inter-cube/`:

| File | Purpose |
|------|---------|
| `src/relay_server.rs` | Axum WebSocket relay server — main entry, connection lifecycle |
| `src/relay_error.rs` | 20 error codes as Rust enum + `make_error_response()` |
| `src/relay_audit.rs` | TIS-27 Merkle-chained audit log — `hash_hex()` direct, no N-API |
| `src/relay_topics.rs` | Topic lifecycle, pub/sub, 3-point authorization, coprime delivery |
| `src/relay_seq.rs` | Sequence numbering, tombstones, golden angle resync |
| `src/relay_capabilities.rs` | Capability negotiation, enforcement, downgrade detection |
| `src/relay_heartbeat.rs` | HModal-phased heartbeat with coprime walk scheduling |
| `src/relay_circuit.rs` | Enhanced circuit breaker with coprime probe scheduling |
| `src/relay_shutdown.rs` | Graceful shutdown with golden angle stagger |
| `src/relay_metrics.rs` | 16 Prometheus metrics on internal port |
| `src/relay_otel.rs` | OpenTelemetry spans and trace propagation |
| `src/relay_frames.rs` | Frame validation contract + Rep C encoding via `has_forgery()` |
| `src/relay_seq_store.rs` | Persistent dedup state — bincode + TLSponge-385 hash |

### Modified existing files:

| File | Change |
|------|--------|
| `ninja-exec/src/server.rs` | Add `/coprime_options` POST route |
| `services/inter-cube/src/ws_relay.rs` | New frame handlers in read loop |
| `services/inter-cube/src/main.rs` | Full jitter backoff, relay server startup |
| `services/inter-cube/src/lib.rs` | Module declarations for new relay_* modules |
| `services/inter-cube/Cargo.toml` | Add `bincode`, `prometheus` deps |

### New non-code files:

| File | Purpose |
|------|---------|
| `docs/task-27-protocol-spec.md` | Control frame JSON schemas, error code table, client pseudocode |
| `docs/task-27-runbooks.md` | Operational runbooks — curl commands, Prometheus scrape config, drain procedure |
| `tests/integration/relay_integration.rs` | Full integration test suite |

## Files NOT Modified by Task #27

All `server/services/*.ts` files — the SHA-3 remediation in TypeScript is a separate task.
