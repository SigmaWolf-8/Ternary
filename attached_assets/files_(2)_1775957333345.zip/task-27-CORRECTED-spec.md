# Task #27 — WebSocket Military-Grade Gap Closure
## CORRECTED SPEC — Rust-Native Build

**Capomastro Holdings Ltd. — Applied Physics Division**
**Sherwood Park, Alberta, Canada**

*Sed Quis Est Deus — Qui Commando IO*

---

## CRITICAL CORRECTIONS FROM ORIGINAL SPEC

### 1. THIS IS A RUST BUILD — NOT TYPESCRIPT EXTENSION

The original spec referenced TypeScript line numbers in `server/index.ts` as targets for modification. **This is WRONG.** The relay server must be built in Rust/Axum, consistent with all recent PlenumNET development:

- NinjaExec: Rust/Axum
- Inter-Cube daemon: Rust/Axum + tokio-tungstenite
- Ternary-math kernel: Rust
- All cryptography: Rust

The existing TypeScript `server/index.ts` relay code (lines 2684–3362) is **MIGRATION REFERENCE ONLY** — it documents existing protocol behavior that the Rust implementation must replicate and extend. It is NOT the build target.

**REPLIT NOTE:** The relay WebSocket server is a new Rust crate or extension of the existing `inter-cube` daemon. It runs alongside the existing Node.js server during migration, eventually replacing the TS relay handler entirely. Replit wires the WebSocket endpoint to the Rust binary.

### 2. N-API BRIDGE IS NOT NEEDED — ELIMINATED ENTIRELY

The original spec referenced `sponge_hash` via "the existing N-API bridge (ternary-math/napi/src/lib.rs:89)" for TIS-27 hashing in the relay server.

**This is WRONG.** If the relay server is Rust, it calls `ternary_math::sponge::hash_hex()` directly as a library function. No N-API. No bridge. No HTTP round-trip. No `sponge_hash(input: Buffer) → String`. Just:

```rust
use ternary_math::sponge::hash_hex;
let hash = hash_hex(event_data.as_bytes());
```

The N-API bridge (`ternary-math/napi/src/lib.rs`) continues to exist for the React frontend and any remaining TS code that needs TLSponge-385. The relay server doesn't use it.

**REPLIT NOTE:** No new N-API bindings are needed for Task #27. The Rust relay server imports `ternary-math` as a crate dependency (already in inter-cube's `Cargo.toml`).

### 3. SHA-3 PROBLEM IS SOLVED BY ARCHITECTURE

The original spec devoted significant text to migrating `crypto.createHash('sha3-256')` to TIS-27 via N-API bridge, handling v1/v2 format boundaries, shared verifier updates across 5 TypeScript files, etc.

**In a Rust relay server, SHA-3 never existed.** The Rust codebase has zero `sha3-256` calls. The audit log is written using `ternary_math::sponge::hash_hex()` from day one. There is no v1→v2 migration boundary — all entries are TIS-27 natively.

The SHA-3 violation remains in the **existing TypeScript** files (`capability-audit-events.ts`, `capability-certificates.ts`, `audit-export.service.ts`, etc.). That is a separate remediation task for the TS codebase — not part of this Rust relay build.

**REPLIT NOTE:** The Rust relay server creates its own audit log file (e.g., `relay-audit.jsonl`) using TIS-27 exclusively. It does NOT share the TS `capability-audit.jsonl` file or its SHA-3 Merkle chain. The two audit streams can be merged by a future Forma Codex log viewer.

### 4. NinjaExec coprime_options ROUTE — STILL NEEDED BUT FOR A DIFFERENT REASON

The original spec described NinjaExec as the bridge for coprime computations from the TS relay server. With a Rust relay server, coprime functions are called directly:

```rust
use ternary_math::coprime::coprime_options;
let opts = coprime_options(&axis, &min, &max);
```

However, the `coprime_options` route on NinjaExec **is still added** (Task 2) for:
- External consumers (monitoring tools, admin dashboards)
- The React frontend via HTTP
- Any remaining TS code during migration

The Rust relay server does NOT call NinjaExec for coprime — it calls the library directly.

**REPLIT NOTE:** Add the `/coprime_options` route to NinjaExec's `server.rs` as specified. The Rust relay server imports `ternary_math::coprime` directly.

---

## Architecture Decision: Where Does the Rust Relay Server Live?

Two options for Replit to decide:

### Option A: Extend inter-cube daemon
- Add WebSocket relay server to the existing `inter-cube-daemon` binary
- Already has: `ternary-math`, `tokio`, `axum`, `tokio-tungstenite`, `serde`, `futures-util`
- Already has: `ws_relay.rs` (client), `persistence.rs` (SequenceStore), `identity.rs`, `telemetry.rs`
- Pro: single binary, shared state, existing deployment
- Con: inter-cube is already large (~2,500 lines in `main.rs`)

### Option B: New `relay-server` crate
- Standalone Rust binary like NinjaExec
- Depends on `ternary-math` crate
- Pro: clean separation, independent deployment, smaller blast radius
- Con: separate process, needs its own deployment config

**Recommendation: Option A** — extend inter-cube. The relay client is already there. The relay server is the other side of the same protocol. Shared process means shared TL-DSA keys, shared identity, no IPC overhead.

**REPLIT NOTE:** Salvi to confirm Option A or B. Either way, the relay server is a Rust binary running on Replit.

---

## Corrected Task List

All task descriptions below supersede the original spec where they conflict. The original spec's protocol design (capability negotiation, topics, sequencing, tombstones, Rep C encoding, HModal phasing, golden angle stagger, coprime delivery, frame validation contract) is **unchanged** — only the implementation language and bridge architecture are corrected.

### Task 2 — Error codes, NinjaExec coprime route, Rep C frame encoding

**Language: Rust + minimal TypeScript (NinjaExec route only)**

1. **NinjaExec coprime route** (`ninja-exec/src/server.rs`): Add `/coprime_options` POST route accepting `{ axis, min, max }`, returning `Vec<u64>`. Wraps `ternary_math::coprime::coprime_options()`. Stateless, no AppState needed.

2. **Relay error codes** — define as a Rust enum in the relay server module:
   ```rust
   pub enum RelayErrorCode {
       // Existing 12
       ErrAuthFailed, ErrSignatureInvalid, ErrSignatureRequired,
       ErrAuthTimeout, ErrRateLimited, ErrFrameMalformed,
       ErrFrameTooLarge, ErrRelayTargetUnknown, ErrRelayQueueFull,
       ErrUnknownMsgType, ErrNotAuthenticated, ErrCircuitOpen,
       // New 8
       ErrCapabilityNotNegotiated, ErrCapabilityDowngrade,
       ErrTopicBackpressure, ErrTopicUnauthorized,
       ErrTopicLimitExceeded, ErrTopicReset,
       ErrResyncRateLimited, ErrResyncPayloadTooLarge,
   }
   ```
   Each variant carries `code: &str`, `message: &str`, `ws_close: Option<u16>`. `make_error_response()` produces the JSON `{type:"error", error, message, offendingType}`.

3. **Rep C frame type encoding** — in the relay frame parser:
   ```rust
   use ternary_math::gf3_algebra::has_forgery;
   
   const FRAME_TYPE_REP_C: &[(&str, u8)] = &[
       ("tombstone", 1), ("topic_reset", 2), ("topic_revoked", 3),
   ];
   
   fn parse_frame_type_rep_c(wire_type: &str) -> u8 {
       FRAME_TYPE_REP_C.iter()
           .find(|(name, _)| *name == wire_type)
           .map(|(_, rep_c)| *rep_c)
           .unwrap_or(0) // Zero = provably corrupt in Rep C
   }
   ```
   Call `has_forgery(&[rep_c])` before handler dispatch. Zero → reject with `ErrFrameMalformed`.

4. **Frame validation contract** — define `FrameSchema` struct with required fields, types, max size (64KB default). Validate all control frames server-side and document for client implementors.

**REPLIT NOTE:** `ninja-exec/src/server.rs` gets the coprime route added. Everything else is in the new Rust relay server module.

---

### Task 11 — TIS-27 Audit Logging (SIMPLIFIED)

**Original Task 11 was the most complex task — migrating SHA-3→TIS-27 across 5+ TypeScript files with v1/v2 format boundaries. In Rust, it collapses to:**

Build the relay audit log module using `ternary_math::sponge::hash_hex()` from the start. No migration. No v1/v2 boundary. No shared verifier updates. No N-API binding.

```rust
use ternary_math::sponge::hash_hex;

pub struct RelayAuditLog {
    leaves: Vec<String>,
    persist_path: PathBuf,
    last_event_hash: String,
}

impl RelayAuditLog {
    pub fn new(path: PathBuf) -> Self {
        let genesis = hash_hex(b"relay-audit-genesis");
        Self { leaves: Vec::new(), persist_path: path, last_event_hash: genesis }
    }
    
    pub fn record_event(&mut self, event: &RelayAuditEvent) -> String {
        let data = format!("{}|{}|{}|{}", event.event_type, event.address, event.timestamp, serde_json::to_string(&event.details).unwrap());
        let hash = hash_hex(data.as_bytes());
        self.leaves.push(hash.clone());
        self.last_event_hash = hash.clone();
        // Append to JSONL with hashAlgorithm: "tis-27"
        self.persist(&hash, event);
        hash
    }
}
```

Every entry includes `hashAlgorithm: "tis-27"` — there is no other algorithm.

Merkle chain uses `hash_hex()` for node hashing. Merkle root computation uses `hash_hex()`. Capability hashing uses `hash_hex()`. Zero SHA-3 anywhere.

**Forma Codex forward-compatibility fields** (eventId UUID v4, source_service, severity, subsystem, correlationRefs) are included on every entry as specified in the original spec — this part is unchanged.

Audit event types (the full list from the original spec Phase 2):
```rust
pub enum RelayAuditEventType {
    AuthSuccess, AuthFailure, Disconnect, Reconnect,
    Error, CircuitBreaker, GoAway, PeerOffline,
    // New — Task #27
    CapabilityNegotiation, CapabilityEnforcement, CapabilityDowngrade,
    TopicSubscribe, TopicPublish, TopicReauthFailure,
    TopicRevoked, TopicReset, TopicLifecycle,
    Tombstone, ResyncRateLimit, HeartbeatFailure,
    HeartbeatIntervalChange, CircuitBreakerManualReset,
}
```

**In-memory capability index:** `HashMap<RepCAddress, Vec<String>>` mapping each node's Rep C address to its last-negotiated capability set. Populated from the audit log on startup (reverse scan), updated on each negotiation. Source of truth for downgrade detection.

**REPLIT NOTE:** This is a Rust module in the relay server. No TypeScript files modified. The existing TS `capability-audit-events.ts` and its SHA-3 usage is a SEPARATE remediation task — not part of Task #27.

---

### Task 1 — Capability Negotiation (Rust)

Same protocol as original spec. Rust implementation:
- `supported` array parsing with version string validation (`name:version` regex)
- `enabled` / `negotiated_down` computation
- Capability set stored in per-connection state
- Enforcement on every message via `check_capability()` guard
- Downgrade detection via in-memory audit index
- `ERR_CAPABILITY_DOWNGRADE` / `ERR_CAPABILITY_NOT_NEGOTIATED` error responses
- Constant-time capability set comparison (use `subtle` crate, already in inter-cube deps)
- Audit logging via `RelayAuditLog` (TIS-27 native)

---

### Task 3 — Heartbeat with HModal Phasing (Rust)

Same protocol as original spec. Key difference:
- Coprime walk positions computed via `ternary_math::coprime::coprime_options()` **directly** — no NinjaExec HTTP call, no cache needed, just a function call
- HModal null channel assignment is a modular arithmetic check in Rust
- Per-connection phased scheduling via tokio timers
- Runtime interval change with ack timeout

---

### Task 4 — Topic Pub/Sub (Rust)

Same protocol as original spec. Key difference:
- Authorization binding uses Rep C address directly from the authenticated connection context (Rust struct field, not a JS object property)
- Coprime-stepped delivery uses `coprime_options()` directly
- `has_forgery()` from `gf3_algebra.rs` called directly for Rep C frame validation
- Topic epoch: `std::time::SystemTime::now()` as epoch source

---

### Task 5 — Sequencing, Tombstones, Resync (Rust)

Same protocol as original spec. Key difference:
- `RelaySequenceStore` in Rust uses `bincode` + truncated TLSponge-385 hash for integrity — calls `ternary_math::sponge::hash_hex()` directly, not via any bridge
- Context string "PlenumNET-DEDUP-STATE-v1" passed directly to the sponge
- Golden angle stagger computed in Rust: `φ_ternary = 182.0 * (3.0 - 5.0_f64.sqrt()) / 364.0`
- Atomic file writes use the same `.tmp + rename` pattern as the existing `SequenceStore` in `persistence.rs`

---

### Task 6 — Rust Client Upgrades

**UNCHANGED from original spec.** This was already Rust:
- Full jitter backoff in `main.rs`
- New frame handlers in `ws_relay.rs` read loop
- `RelaySequenceStore` in `persistence.rs` (new, alongside existing `SequenceStore`)
- `has_forgery()` from `gf3_algebra.rs` for Rep C validation

---

### Task 7 — Circuit Breaker Enhancement (Rust)

Same protocol. Implemented as a Rust struct extending the circuit breaker pattern:
- Token-bucket recovery ramp
- Coprime probe scheduling via `coprime_options()` directly
- HModal null channel probes
- Prometheus gauge exposure

---

### Task 8 — Graceful Shutdown (Rust)

Same protocol. Rust/tokio implementation:
- Golden angle stagger on go-away broadcast
- Per-connection drain window via `tokio::time::timeout()`
- HTTP 503 draining health endpoint via Axum route
- Shutdown ordering: relay drain → other services → `process::exit(1)` after 30s

---

### Task 9 — OpenTelemetry (Rust)

Rust OTel SDK (`opentelemetry`, `opentelemetry-otlp`, `tracing-opentelemetry` crates). Same attributes and sampling strategy as original spec.

---

### Task 10 — Prometheus Metrics (Rust)

`prometheus` crate (Rust-native). Exposed on internal `METRICS_PORT` via Axum. Same 16 metrics as original spec.

---

### Task 12 — Integration Tests (Rust)

`#[tokio::test]` harness. Same test cases as original spec. 5-minute CI wall clock limit. Configurable time parameters shortened in CI.

---

### Task 13 — Documentation & Runbooks

**UNCHANGED** from original spec — protocol documentation is language-independent.

---

## Corrected Task Dependency Graph

```
  2 (error codes + NinjaExec coprime route)
  │
  ├──→ 11 (TIS-27 audit — simplified, no migration) ──→ 1 (capabilities) ──→ 3 (heartbeat)
  │                                                              │
  │                                                              └──→ 4 (topics) ──→ 5 (sequencing)
  │
  7 (circuit breaker)
  8 (graceful shutdown)
  │
  └──→ 6 (Rust client upgrades) ←── 4, 5
  │
  9 (OpenTelemetry) ←── 4, 5
  10 (Prometheus) ←── 7, 8, 11
  │
  12 (integration tests) ←── ALL
  13 (documentation) ←── ALL
```

Critical path: **2 → 11 → 1 → 4 → 5 → 6 → 12**

Task 11 is NO LONGER split into phases. There is no Phase 1/Phase 2 distinction because there is no SHA-3→TIS-27 migration — TIS-27 is the only algorithm from the start.

---

## Files Replit Needs to Provide / Produce

### Already in the zip (reference code — DO NOT MODIFY for Task #27):
- `server/index.ts` — migration reference for existing relay protocol behavior
- `server/services/node-watchdog.ts` — migration reference for error codes, circuit breaker pattern
- `server/services/capability-audit-events.ts` — migration reference for audit log pattern (SHA-3 violation stays in TS, separate remediation)
- All other `server/services/*.ts` — NOT TOUCHED by Task #27

### Files Claude builds (Rust):
- `services/inter-cube/src/relay_server.rs` — WebSocket relay server (Axum + tokio-tungstenite)
- `services/inter-cube/src/relay_error.rs` — Error codes enum + `make_error_response()`
- `services/inter-cube/src/relay_audit.rs` — TIS-27 Merkle-chained audit log
- `services/inter-cube/src/relay_topics.rs` — Topic lifecycle, pub/sub, authorization
- `services/inter-cube/src/relay_seq.rs` — Sequence numbering, tombstones, resync
- `services/inter-cube/src/relay_capabilities.rs` — Capability negotiation + enforcement
- `services/inter-cube/src/relay_heartbeat.rs` — HModal-phased heartbeat
- `services/inter-cube/src/relay_circuit.rs` — Enhanced circuit breaker
- `services/inter-cube/src/relay_shutdown.rs` — Graceful shutdown with golden angle stagger
- `services/inter-cube/src/relay_metrics.rs` — Prometheus metrics
- `services/inter-cube/src/relay_telemetry.rs` — OpenTelemetry integration
- `services/inter-cube/src/relay_frames.rs` — Frame validation contract + Rep C encoding
- `services/inter-cube/src/relay_seq_store.rs` — Persistent dedup state (alongside existing `persistence.rs`)
- `ninja-exec/src/server.rs` — coprime_options route added
- `tests/` — Integration tests
- `docs/` — Protocol documentation + runbooks

### New crate dependencies (add to `services/inter-cube/Cargo.toml`):
```toml
# Task #27 additions
bincode = "1"          # Dedup state serialization
prometheus = "0.13"    # Metrics
# OTel (Task 9) — add when Task 9 begins:
# opentelemetry = "0.22"
# opentelemetry-otlp = "0.15"
# tracing-opentelemetry = "0.23"
```

All other deps (`ternary-math`, `tokio`, `axum`, `tokio-tungstenite`, `serde`, `futures-util`, `uuid`, `hex`, `subtle`) are already present.

---

## Summary of What Changed vs Original Spec

| Aspect | Original Spec | Corrected |
|--------|--------------|-----------|
| Server language | TypeScript (extend `server/index.ts`) | **Rust/Axum** |
| TIS-27 access | N-API bridge (`sponge_hash(Buffer)→String`) | **Direct: `hash_hex()`** |
| Coprime access | NinjaExec HTTP (`:21027/coprime_options`) | **Direct: `coprime_options()`** |
| GF(3)/Rep C access | TypeScript inline + Rust client | **Direct: `has_forgery()`** |
| SHA-3→TIS-27 migration | Complex v1/v2 boundary, 5 TS files | **Not needed — TIS-27 from start** |
| Task 11 complexity | Split Phase 1 + Phase 2, shared verifier updates | **Single task, no migration** |
| Audit log file | Shared `capability-audit.jsonl` | **Separate `relay-audit.jsonl`** |
| Error codes | Added to TS `RELAY_ERROR_CODES` object | **Rust enum** |
| Frame validation | TypeScript function | **Rust struct + validation** |
| Circuit breaker | Extend TS `CircuitBreaker` class | **Rust struct** |

**Protocol design is 100% unchanged.** Capability negotiation, topic lifecycle, sequencing, tombstones, Rep C encoding, HModal phasing, golden angle stagger, coprime delivery, frame schemas, security model — all identical. Only the implementation language and bridge architecture are corrected.

---

*Lo Sono Capomastro — Così sia.*
