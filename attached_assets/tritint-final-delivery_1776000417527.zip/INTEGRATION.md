# TritInt Decontamination — Replit Integration Guide

**Date:** 2026-04-12
**Scope:** 11 files, 10,950 lines

---

## What This Delivery Is

Every framework value in the ternary-math crate now derives from TritInt — the base-3 native numeric type. No hardcoded decimal literals for any framework constant (repunits, polygon generators, coprime tables, UV wavelengths, sponge dimensions, hash windows, compression parameters, signal model, geometry). The boundary crossing from TritInt to host integer (u32/u64/usize) happens at point of use via `.to_u32_const()`, not in an intermediate duplication layer.

## Files To Replace

All files go into `ternary-math/src/`. Drop-in replacement — same filenames, same public API.

| File | Lines | What changed |
|------|-------|-------------|
| `trit_int.rs` | 2,732 | `MAX_HEAP_TRITS` deleted. `TritIntError::TooLong` deleted. `from_u128()` auto-promotes to heap. `from_trit_slice()` + `repunit_rt()` added (runtime unbounded). Const path documented as Rust language constraint. |
| `constants.rs` | 1,779 | §0: 33 TritInt constants (source of truth). All §1-§17 u32 values derived — coprime tables, UV wavelengths, signal model, polygon geometry, torus knots, Z₂₈, Fibonacci. Zero hardcoded decimal literals for framework values. |
| `ttc.rs` | 2,694 | Powers of 3 computed via `3_usize.pow(n)`. `MAX_MATCH_LEN = Δ₂`. `TUNNEL_COUNT = 2 × R₃`. Hash window/multipliers from constants. Torsion/delta spectral analysis from R₃. |
| `tlsponge385.rs` | 869 | `STATE_SIZE = Δ₂`. `LANES = √Δ₂`. `RATE = 3⁵`. `ROUNDS = 3²`. `MAX_BATCH = 2 × R₃`. |
| `ctx_ans.rs` | 531 | `CTX_BINS = 3³`. Hash13, find_long_match, update_long_table all derive window and multipliers from constants. |
| `container_decomp.rs` | 852 | `coprime_walk_order()` generators from constants. |
| `cpd.rs` | 150 | `COPRIME_STRIDES` from T_POLYGON_* and COPRIME_PAIR_LCMS. |
| `coprime.rs` | 516 | Zero `from_u64()`. All values trit-native. |
| `wasm_exports.rs` | 637 | 40-trit guards removed. FFI exports cross through T_ directly. |
| `cube_addr.rs` | 59 | `DIMENSIONS = R₃` via T_REPUNIT_3. |
| `repunit_circles.rs` | 132 | R₃-R₉ derived from T_ constants. |

## How To Apply

```bash
# From repo root:
cd ternary-math/src/

# Back up originals
mkdir -p /tmp/pre-decontamination
cp trit_int.rs constants.rs ttc.rs tlsponge385.rs ctx_ans.rs \
   container_decomp.rs cpd.rs coprime.rs wasm_exports.rs \
   cube_addr.rs repunit_circles.rs /tmp/pre-decontamination/

# Extract delivery (from wherever the zip was downloaded)
unzip tritint-complete-decontamination.zip -d .

# Build
cargo check 2>&1 | head -50

# If clean, run tests
cargo test --workspace 2>&1 | tail -20
```

## Expected Build Behavior

`cargo check` should pass clean. If there are errors, they will be in one of two categories:

1. **Trit literal typos** — a `from_trits(&[...])` value doesn't produce the expected integer. The compile-time assertions in constants.rs §0 catch these immediately. Fix the trit array.

2. **Missing T_ constant** — a file not in this delivery imports a u32 constant that was changed or removed. The u32 backward-compat layer in constants.rs §1+ should prevent this, but if a symbol is missing, add it back as `pub const X: u32 = T_X.to_u32_const();` temporarily.

## What's Left (Not In This Delivery)

The following files still import u32 constants from the backward-compat layer in constants.rs §1+. They need the same migration: replace `crate::constants::SYMBOL` with `crate::constants::T_SYMBOL.to_u32_const()`.

| File | Constants used | Migration effort |
|------|---------------|-----------------|
| `ternary_circle.rs` | `pub use` re-exports ~15 constants (CYCLIC_ORDER, Z28_*, WALK_TURN_*, etc.) | Medium — re-exports become `pub const X: u32 = T_X.to_u32_const()` at the re-export site |
| `trit.rs` | Compile-time assertions against `constants::REPUNIT_6`, `ROOT_X1`, `ARC_ROOT_SEMI`, `DISCRIMINANT_2`, `DUTY_NUM/DEN` | Small — change assertion RHS to `T_X.to_u32_const()` |
| `torus.rs` | `TORUS_RADIX` (= 3), `TAU_TRIBONACCI` (f64) | Trivial — TORUS_RADIX = 3 is the radix, TAU is f64 |
| `tribonacci.rs` | `TAU_TRIBONACCI` (f64) | None — f64 constants are not framework integers |

Once those 4 files are migrated, the u32 backward-compat layer (§1+ in constants.rs) can be deleted entirely. The `pub const fn repunit(n: u32) -> u32` function can also be deleted — consumers use `TritInt::repunit(n).to_u32_const()`.

## Architecture After Full Migration

```
trit_int.rs          TritInt type (unbounded, base-3 native)
       │
       ▼
constants.rs §0      T_REPUNIT_3, T_POLYGON_11, T_ARC_ROOT_SEMI, ...
       │              (TritInt consts — source of truth)
       │
       ├──► engine files     cross at point of use:
       │                     const R3: usize = T_REPUNIT_3.to_u32_const() as usize;
       │
       ├──► wasm_exports     cross at FFI boundary:
       │                     pub fn repunit_3() -> u32 { T_REPUNIT_3.to_u32_const() }
       │
       └──► coprime tables   cross via private P aliases:
                             const P7: u32 = T_POLYGON_7.to_u32_const();
                             pub const COPRIME_PAIRS: [...] = [(P7, P11), ...];
```

No u32 duplication layer. No decimal literals for framework values. TritInt is the type. `.to_u32_const()` is the boundary crossing. The crossing happens at point of use.
