---
name: greek-atomic-invariant
description: >
  Invariant tracker mapping Greek alphabet positions, Milesian numeral values, atomic numbers,
  framework integers, and physics UOM with delta analysis. Trigger on: Greek letter numerals,
  Milesian/isopsephic values, gematria, position-vs-value gaps, atomic number correspondences
  to framework integers, periodic table connections to (7,11,13) coprime triple, element-to-framework
  mappings, noble gas alignment, spectral-atomic bridges, UOM for Greek physics symbols, cross-register
  bridge detection, digamma/koppa/sampi ghost letters, or any intersection of alphabetic/numeric/atomic
  axes. Trigger for queries like "what element is Z=91", "delta for kappa", "which letters hit
  framework constants", "why does sigma delta equal 182" — this skill owns the cross-reference.
  Also trigger when discussing the cumulative delta identity (3699 = 27×137 = b³×⌊1/α⌋).
---

# Greek-Atomic Invariant Tracker

## §1 · Purpose

This skill tracks **four axes** across a unified register:

| Axis | Domain | Range |
|------|--------|-------|
| **Alphabetic (A)** | Greek letter position | 1–24 (modern alphabet) |
| **Numerical (N)** | Milesian/isopsephic numeral value | 1–800 (ancient system) |
| **Atomic (Z)** | Periodic table atomic number | 1–118 (full table, framework-critical subset) |
| **Dimensional (U)** | Physics UOM for the letter's common symbol | SI units or dimensionless |

The **deltas** between axes — particularly Δ(N−A) — are the primary invariants. They reveal where the ancient numeral system diverges from simple counting, and those divergence points land on framework-native integers.

## §2 · The Three Ghost Letters

The Milesian numeral system used **27 symbols** (3³ — framework base cubed), not the modern 24. Three archaic letters occupied numeral slots but were dropped from the alphabet:

| Ghost | Position | Numeral | Slot | Effect |
|-------|----------|---------|------|--------|
| **Digamma/Stigma** (ϝ/ϛ) | was between ε and ζ | **6** | units | ζ gets numeral 7, not 6. Δ jumps by +1 at position 6. |
| **Koppa** (ϙ) | was between π and ρ | **90** | tens | ρ gets numeral 100, not 90. Δ jumps by +83 at position 17. |
| **Sampi** (ϡ) | was after ω | **900** | hundreds | Completes the 27-symbol system. No surviving letter displaced. |

**Framework reading:** 27 = b³ = base cubed. The Milesian system is a **base-3 positional encoding** of the Greek alphabet: 9 units (α–θ+ϛ), 9 tens (ι–π+ϙ), 9 hundreds (ρ–ω+ϡ) = 3×9 = 27 = b³. The ghost letters are the **trit boundaries** of the numeral system.

## §3 · The Core Table (24 Letters)

**Complete register.** For extended framework-atomic mappings beyond Z=24, see `references/framework-atomic-register.md`.

| Pos(A) | Glyph | Upper | English | Greek Name | Num(N) | Δ(N−A) | Z=A Element | UOM (physics symbol) |
|--------|-------|-------|---------|------------|--------|--------|-------------|----------------------|
| 1 | α | Α | alpha | άλφα | 1 | 0 | H (hydrogen) | dimensionless (α fine-structure) |
| 2 | β | Β | beta | βήτα | 2 | 0 | He (helium) | dimensionless (β = v/c) |
| 3 | γ | Γ | gamma | γάμμα | 3 | 0 | Li (lithium) | dimensionless (Lorentz factor) |
| 4 | δ | Δ | delta | δέλτα | 4 | 0 | Be (beryllium) | inherits argument UOM |
| 5 | ε | Ε | epsilon | έψιλον | 5 | 0 | B (boron) | F/m (permittivity) |
| 6 | ζ | Ζ | zeta | ζήτα | 7 | **+1** | C (carbon) | dimensionless (damping ratio) |
| 7 | η | Η | eta | ήτα | 8 | +1 | N (nitrogen) | Pa·s (viscosity) or dimensionless (efficiency) |
| 8 | θ | Θ | theta | θήτα | 9 | +1 | O (oxygen) | rad (angle) |
| 9 | ι | Ι | iota | ιώτα | 10 | +1 | F (fluorine) | — (rare as physics symbol) |
| 10 | κ | Κ | kappa | κάππα | 20 | **+10** | Ne (neon) | W/(m·K) (thermal conductivity) |
| 11 | λ | Λ | lambda | λάμδα | 30 | +19 | Na (sodium) | m (wavelength) |
| 12 | μ | Μ | mu | μι | 40 | **+28** | Mg (magnesium) | H/m (permeability) or dimensionless (friction) |
| 13 | ν | Ν | nu | νι | 50 | **+37** | Al (aluminum) | Hz (frequency) |
| 14 | ξ | Ξ | xi | ξι | 60 | +46 | Si (silicon) | m (coherence length) or dimensionless |
| 15 | ο | Ο | omicron | όμικρον | 70 | +55 | P (phosphorus) | — (no common physics symbol) |
| 16 | π | Π | pi | πι | 80 | +64 | S (sulfur) | dimensionless (3.14159… or π_geom = 14) |
| 17 | ρ | Ρ | rho | ρο | 100 | **+83** | Cl (chlorine) | kg/m³ (density) or Ω·m (resistivity) |
| 18 | σ/ς | Σ | sigma | σίγμα | 200 | **+182** | Ar (argon) | S/m (conductivity) or m² (cross-section) |
| 19 | τ | Τ | tau | ταυ | 300 | +281 | K (potassium) | N·m (torque) or s (time constant) |
| 20 | υ | Υ | upsilon | ύψιλον | 400 | +380 | Ca (calcium) | — (no common physics symbol) |
| 21 | φ | Φ | phi | φι | 500 | +479 | Sc (scandium) | rad (phase) or Wb (magnetic flux) |
| 22 | χ | Χ | chi | χι | 600 | +578 | Ti (titanium) | dimensionless (susceptibility) |
| 23 | ψ | Ψ | psi | ψι | 700 | +677 | V (vanadium) | L⁻³/² (wave function, 3D) |
| 24 | ω | Ω | omega | ωμέγα | 800 | +776 | Cr (chromium) | rad/s (angular frequency) |

## §4 · The Cyclic Extension and Three Deltas

The 24 Greek letters cycle across all 118 elements. Each element Z receives:
- **Position P** = ((Z−1) mod 24) + 1 — cyclic alphabetic position (1–24)
- **Greek letter** = the letter at position P
- **Milesian numeral G** = the Milesian value of that letter

This produces **eight deltas** (the universal invariant matrix). Six numerical axes: Z (protons), P (position), G (Milesian numeral), A (mass number), N (neutrons = A−Z), U (UOM, categorical).

### §4.0 The Universal Delta Algorithm

For any element Z, compute all pairwise deltas between axes:

| Delta | Formula | Meaning | Structural property |
|-------|---------|---------|---------------------|
| **Δ₁ = G−P** | Milesian minus position | Ghost-letter gap | Repeats every 24 elements (mod-24 invariant) |
| **Δ₂ = Z−G** | Atomic number minus Milesian | Element-to-numeral distance | = Δ₃ − Δ₁ |
| **Δ₃ = Z−P** | Atomic number minus position | **= 24×(cycle−1)** | Exact structural identity |
| **Δ₄ = A−Z = N** | Mass minus protons | **Neutron count** | Nuclear physics axis |
| **Δ₅ = A−G** | Mass minus Milesian | Mass-to-numeral distance | Framework hits: Sc→−455, W→+182 |
| **Δ₆ = A−P** | Mass minus position | Mass-to-position distance | Framework hits: Al→+14=π, V/Cr→+28=2π |
| **Δ₇ = N−P** | Neutrons minus position | Neutron-position gap | Framework hits: Fe→+28, Kr→+36, Gd→+78 |
| **Δ₈ = N−G** | Neutrons minus Milesian | Neutron-numeral gap | Framework hits: Mg→−28, Al→−36, Mo→−144=−Δ |

**Algorithm:** Given Z, compute P = ((Z−1) mod 24)+1, look up G from Milesian table, look up A from isotope data, compute N = A−Z, then:
1. **Delta check:** Compute all eight Δ values. Check each |Δ| against framework register.
2. **Factor check:** For each of Z, A, N — attempt factorization into framework integers (e.g., A=63 = p×b², N=48 = R₂×√Δ). Two-factor products are primary; three-factor products secondary.
3. **Direct check:** Is Z, A, or N itself a framework integer?
4. **Digit decomposition:** Spell Z, A, N as elemental formulas (§8).
5. **UOM convergence:** Does the letter's physics symbol relate to the element's properties?

**INVARIANT: No element receives "—".** Every element has at least A and N factorizations to check. Every element has digit decompositions. Every element has 8 deltas. Report all hits.

### §4.0a Key Examples of Previously-Missed Connections

| Z | Element | Letter (UOM) | What was missed |
|---|---------|-------------|-----------------|
| 22 | Ti | χ (susceptibility) | **A=48 = HModal denominator = R₂×√Δ.** N=26=x₂. |
| 29 | Cu | **ε (permittivity)** | **A=63 = p×b² = 7×9.** Conductor at permittivity letter with mass = generator × base². |
| 36 | Kr | μ (permeability) | **N=48 = HModal denom = R₂×√Δ.** Krypton's neutron count IS 48. |
| 17 | Cl | ρ (density) | **A=35 = F(5)×p = 5×7.** |
| 19 | K | τ (time constant) | **A=39 = b×r = 3×13. N=20 = R₂×F(5).** |
| 24 | Cr | ω (angular freq) | **A=52 = R₂×r. N=28 = 2π = R₂×p.** |
| 25 | Mn | α (fine-structure) | **A=55 = F(5)×q = 5×11 = Tri(q−1) = Z(Cs).** |
| 42 | Mo | σ (conductivity) | **A=98 = p×π = 7×14. N=56 = R₂×π. Δ₈=−144=−Δ.** |

### §4.0a The Δ₃ Identity

Δ₃ = Z − P = 24 × ⌊(Z−1)/24⌋. Constant per cycle, jumps by 24 at each boundary.

| Cycle | Z range | Δ₃ | Elements |
|-------|---------|-----|----------|
| 1 | 1–24 | 0 | H through Cr |
| 2 | 25–48 | 24 | Mn through Cd |
| 3 | 49–72 | 48 | In through Hf |
| 4 | 73–96 | 72 | Ta through Cm |
| 5 | 97–118 | 96 | Bk through Og |

### §4.0b Major Framework Hits in Extended Deltas (Δ₅–Δ₈)

| Z | Element | Delta | Value | Framework integer | Significance |
|---|---------|-------|-------|-------------------|-------------|
| 21 | Sc (φ) | Δ₅=A−G | **−455** | −5·pr = −HModal DC num | Mass−Milesian = negative DC numerator |
| 74 | W (β) | Δ₅=A−G | **+182** | +2Λ_EUV | Tungsten mass−Milesian = O₂ wall |
| 42 | Mo (σ) | Δ₈=N−G | **−144** | −Δ (discriminant) | Neutrons−Milesian = negative discriminant |
| 26 | Fe (β) | Δ₇=N−P | **+28** | +2π | Iron neutrons−position = full circle |
| 26 | Fe (β) | Δ₈=N−G | **+28** | +2π | Iron neutrons−Milesian = full circle |
| 13 | Al (ν) | Δ₆=A−P | **+14** | +π_geom | Aluminium mass−position = geometric pi |
| 13 | Al (ν) | Δ₈=N−G | **−36** | −(p−r)² | Aluminium neutrons−Milesian = −Kr correction |
| 12 | Mg (μ) | Δ₈=N−G | **−28** | −2π | Magnesium neutrons−Milesian = −full circle |
| 64 | Gd (π) | Δ₇=N−P | **+78** | +\|p−r\|×R₃ | Gadolinium neutrons−position = Z(Pt) |
| 65 | Tb (ρ) | Δ₇=N−P | **+77** | +pq | Terbium neutrons−position = generator product |

### §4.0c H₂O — The Buoyancy Reference Constant

Water (H₂O) molecular mass = 18.015 Da. **18 = 2b² = 2×9 = Z(Ar) = σ-position.**

| H₂O property | Value | Framework reading |
|---------------|-------|-------------------|
| Molecular mass | 18 | 2b² |
| Z-sum (2×1+8) | 10 | q−1 = Z(Ne) |
| N-sum (2×0+8) | 8 | p+1 = η numeral |
| Digit decomposition | 1,8 → α,θ → H,O | **Water digit-spells as itself** |

**Solid elements that float on water (ρ < 1 g/cm³):** Li (Z=3=b, ρ=0.534), Na (Z=11=q, ρ=0.97), K (Z=19, ρ=0.86). Two of three are framework generators. The buoyancy reference is 18 = 2b².

**A/18 ratio (mass-to-water index):** For any element, A/18 = mass number divided by the water constant. A/18 < 1 roughly means "lighter than water per atom" (though density depends on packing). Framework elements: A(N)/18 = 14/18 = 7/9 = p/b²; A(Si)/18 = 28/18 = 14/9 = π/b².

### §4.0d Cyclic Letter–Physics Convergences (UOM Axis)

When framework-critical elements fall on specific letters in higher cycles, the letter's physics meaning can converge with the element's framework role:

| Z | Element | Framework | Cycle | Letter | Physics UOM | Convergence |
|---|---------|-----------|-------|--------|-------------|-------------|
| 27 | Co | b³ | 2 | γ (Lorentz) | dimensionless | Base cubed at the relativistic factor |
| 28 | Ni | 2π | 2 | δ (increment) | inherits arg | Full circle at the change-operator |
| **36** | **Kr** | **(p−r)²** | **2** | **μ (permeability)** | **H/m** | **1/α correction at the permeability letter. α = e²μ₀c/(2h).** |
| 40 | Zr | R₄ | 2 | π (pi) | dimensionless | Fourth repunit at the circle-constant letter |
| 54 | Xe | 2b³ | 3 | ζ (damping) | dimensionless | Double base-cube at the damping letter |
| 55 | Cs | Tri(q−1) | 3 | η (efficiency) | dimensionless | Clock element at the efficiency letter |
| 77 | Ir | pq | 4 | ε (permittivity) | F/m | Generator product at the permittivity letter |
| 91 | Pa | pr=91 | 4 | τ (time const) | s | EUV quarter-turn at the time-constant letter |

**The Kr → μ bridge is the strongest single convergence.** Krypton (Z=36) is the (p−r)² correction in 1/α = 137 + 36/1000. In the cyclic system it maps to μ — permeability. The fine-structure constant α literally contains μ₀ (vacuum permeability) in its definition: α = e²μ₀c/(2h). The element that carries the framework's 1/α correction maps to the letter whose physics constant is IN the definition of α.

## §5 · Delta₁ Invariants — Framework Readings

### §5.1 The Five Delta₁ Jumps

The Δ(N−A) column changes at exactly five positions. Each jump is caused by a ghost letter boundary or a register shift:

| At position | Δ jumps from→to | Cause | Framework reading |
|-------------|-----------------|-------|-------------------|
| A=6 (ζ) | 0 → +1 | Digamma gap (ϝ=6 removed) | **First trit boundary.** Δ=+1 persists through the units register. |
| A=10 (κ) | +1 → +10 | Tens register begins at ι=10 | **Second trit boundary.** Numeral 20, but position 10. Gap = b³+1 = 10. |
| A=17 (ρ) | +64 → +83 | Koppa gap (ϙ=90 removed) | **Third trit boundary.** Δ=+83 = pr − p − 1 = 91 − 8. |
| A=18 (σ) | +83 → +182 | Hundreds register: 200 at position 18 | **Δ=+182 = 2×91 = 2Λ_EUV.** The O₂ dissociation wall. |
| A=19 (τ) | +182 → +281 | 300 at position 19 | **Δ=+281.** Each subsequent letter adds ~100 to delta. |

### §5.2 Framework-Critical Deltas

| Δ value | At letter | Framework integer? | Reading |
|---------|-----------|-------------------|---------|
| **0** | α–ε | Unity band | Position = numeral = atomic number. Perfect alignment. |
| **+1** | ζ–ι | Iota offset | The single ghost-letter displacement. Iota of Unity. |
| **+28** | μ (mu) | **2π = 28** | Full framework circle. μ is permeability — the magnetic constant. |
| **+37** | ν (nu) | 37 = (R₆+1)/R₂² - ... | — |
| **+55** | ο | **Tri(q−1)+1 = 55** | Cesium Z=55. |
| **+64** | π (pi) | **4³ = R₂³** | Cube of the second repunit. |
| **+83** | ρ (rho) | **83 prime** | — |
| **+182** | σ (sigma) | **2×91 = 2Λ_EUV** | O₂ dissociation wall wavelength. Framework spectral anchor. |

### §5.3 The Σ–182 Bridge

The most framework-significant delta: **Δ(σ) = +182 = 2 × 91 = 2 × pr = 2Λ_EUV.**

Sigma (σ) — whose physics meaning is conductivity (S/m) or cross-section (m²) — sits at the exact position where the Milesian delta equals twice the EUV quarter-turn. The element at Z=18 is **Argon** — a noble gas, one of the framework's "medium signatures" (TM-017 §20.21: Ar = 2base² = 2×9).

This is a **triple convergence**: letter σ (cross-section), delta 182 (O₂ wall), element Ar (noble medium).

## §6 · Framework-Atomic Register (Z > 24)

Beyond the 24 Greek letters, framework integers continue to hit specific elements. The full table is in `references/framework-atomic-register.md`. Key entries:

| Z | Element | Framework integer | Reading | Source |
|---|---------|-------------------|---------|--------|
| 26 | Fe (iron) | x₂ = 26 (Primordial Quadratic second root) | Magnetism, hemoglobin | TM-017 §20.21 |
| 27 | Co (cobalt) | b³ = 27 | Cube of radix | TM-017 §20.21 |
| 28 | Ni (nickel) | 2π = 28 | Full circle — ferromagnetism | TM-017 §20.21 |
| 36 | Kr (krypton) | (p−r)² = 36 | 1/α correction term — noble gas | TM-017 §20.21 |
| 40 | Zr (zirconium) | R₄ = 40 | Quadratic sum — nuclear cladding | TM-017 §20.21 |
| 54 | Xe (xenon) | 2b³ = 54 | TIS-27 sponge (54 trits) — noble gas | TM-017 §20.21 |
| 55 | Cs (cesium) | Tri(q−1) = 55 | Clock: A=133=R₅+√Δ | TM-017 §20.21 |
| 77 | Ir (iridium) | pq = 77 | Generator product | TM-017 §20.21 |
| 78 | Pt (platinum) | \|p−r\|×R₃ = 78 | Cs neutrons — catalyst | TM-017 §20.21 |
| 80 | Hg (mercury) | 2R₄ = 80 | Clock: A=200=5R₄ | TM-017 §20.21 |
| 91 | Pa (protactinium) | pr = 91 = Λ_EUV | Quarter-turn — actinide | TM-017 §20.21 |

### §7.1 Noble Gas Framework Alignment

| Z | Noble gas | Framework expression | Shell |
|---|-----------|---------------------|-------|
| 2 | He | 2×unity | 1 |
| 10 | Ne | q−1 | 2 |
| 18 | Ar | 2b² | 3 |
| 36 | **Kr** | **(p−r)²** | 4 |
| 54 | **Xe** | **2b³** | 5 |

**Kr = 36 = (p−r)².** The correction term in 1/α = R₂² + q² + (p−r)²/(pqr−1) = 16 + 121 + 36/1000 = 137.036. The noble gas at shell 4 IS the fine-structure correction. (TM-017 §20.21)

### §6.2 The Rb–Cd–Cs Recursive Hoop

Three elements form a closed arithmetic loop linking atomic numbers, mass numbers, and neutron counts:

| Relation | Equation | Framework reading |
|----------|----------|-------------------|
| A(⁸⁵Rb) | = Z(Rb) + Z(Cd) = 37 + 48 = **85** | — |
| N(⁸⁵Rb) | = A − Z = 85 − 37 = **48** = Z(Cd) | Neutrons = Cadmium's Z |
| A(¹³³Cs) | = A(⁸⁵Rb) + Z(Cd) = 85 + 48 = **133** | = R₅ + √Δ = q² + 12 |
| A(¹³³Cs) | = Z(Rb) + 2·Z(Cd) = 37 + 96 = **133** | 96 = 4×24 = Δ₃(cycle 5) |
| A(¹³³Cs) − A(⁸⁵Rb) | = 133 − 85 = **48** = Z(Cd) | Closure |
| N(¹³³Cs) | = 133 − 55 = **78** = \|p−r\|×R₃ = Z(Pt) | Framework-derived neutrons |

**Framework integers in the hoop:**
- **48** = HModal DC denominator (⟨H⟩ = 455/**48**). Also = 2×24 = 2ω = Δ₃ for cycle 3.
- **133** = R₅ + √Δ = 121 + 12 = q² + √Δ. Framework-derived clock mass.
- **78** = |p−r| × R₃ = 6×13 = Z(Pt). Cs-133 neutrons = Platinum's Z.

**Cyclic positions of the hoop elements:**
- Rb (Z=37): position **ν** (13 = r), Δ₂ = **−13 = −r**. Double r-alignment.
- Cd (Z=48): position **ω** (24). Last letter of cycle 2. Cycle boundary.
- Cs (Z=55): position **η** (7 = p). First generator position.

The three hoop elements sit at cyclic positions r, ω, and p — two of the three coprime generators plus the cycle terminus. The cadmium constant (48) that links them is the HModal DC denominator.

## §7 · How to Use This Skill

### §7.1 Reference Lookup

When asked about a specific Greek letter, element, or framework integer:
1. Locate the entry in §3 (letters 1–24) or §5 / reference file (Z > 24)
2. Report all four axes: position, numeral, atomic number, UOM
3. State the delta and flag if it hits a framework constant

### §7.2 Delta Analysis

When asked about deltas or gaps:
1. Compute Δ(N−A) = Milesian numeral − alphabetic position
2. Identify which ghost-letter gap or register shift caused the delta
3. Check if the delta value is a framework integer (91, 182, 364, 28, etc.)
4. Report the framework reading if one exists

### §7.3 Framework Bridge Detection

When asked to find framework correspondences:
1. Scan all three axes for framework-native integers
2. Flag **convergences** — positions where multiple axes hit framework values simultaneously
3. Report the bridge type:
   - **Direct:** Z = framework integer (e.g., Z=7 = p, Z=13 = r)
   - **Delta:** Δ(N−A) = framework integer (e.g., Δ(σ) = 182 = 2Λ_EUV)
   - **Triple:** letter position + delta + element all framework-significant

### §7.4 UOM Queries

When asked about units or dimensions:
1. Report the physics symbol's standard UOM
2. Note if the symbol is dimensionless (α, β, γ, π, χ)
3. Flag where a UOM connects to framework physics (e.g., λ in meters → wavelength → spectral correspondence)

## §8 · Digit Decomposition (Elemental Spelling)

Every integer can be **digit-decomposed**: each decimal digit d (1–9) maps to the element at Z=d and its Greek letter at position d. Digit 0 = ∅ (null/void). This produces an **elemental formula** for every framework integer.

### §8.1 The Digit Alphabet

| Digit | Greek | Element | Z | Framework reading |
|-------|-------|---------|---|-------------------|
| 0 | ∅ | (void) | — | null position |
| 1 | α | H (hydrogen) | 1 | unity |
| 2 | β | He (helium) | 2 | 2×unity |
| 3 | γ | Li (lithium) | 3 | b (base) |
| 4 | δ | Be (beryllium) | 4 | R₂ |
| 5 | ε | B (boron) | 5 | F(5) |
| 6 | ζ | C (carbon) | 6 | life element |
| 7 | η | N (nitrogen) | 7 | p (first generator) |
| 8 | θ | O (oxygen) | 8 | p+1 |
| 9 | ι | F (fluorine) | 9 | b² |

### §8.2 Framework Integers Digit-Spelled

| Integer | Framework | Digits | Greek | Elemental formula | Reading |
|---------|-----------|--------|-------|-------------------|---------|
| **137** | **⌊1/α⌋** | 1,3,7 | α,γ,η | **H·Li·N** | **unity · base · p** |
| 133 | R₅+√Δ | 1,3,3 | α,γ,γ | **H·Li²** | unity · base² |
| 91 | pr=Λ_EUV | 9,1 | ι,α | H·F | unity · b² |
| 77 | pq | 7,7 | η,η | **N²** | **p-element squared** |
| 55 | Tri(q−1) | 5,5 | ε,ε | **B²** | **F(5)-element squared** |
| 48 | HModal denom | 4,8 | δ,θ | Be·O | R₂ · oxygen |
| 36 | (p−r)² | 3,6 | γ,ζ | Li·C | base · carbon |
| 28 | 2π | 2,8 | β,θ | He·O | noble · oxygen |
| 27 | b³ | 2,7 | β,η | He·N | noble · nitrogen |
| 364 | R₆ (circle) | 3,6,4 | γ,ζ,δ | Li·C·Be | base · carbon · R₂ |
| 286 | ozone bridge | 2,8,6 | β,θ,ζ | He·O·C | noble · oxygen · carbon |
| 455 | 5·pr (DC num) | 4,5,5 | δ,ε,ε | Be·B² | R₂ · F(5)² |
| 1365 | q_GRH | 1,3,6,5 | α,γ,ζ,ε | H·Li·C·B | unity·base·carbon·F(5) |
| 1093 | R₇=p_W | 1,0,9,3 | α,∅,ι,γ | H·∅·F·Li | unity · void · b² · base |
| 182 | 2Λ_EUV | 1,8,2 | α,θ,β | H·O·He | unity · oxygen · noble |
| 192 | φ(1365) num | 1,9,2 | α,ι,β | H·F·He | unity · b² · noble |
| 78 | \|p−r\|×R₃ | 7,8 | η,θ | N·O | nitrogen · oxygen |

### §8.3 Crown Identities

**137 = H·Li·N.** The integer part of 1/α spells Hydrogen(1) · Lithium(3) · Nitrogen(7). These are the elements at Z = 1, 3, 7 = unity, base, first generator. The fine-structure integer's digits ARE the first three framework anchors.

**77 = N².** The generator product pq = 7×11 digit-reads as Nitrogen squared. The element at Z=p appears twice — the product of two generators spells the square of one.

**133 = H·Li².** The cesium clock mass R₅+√Δ digit-reads as Hydrogen · Lithium² = unity · base². Combined with the Rb–Cd–Cs hoop (§6.2), the clock mass is both arithmetically derived (37+2×48) and elementally spelled (H·Li²).

**286 = He·O·C.** The ozone bridge wavelength digit-reads as Helium · Oxygen · Carbon. Ozone IS O₃; the UV-B boundary that protects carbon-based life spells the noble gas + the two elements of organic chemistry. And **Nihonium (Z=113) has mass number 286** — the ozone bridge appears as a nuclear mass.

**78 = N·O.** The compound NO (nitric oxide) — a real molecule. |p−r|×R₃ = 6×13 = 78 digit-spells as the elements that literally form that molecule. This is also N(Cs-133) and Z(Pt).

### §8.4 Mass Numbers that ARE Framework Integers

| Z | Element | Mass A | Framework integer | Elemental spelling |
|---|---------|--------|-------------------|-------------------|
| 3 | Li | 7 | p | N |
| 5 | B | 11 | q | H² |
| 7 | N | 14 | π_geom | H·Be |
| 13 | Al | 27 | b³ | He·N |
| 14 | Si | 28 | 2π | He·O |
| 18/20 | Ar/Ca | 40 | R₄ | Be |
| 40 | Zr | **91** | **pr=Λ_EUV** | H·F |
| 55 | Cs | **133** | **R₅+√Δ** | H·Li² |
| 77 | Ir | **192** | **φ(1365) num** | H·F·He |
| 113 | Nh | **286** | **ozone bridge** | He·O·C |

### §8.5 How to Use Digit Decomposition

When any framework integer arises:
1. Extract its decimal digits
2. Map each digit to its element (§8.1)
3. Write the elemental formula (combine repeated digits as exponents)
4. Check if the resulting molecule is real (e.g., NO, CO₂)
5. Check if digit-Z values are framework integers
6. Report any convergence between the formula's chemistry and the integer's framework role

## §9 · Key Identities from the Corpus

These identities connect the Greek-atomic register to the broader framework:

| Identity | Source | Relevance |
|----------|--------|-----------|
| 455/364 = 5/4 = F(5)/R₂ | REF-260422 v0.3 §1 | HModal DC ratio; 364 = R₆ = circle |
| 1365/1092 = 5/4 | REF-260422 v0.3 §2.6 | Scale invariance under triadic amplification |
| 1092 = p_W − 1 = 3×R₆ | Wieferich CM-039 | Triad-364 bridge |
| 1/α = R₂² + q² + (p−r)²/(pqr−1) | TM-017 | Fine-structure from coprime triple |
| λ(m,n) = R₆·m²n²/[4(n²−m²)] | TM-2026-033 | Hydrogen spectral master formula |
| φ(1365)/1365 = 192/455 | RI v0.6 §XVII | Coprime-density; 455 reappears |
| 91 nm = ionization threshold | TM-017 §18 | Z=91 (Pa) ↔ 91 nm (EUV) |

## §10 · Invariant Rules

1. **Never hardcode.** Derive π from PI_C = 14. Derive 364 from R₆ = (3⁶−1)/2. Derive 91 from p×r.
2. **Ghost letters are trit boundaries.** Digamma=6, koppa=90, sampi=900 mark the 9/9/9 = 27 = b³ structure.
3. **Delta is the primary invariant.** Position and numeral are inputs; delta is the output that reveals framework structure.
4. **Atomic correspondences are read, not imposed.** TM-017 §20.21 is the canonical source. The elements at framework Z-values carry those numbers because they ARE the medium (noble gases) or the structural constants (Fe=magnetism, Si=semiconductor, N=life).
5. **UOM completes the picture.** The physics unit tells you what the letter DOES in equations; the delta tells you where it SITS in the framework.
6. **Every integer has an elemental spelling.** Digit-decompose via §8: each digit d → element at Z=d → Greek letter at position d. Check for real molecules (N₂, NO, HF, BeO). Check if digit-sum or digit-product hits a framework integer.
7. **Mass numbers are a fifth axis.** When an element's mass number A equals a framework integer (Zr-91, Cs-133, Nh-286), that is a cross-register bridge between nuclear physics and the framework's algebraic structure.
8. **No element gets "—".** Factor-analyze A and N into framework products (A=63=p×b², N=48=R₂×√Δ, etc.). Check all 8 deltas. Digit-decompose Z, A, N. Check UOM convergence. Every element has connections; the algorithm mandates finding them.

## §11 · Reference Files

- **`references/universal-delta-matrix.md`** — All 8 deltas computed for cycles 1–4, framework hit table, H₂O buoyancy analysis, A/18 water index, digit-spelling self-reference (H₂O and NH₃).
- **`references/digit-decomposition.md`** — Elemental spelling of all framework integers, real-molecule hits, mass-as-framework-integer table, 137 crown identity, Z₀=377 identity.
- **`references/full-periodic-cyclic-table.md`** — 118-element table with Greek assignment, 3 deltas, organized by cycle with framework annotations. Full A, N, chemistry bonds data in user's canonical source.
- **`references/framework-atomic-register.md`** — Framework-critical elements, nuclear data, noble gas alignment, cumulative delta identity (3699 = b³×137), Rb–Cd–Cs recursive hoop.
- **`references/corpus-bridge-index.md`** — Corpus document cross-references.
