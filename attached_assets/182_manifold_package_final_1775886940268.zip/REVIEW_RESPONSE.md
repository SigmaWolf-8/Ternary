# Review Response — 182° Manifold Package

**Capomastro Holdings Ltd. — Applied Physics Division**
**April 2026**

---

## Issue 1: ags.rs Ternary Multiplication Error in Comments (Lines 218–226)

**Reviewer:** The comment tries to compute 11 × 13 in base 3 and gets lost.

**Response:** Correct. The comment was wrong. 11 × 13 = 143. In base 3: 143 ÷ 3 = 47 r 2, 47 ÷ 3 = 15 r 2, 15 ÷ 3 = 5 r 0, 5 ÷ 3 = 1 r 2, 1 ÷ 3 = 0 r 1. So 143 = 12022₃ (MSB-first), or [2, 2, 0, 2, 1] LSB-first.

**Action:** Comment corrected in ags.rs. The worked multiplication is removed — the code calls TritInt::mul which handles it correctly. Comments should describe WHAT, not try to replicate the arithmetic by hand.

---

## Issue 2: ags.rs shrink() Heuristic Is a Placeholder

**Reviewer:** find_least_useful_generator currently just removes the largest generator. Needs a tracking note.

**Response:** Agreed. The "remove largest" heuristic is a reasonable default but not the final implementation. The correct heuristic requires access to the population's residue distribution, which depends on the storage layer that doesn't exist yet.

**Action:** Comment updated to explicitly mark this as PLACEHOLDER with a description of the correct algorithm (residue histogram entropy per generator). A TODO with ticket reference should be added when the tracking system has a number for it.

---

## Issue 3: Option A vs Option B — Agreed

**Reviewer:** Option A (single type, enum dispatch). Agreed.

**Response:** Confirmed. TM-2026-000 already recommends Option A. No change needed.

---

## Issue 4: 8-byte vs 9-byte Inline Buffer — Go With 8

**Reviewer:** 8 bytes. Cleaner alignment. Heap handles overflow.

**Response:** Agreed. 8 bytes = 40 trits. Every framework constant fits. Values above 3⁴⁰ (about 1.22 × 10¹⁹) take the heap path, which is only hit during runtime computation on very large values, not for any constant.

**Action:** TM-2026-000 updated to state 8 bytes as the decision (not a question).

---

## Issue 5: Eigenvalue Tier Migration Needs Stronger Caveat in TM-2026-036

**Reviewer:** TM-2026-036 §4.4 presents eigenvalue-driven tier migration as architectural, but TM-2026-031 labels it speculative. The caveat should appear in both documents.

**Response:** Correct. TM-2026-036 §4.4 should state that eigenvalue-driven migration is the TARGET design but the initial implementation uses LRU-based aging until the recurrence f(n+2) = 832·f(n+1) − 118,300·f(n) is validated against real access patterns.

**Action:** TM-2026-036 §4.4 amended with explicit caveat and fallback to LRU.

---

## Issue 6: SQL Replacement Gaps Should Appear in TM-2026-036 Too

**Reviewer:** The gaps (full-text search, ACID, semantic similarity) appear only in TM-2026-031 §5.3. They should be in TM-2026-036's replacement section too.

**Response:** Correct. TM-2026-036 §2.2 currently describes what the manifold provides but doesn't repeat the honest "what's still needed" list from TM-2026-031.

**Action:** TM-2026-036 §2.2 gains a "What native manifold operations do NOT cover" subsection listing: full-text keyword search (needs inverted index), ACID multi-record transactions (needs coordination layer), semantic similarity (needs keyword index or embeddings), and arbitrary multi-field predicates (needs application-layer filtering on TPT candidate sets).

---

## Issue 7: debug_assert! vs assert! for Critical Invariants

**Reviewer:** debug_assert! in ags.rs lines 355 and 392 disappears in release builds. For invariants this critical, use assert! or a dedicated error type.

**Response:** Correct. "Generator must divide capacity exactly" and "generators must be coprime" are LOAD-BEARING INVARIANTS (per the repo guide's architectural invariant rules). If these fail, the AGS is in a corrupt state and continuing would produce wrong results silently. They should be full assert! or return Result<T, AgsError>.

**Action:** Changed to assert! with descriptive panic messages. If the framework later moves to a Result-based error model for AGS operations, these become Err returns. For now, panic is correct — a corrupt AGS is unrecoverable.

---

## Answers to Open Questions — Confirmed

**Q1 (Path 4):** Build plain TritInt first. ℤ[φ] extension later as TritPhi wrapper. **Confirmed.**

**Q2 (ℚ(φ) layer):** Later extension. **Confirmed.**

**Q3 (Naming):** Keep "TritInt." Rename to "Trit" only if/when ℤ[φ] is integrated. **Confirmed.**

**Q4 (TypeScript mirror):** Binary bridge via shared/constants.ts suffices. No TypeScript TritInt. **Confirmed.**

---

## Implementation Plan — Confirmed

TritInt is a standalone milestone. The sequence:

```
Milestone: TritInt
  Steps 1–5: const constructors + arithmetic + boundary crossings
  Steps 6–12: runtime arithmetic + traits + serde
  Step 13: heap path for large values
  Deliverable: ternary-math/src/trit_int.rs passing all tests

Milestone: constants.rs Migration (Phase 1)
  Add _T companions to all integer constants
  Compile-time assertions verify _T matches u32
  Zero existing code changes
  Deliverable: cargo test passes with both u32 and TritInt constants

Milestone: AGS Integration
  ags.rs uses TritInt for all arithmetic
  Binary bridge for API consumers
  Deliverable: ags.rs passing all tests, grow/shrink verified

Everything else (TM-2026-036 operating architecture) blocks on these three.
```

---

*Copyright (c) 2025–2026 Capomastro Holdings Ltd. (Canada)*
*Applied Physics Division — Patent(s) Pending — All Rights Reserved*
