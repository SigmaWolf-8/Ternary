# Trit — Ternary-Native Value Type

**Capomastro Holdings Ltd. — Applied Physics Division**
**Patent(s) Pending — All Rights Reserved**
**TM-2026-000 v3.0 — Trit Type Specification**

**Revision History:**
- v1.0: TritInt — flat integer, single trit vector
- v2.0: Trit — three vectors, no opinion about meaning, consumer assigns
- **v3.0: Three always-live vectors: ℤ (integer), φ (golden ratio), ω (cube root of unity). Both reduction rules native. No caps, no sentinels, no modes.**

---

## Section 1: What This Is

Trit is the foundational value type for the Salvi Framework. It represents an element of the form:

```
a + bφ + cω
```

where a, b, c are ternary integers (packed trit vectors), φ is the golden ratio, and ω is the primitive cube root of unity. All three components are always present and always carry real values.

For a plain integer like 364: a = 364, b = 0, c = 0. This is not a "mode" or a "capped state" — it is the mathematically correct representation of 364 in this algebra.

For an icosahedral quantity like R² = 14 + 5φ: a = 14, b = 5, c = 0. The golden ratio component is live.

For an Eisenstein integer like a GF(3) algebraic element: a and c are live, b = 0.

The three components correspond to the three algebraic structures the framework operates in:

| Vector | Coefficient of | Algebra | Reduction Rule | Where It Appears |
|--------|---------------|---------|----------------|-----------------|
| v[0] | 1 | ℤ (integers) | None needed | Every value |
| v[1] | φ | ℤ[φ] (golden ring) | φ² = φ + 1 | Icosahedral geometry, vertex coords, R² |
| v[2] | ω | ℤ[ω] (Eisenstein ring) | ω² + ω + 1 = 0, equivalently ω² = −1 − ω | GF(3) closure, Rep D, algebraic trits |

---

## Section 2: Type Definition

```rust
pub struct Trit {
    v: [TritVec; 3],
}
```

Three vectors because the system is base 3. Three algebraic components because the framework operates in three algebraic domains. These are the same fact.

### 2.1 TritVec (The Storage Primitive)

```rust
pub struct TritVec {
    storage: TritVecStorage,
}

enum TritVecStorage {
    Inline {
        packed: [u8; 8],   // 8 bytes × 5 trits/byte = 40 trits max
        trit_count: u8,
    },
    Heap {
        packed: Vec<u8>,
        trit_count: u32,
    },
}
```

**Packing:** 5 trits per byte (3⁵ = 243 < 256).

**Inline buffer:** 8 bytes = 40 trits. Covers every framework constant.

**Heap path:** Values above 40 trits. Runtime computation only.

**Internal representation:** Rep B {0, 1, 2}. Zero is valid internally as the additive identity.

**Wire representation:** Rep C {1, 2, 3}. Zero = forgery. Conversion at boundary via `to_repr_c()` / `from_repr_c()`. A zero-value TritVec (the additive identity) serializes as an empty trit sequence in Rep C — no zero digits appear on the wire.

**Byte ordering:** LSB-first. packed[0] holds trits 0–4 (least significant).

### 2.2 Packing Scheme

```
byte_value = t₀ + 3·t₁ + 9·t₂ + 27·t₃ + 81·t₄

Extract trit k from the full TritVec:
    byte_index = k / 5
    trit_within_byte = k % 5
    trit = (packed[byte_index] / 3^trit_within_byte) % 3
```

---

## Section 3: Constructors

### 3.1 Scalar (Integer Only)

Most framework values. v[1] and v[2] are the additive identity.

```rust
impl Trit {
    pub const fn zero() -> Self {
        Self { v: [TritVec::zero(), TritVec::zero(), TritVec::zero()] }
    }

    pub const fn one() -> Self {
        Self { v: [TritVec::one(), TritVec::zero(), TritVec::zero()] }
    }

    pub const fn scalar(a: TritVec) -> Self {
        Self { v: [a, TritVec::zero(), TritVec::zero()] }
    }

    pub const fn from_trits(trits: &[u8]) -> Self {
        Self::scalar(TritVec::from_trits(trits))
    }

    pub const fn repunit(n: usize) -> Self {
        Self::scalar(TritVec::repunit(n))
    }
}
```

### 3.2 Golden (ℤ[φ] Element)

Icosahedral geometry. v[0] = integer part, v[1] = φ-coefficient.

```rust
impl Trit {
    pub const fn golden(a: TritVec, b: TritVec) -> Self {
        Self { v: [a, b, TritVec::zero()] }
    }
}
```

### 3.3 Eisenstein (ℤ[ω] Element)

GF(3) algebraic closure. v[0] = integer part, v[2] = ω-coefficient.

```rust
impl Trit {
    pub const fn eisenstein(a: TritVec, c: TritVec) -> Self {
        Self { v: [a, TritVec::zero(), c] }
    }
}
```

### 3.4 Full (All Three Live)

When a computation produces results with all three components:

```rust
impl Trit {
    pub const fn new(a: TritVec, b: TritVec, c: TritVec) -> Self {
        Self { v: [a, b, c] }
    }
}
```

### 3.5 Boundary Crossing (Binary → Trit)

```rust
impl Trit {
    pub const fn from_u64(val: u64) -> Self {
        Self::scalar(TritVec::from_u64(val))
    }
}
```

---

## Section 4: Arithmetic

### 4.1 TritVec Arithmetic (Single Vector, Base-3 Native)

```rust
impl TritVec {
    pub fn add(&self, other: &TritVec) -> TritVec
    pub fn sub(&self, other: &TritVec) -> TritVec
    pub fn mul(&self, other: &TritVec) -> TritVec
    pub fn div_mod(&self, other: &TritVec) -> (TritVec, TritVec)
    pub fn div_repunit(&self, n: usize) -> (TritVec, TritVec)
    pub fn pow(&self, exp: u32) -> TritVec
    pub fn mod_pow(&self, exp: &TritVec, modulus: &TritVec) -> TritVec
    pub fn gcd(a: &TritVec, b: &TritVec) -> TritVec
    pub fn extended_gcd(a: &TritVec, b: &TritVec) -> (TritVec, TritVec, TritVec)
    pub fn add_with_carry(&self, other: &TritVec) -> TritVecAddResult

    // Const versions (inline only, for compile-time constants)
    pub const fn const_add(self, other: TritVec) -> TritVec
    pub const fn const_sub(self, other: TritVec) -> TritVec
    pub const fn const_mul(self, other: TritVec) -> TritVec
    pub const fn const_eq(self, other: TritVec) -> bool
    pub const fn const_lt(self, other: TritVec) -> bool
}
```

All operations on packed trit vectors. No binary conversion.

### 4.2 Trit Addition and Subtraction (Component-Wise, Always Valid)

```rust
impl Trit {
    pub fn add(&self, other: &Trit) -> Trit {
        Trit {
            v: [
                self.v[0].add(&other.v[0]),
                self.v[1].add(&other.v[1]),
                self.v[2].add(&other.v[2]),
            ]
        }
    }

    pub fn sub(&self, other: &Trit) -> Trit {
        Trit {
            v: [
                self.v[0].sub(&other.v[0]),
                self.v[1].sub(&other.v[1]),
                self.v[2].sub(&other.v[2]),
            ]
        }
    }

    pub fn scale(&self, scalar: &TritVec) -> Trit {
        Trit {
            v: [
                self.v[0].mul(scalar),
                self.v[1].mul(scalar),
                self.v[2].mul(scalar),
            ]
        }
    }
}
```

Addition and subtraction are the same regardless of which algebra you're in. They're always component-wise. No reduction rules needed.

### 4.3 Multiplication (Algebra-Specific, Both Native)

Multiplication depends on which reduction rule applies. Both are defined at the foundation level. The consumer calls the one that matches their domain.

**ℤ[φ] multiplication (icosahedral geometry):**

Uses v[0] and v[1]. Applies φ² = φ + 1.

```rust
impl Trit {
    /// Multiply in ℤ[φ]. Uses v[0] (integer) and v[1] (φ-coefficient).
    /// Reduction: φ² = φ + 1.
    ///
    /// (a₁ + b₁φ)(a₂ + b₂φ) = (a₁a₂ + b₁b₂) + (a₁b₂ + a₂b₁ + b₁b₂)φ
    ///
    /// v[2] is carried through unchanged (additive identity preserves).
    pub fn mul_golden(&self, other: &Trit) -> Trit {
        let a1 = &self.v[0]; let b1 = &self.v[1];
        let a2 = &other.v[0]; let b2 = &other.v[1];

        let a1a2 = a1.mul(a2);
        let b1b2 = b1.mul(b2);
        let a1b2 = a1.mul(b2);
        let a2b1 = a2.mul(b1);

        Trit {
            v: [
                a1a2.add(&b1b2),                     // a₁a₂ + b₁b₂
                a1b2.add(&a2b1).add(&b1b2),          // a₁b₂ + a₂b₁ + b₁b₂
                self.v[2].add(&other.v[2]),           // carry v[2] through
            ]
        }
    }
}
```

**ℤ[ω] multiplication (Eisenstein / GF(3) closure):**

Uses v[0] and v[2]. Applies ω² = −1 − ω (equivalently ω² + ω + 1 = 0).

```rust
impl Trit {
    /// Multiply in ℤ[ω]. Uses v[0] (integer) and v[2] (ω-coefficient).
    /// Reduction: ω² = −1 − ω.
    ///
    /// (a₁ + c₁ω)(a₂ + c₂ω) = a₁a₂ + (a₁c₂ + a₂c₁)ω + c₁c₂ω²
    ///                        = (a₁a₂ − c₁c₂) + (a₁c₂ + a₂c₁ − c₁c₂)ω
    ///
    /// v[1] is carried through unchanged.
    pub fn mul_eisenstein(&self, other: &Trit) -> Trit {
        let a1 = &self.v[0]; let c1 = &self.v[2];
        let a2 = &other.v[0]; let c2 = &other.v[2];

        let a1a2 = a1.mul(a2);
        let c1c2 = c1.mul(c2);
        let a1c2 = a1.mul(c2);
        let a2c1 = a2.mul(c1);

        Trit {
            v: [
                a1a2.sub(&c1c2),                     // a₁a₂ − c₁c₂
                self.v[1].add(&other.v[1]),           // carry v[1] through
                a1c2.add(&a2c1).sub(&c1c2),          // a₁c₂ + a₂c₁ − c₁c₂
            ]
        }
    }
}
```

**Scalar multiplication (plain integer):**

When both operands are scalars (v[1] and v[2] at additive identity), either mul_golden or mul_eisenstein produces the same result: v[0] = a₁a₂, v[1] = 0, v[2] = 0. The consumer doesn't need to pick. But for clarity:

```rust
impl Trit {
    /// Multiply scalars (v[0] only). Fastest path.
    pub fn mul_scalar(&self, other: &Trit) -> Trit {
        Trit::scalar(self.v[0].mul(&other.v[0]))
    }
}
```

### 4.4 Norm (Algebra-Specific, Both Native)

**ℤ[φ] norm:** N(a + bφ) = a² + ab − b². Returns a scalar Trit.

```rust
impl Trit {
    pub fn norm_golden(&self) -> Trit {
        let a = &self.v[0]; let b = &self.v[1];
        Trit::scalar(a.mul(a).add(&a.mul(b)).sub(&b.mul(b)))
    }
}
```

**ℤ[ω] norm:** N(a + cω) = a² − ac + c². Returns a scalar Trit.

```rust
impl Trit {
    pub fn norm_eisenstein(&self) -> Trit {
        let a = &self.v[0]; let c = &self.v[2];
        Trit::scalar(a.mul(a).sub(&a.mul(c)).add(&c.mul(c)))
    }
}
```

---

## Section 5: Accessors

```rust
impl TritVec {
    pub fn is_zero(&self) -> bool
    pub fn trit_length(&self) -> usize
    pub fn trit_at(&self, i: usize) -> u8
    pub fn trit_diversity(&self) -> u8
    pub fn is_repunit(&self) -> bool
    pub fn is_power_of_3(&self) -> bool
    pub fn ternary_exponent(&self) -> Option<u32>
    pub fn to_trits(&self) -> Vec<u8>              // LSB-first
    pub fn trits_msb_first(&self) -> Vec<u8>
}

impl Trit {
    pub fn is_zero(&self) -> bool {
        self.v[0].is_zero() && self.v[1].is_zero() && self.v[2].is_zero()
    }

    pub fn is_scalar(&self) -> bool {
        self.v[1].is_zero() && self.v[2].is_zero()
    }

    pub fn is_golden(&self) -> bool {
        !self.v[1].is_zero() && self.v[2].is_zero()
    }

    pub fn is_eisenstein(&self) -> bool {
        self.v[1].is_zero() && !self.v[2].is_zero()
    }

    pub fn integer_part(&self) -> &TritVec { &self.v[0] }
    pub fn golden_part(&self) -> &TritVec { &self.v[1] }
    pub fn eisenstein_part(&self) -> &TritVec { &self.v[2] }
    pub fn vector(&self, i: usize) -> &TritVec { &self.v[i] }
}
```

---

## Section 6: Representation Interop (Rep A, B, C)

Per-vector conversions:

```rust
impl TritVec {
    pub fn to_repr_a(&self) -> Vec<i8>     // Balanced {-1, 0, +1}, MSB-first
    pub fn to_repr_b(&self) -> Vec<u8>     // Standard {0, 1, 2}, MSB-first
    pub fn to_repr_c(&self) -> Vec<u8>     // Bijective {1, 2, 3}, MSB-first
    pub fn from_repr_a(balanced: &[i8]) -> Self
    pub fn from_repr_b(standard: &[u8]) -> Self
    pub fn from_repr_c(bijective: &[u8]) -> Self
}
```

Rep D (AlgebraicTrit = {Zero, One, Omega}) maps directly to v[2]:
- AlgebraicTrit::Zero → ω-coefficient = 0 (additive identity)
- AlgebraicTrit::One → integer part, ω-coefficient = 0
- AlgebraicTrit::Omega → integer part = 0, ω-coefficient = 1

The connection between Rep D and Trit's v[2] is native — not a bolted-on conversion.

---

## Section 7: Boundary Crossings

### 7.1 TritVec → Binary

```rust
impl TritVec {
    pub fn to_u32(&self) -> Result<u32, Overflow>
    pub fn to_u64(&self) -> Result<u64, Overflow>
    pub fn to_u128(&self) -> Result<u128, Overflow>
    pub fn to_decimal(&self) -> u64
    pub const fn to_u32_const(self) -> u32
    pub const fn to_u64_const(self) -> u64
}
```

### 7.2 Binary → TritVec

```rust
impl TritVec {
    pub fn from_u32(val: u32) -> Self
    pub fn from_u64(val: u64) -> Self
    pub fn from_u128(val: u128) -> Self
    pub const fn from_u64_const(val: u64) -> Self
}
```

### 7.3 Trit → f64 (Evaluation)

```rust
impl Trit {
    /// Evaluate as f64: a + b·φ + c·ω.
    /// BOUNDARY CROSSING — exits exact ternary arithmetic into floating point.
    /// Used for display, CODATA comparison, rendering coordinates.
    pub fn to_f64(&self) -> f64 {
        const PHI: f64 = 1.618_033_988_749_895;
        const OMEGA_REAL: f64 = -0.5;  // Re(ω) = −1/2
        let a = self.v[0].to_decimal() as f64;
        let b = self.v[1].to_decimal() as f64;
        let c = self.v[2].to_decimal() as f64;
        a + b * PHI + c * OMEGA_REAL
    }
}
```

### 7.4 Scalar Trit → Binary

```rust
impl Trit {
    pub fn to_u64(&self) -> Result<u64, Overflow> {
        if !self.is_scalar() {
            return Err(Overflow::NonScalar);
        }
        self.v[0].to_u64()
    }
}
```

---

## Section 8: Display and Formatting

```rust
impl Display for TritVec {
    // "210₃"
}

impl Display for Trit {
    // Scalar:     "210₃"
    // Golden:     "112₃ + 12₃φ"          (14 + 5φ)
    // Eisenstein: "21₃ + 2₃ω"
    // Full:       "112₃ + 12₃φ + 2₃ω"
}
```

---

## Section 9: Rust Traits

### 9.1 TritVec

```rust
impl Add, Sub, Mul, Div, Rem for TritVec { ... }
impl AddAssign, SubAssign, MulAssign for TritVec { ... }
impl PartialEq, Eq, PartialOrd, Ord for TritVec { ... }
impl Hash, Clone for TritVec { ... }
```

### 9.2 Trit

```rust
impl Add for Trit { ... }        // component-wise, always valid
impl Sub for Trit { ... }        // component-wise, always valid
impl PartialEq, Eq for Trit { ... }
impl Hash, Clone for Trit { ... }
```

Mul, Div, Ord are NOT blanket-implemented on Trit. Multiplication requires choosing an algebra (mul_golden, mul_eisenstein, or mul_scalar). Ordering requires knowing which components are semantically active.

### 9.3 Zeroize and Serde

```rust
impl zeroize::Zeroize for TritVec { ... }  // zero inline + heap
impl zeroize::Zeroize for Trit { ... }     // zero all three vectors

#[cfg(feature = "serde")]
impl Serialize for Trit { ... }   // serialize all three as Rep C arrays
impl Deserialize for Trit { ... }
```

---

## Section 10: Framework Constants

### 10.1 Scalar Constants

```rust
pub const REPUNIT_6_T: Trit = Trit::repunit(6);
pub const ROOT_X1_T: Trit = Trit::from_trits(&[2, 1, 1]);           // 14 = π
pub const ARC_ROOT_SEMI_T: Trit = Trit::from_trits(&[2,2,0,0,2]);   // 182
pub const DISCRIMINANT_2_T: Trit = Trit::from_trits(&[0,0,0,0,0,0,1]); // 729
```

### 10.2 Golden Constants

```rust
pub const R_SQUARED_T: Trit = Trit::golden(
    TritVec::from_trits(&[2, 1, 1]),    // 14 = π
    TritVec::from_trits(&[2, 1]),       //  5
);
// R² = 14 + 5φ. Norm = 241 (prime).

pub const ICOSA_CIRCUMRADIUS_SQ_T: Trit = Trit::golden(
    TritVec::from_trits(&[2]),          //  2
    TritVec::from_trits(&[1]),          //  1
);
// 2 + φ
```

### 10.3 Compile-Time Verification

```rust
const _: () = assert!(REPUNIT_6_T.v[0].to_u32_const() == 364);
const _: () = assert!(R_SQUARED_T.v[0].to_u32_const() == 14);   // integer part = π
const _: () = assert!(R_SQUARED_T.v[1].to_u32_const() == 5);    // φ-coefficient
const _: () = assert!(R_SQUARED_T.v[2].to_u32_const() == 0);    // ω-coefficient = identity
```

---

## Section 11: Build Sequence

```
Step 1:   TritVec struct + packing/unpacking
Step 2:   TritVec const constructors (zero, one, repunit, from_trits)
Step 3:   TritVec const comparison (const_eq, const_lt)
Step 4:   TritVec const arithmetic (const_add, const_sub, const_mul)
Step 5:   TritVec boundary crossings (to_u32_const, from_u64_const)
Step 6:   Trit struct wrapping [TritVec; 3]
Step 7:   Trit constructors (zero, one, scalar, golden, eisenstein, new)
Step 8:   Trit add/sub (component-wise) + scale
Step 9:   Trit mul_golden (φ² = φ + 1 reduction)
Step 10:  Trit mul_eisenstein (ω² + ω + 1 = 0 reduction)
Step 11:  Trit norm_golden + norm_eisenstein
Step 12:  Trit accessors (is_scalar, is_golden, is_eisenstein)
Step 13:  TritVec runtime arithmetic (div_mod, pow, mod_pow, gcd)
Step 14:  TritVec div_repunit optimization
Step 15:  TritVec representation interop (Rep A/B/C)
Step 16:  Trait implementations
Step 17:  Zeroize + Serde
Step 18:  Heap path (values > 40 trits)
```

Steps 1–12 deliver the complete Trit type with both algebras.
Steps 13–18 fill out runtime operations and production hardening.

---

## Section 12: Backward Compatibility

Unchanged from v2.0:

1. Existing u32 constants stay
2. New `_T` companions added alongside
3. Compile-time assertions verify both match
4. Modules migrate individually
5. No flag day

---

## Section 13: Consumer Modules

### 13.1 tri182.rs

Icosahedral geometry. Uses `mul_golden`, `norm_golden`. Defines R², vertex coordinates, face angle cosines, Fibonacci-weighted projection from 27-trit addresses to ℤ[φ] coordinates. All exact, no floating point.

### 13.2 gf3_algebra.rs (Extended)

GF(3) algebraic closure via ℤ[ω]. Uses `mul_eisenstein`, `norm_eisenstein`. Extends existing Rep D (AlgebraicTrit) to operate on Trit v[2] natively.

### 13.3 ags.rs

Active Generator Set. Uses scalar Trit values only (v[1] = v[2] = identity). Calls `mul_scalar` for growth, `div_mod` for shrink.

---

*Copyright (c) 2025–2026 Capomastro Holdings Ltd. (Canada)*
*Applied Physics Division — Patent(s) Pending — All Rights Reserved*
