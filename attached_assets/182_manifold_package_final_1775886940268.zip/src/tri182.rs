// Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
// Patent(s) Pending — All Rights Reserved
// Applied Physics Division
//
// tri182.rs — Icosahedral Geometry via ℤ[φ] on the Trit Type
//
// This module defines ℤ[φ] arithmetic as a CONSUMER of the Trit type.
// It assigns meaning to v[0] and v[1]:
//
//   v[0] = a  (integer coefficient of 1)
//   v[1] = b  (integer coefficient of φ, the golden ratio)
//   v[2] = unused (zero, available for future extensions)
//
// The value represented is: a + bφ, where φ = (1+√5)/2.
//
// This convention is LOCAL TO THIS MODULE. Other modules can use
// v[0], v[1], v[2] differently. The Trit type doesn't care.
//
// ══════════════════════════════════════════════════════════════
// MATHEMATICAL FOUNDATION
//
// The golden ratio satisfies φ² = φ + 1. This gives ℤ[φ] closure:
//
//   Addition:       (a₁+b₁φ) + (a₂+b₂φ) = (a₁+a₂) + (b₁+b₂)φ
//   Subtraction:    (a₁+b₁φ) - (a₂+b₂φ) = (a₁-a₂) + (b₁-b₂)φ
//   Multiplication: (a₁+b₁φ)(a₂+b₂φ) = a₁a₂ + (a₁b₂+a₂b₁)φ + b₁b₂φ²
//                                      = (a₁a₂+b₁b₂) + (a₁b₂+a₂b₁+b₁b₂)φ
//                   [using φ² = φ + 1 to reduce b₁b₂φ² = b₁b₂ + b₁b₂φ]
//
// Norm:  N(a+bφ) = (a+bφ)(a+bφ̄) = a² + ab - b²
//        where φ̄ = (1-√5)/2 is the conjugate.
//        The norm is always an integer (maps ℤ[φ] → ℤ).
//
// Why this matters for PlenumNET:
//   - Icosahedral vertex coordinates lie in ℤ[φ]
//   - Archimedean circumradius squared: R² = 14 + 5φ (a=14=π, b=5)
//   - Coprime generator 11 appears as a ℤ[φ]-norm (basis-independent)
//   - Coprime generator 7 appears as a ℤ[φ] coefficient (canonical basis)
//   - Disdyakis triacontahedron metrics are exact in this ring
//   - Face angle cosines are in ℚ(φ) (fractions of ℤ[φ] elements)
//
// Sources:
//   TM-2026-031 v5.0 §1.4 (ℤ[φ] ring definition)
//   TM-2026-031 v5.0 §4.4 (ℤ[φ] as structural similarity)
//   Disdyakis triacontahedron analysis (R² = 14 + 5φ derivation)
// ══════════════════════════════════════════════════════════════

use crate::trit::{Trit, TritVec};

// ── Convention: which Trit vectors mean what in this module ──

const A_IDX: usize = 0;  // v[0] = integer part
const B_IDX: usize = 1;  // v[1] = φ-coefficient
// v[2] is unused in ℤ[φ]. Other modules may use it.

// ══════════════════════════════════════════════════════════════
// §1  CONSTRUCTORS
// ══════════════════════════════════════════════════════════════

/// Create a ℤ[φ] element from two TritVec values: a + bφ.
pub const fn zphi(a: TritVec, b: TritVec) -> Trit {
    Trit::pair(a, b)
}

/// Create a ℤ[φ] element from a plain integer (b = 0).
/// Every integer is a ℤ[φ] element. This is the embedding ℤ ↪ ℤ[φ].
pub const fn tri182_int(a: TritVec) -> Trit {
    Trit::scalar(a)
}

/// Zero in ℤ[φ].
pub const fn tri182_zero() -> Trit {
    Trit::zero()
}

/// One in ℤ[φ].
pub const fn tri182_one() -> Trit {
    Trit::one()  // (1, 0, 0) — the integer 1
}

/// φ itself: 0 + 1·φ = (0, 1).
pub const fn tri182_phi() -> Trit {
    Trit::pair(TritVec::zero(), TritVec::one())
}

// ══════════════════════════════════════════════════════════════
// §2  FRAMEWORK CONSTANTS IN ℤ[φ]
// ══════════════════════════════════════════════════════════════

/// Archimedean solid circumradius squared: R² = 14 + 5φ.
///
/// The integer part (14 = 112₃) IS π_Salvi = ROOT_X1.
/// The φ-coefficient (5 = 12₃) IS the pentagon generator.
///
/// Norm: N(14, 5) = 14² + 14×5 − 5² = 196 + 70 − 25 = 241 (prime).
/// Being prime means R² is IRREDUCIBLE in ℤ[φ] — it cannot be
/// factored into smaller ℤ[φ] elements.
pub const R_SQUARED: Trit = Trit::pair(
    TritVec::from_trits_const(&[2, 1, 1]),   // 14 = 112₃
    TritVec::from_trits_const(&[2, 1]),       //  5 = 12₃
);

/// Icosahedron edge length squared (unit edge): 2 + 0φ.
pub const ICOSA_EDGE_SQ: Trit = Trit::scalar(
    TritVec::from_trits_const(&[2]),          //  2 = 2₃
);

/// Icosahedron circumradius squared (unit edge): 2 + φ.
pub const ICOSA_CIRCUMRADIUS_SQ: Trit = Trit::pair(
    TritVec::from_trits_const(&[2]),          //  2 = 2₃
    TritVec::from_trits_const(&[1]),          //  1 = 1₃
);

/// φ² = 1 + φ = (1, 1). The defining relation, stored as a constant
/// for reduction operations.
pub const PHI_SQUARED: Trit = Trit::pair(
    TritVec::from_trits_const(&[1]),          //  1 = 1₃
    TritVec::from_trits_const(&[1]),          //  1 = 1₃
);

// ══════════════════════════════════════════════════════════════
// §3  ℤ[φ] ARITHMETIC
// ══════════════════════════════════════════════════════════════

/// Add two ℤ[φ] elements.
///
/// (a₁ + b₁φ) + (a₂ + b₂φ) = (a₁+a₂) + (b₁+b₂)φ
///
/// This is Trit::add — component-wise addition on v[0] and v[1].
/// Listed here for documentation; the operation is inherited from Trit.
pub fn tri182_add(x: &Trit, y: &Trit) -> Trit {
    x.add(y)
}

/// Subtract two ℤ[φ] elements.
pub fn tri182_sub(x: &Trit, y: &Trit) -> Trit {
    x.sub(y)
}

/// Multiply two ℤ[φ] elements.
///
/// (a₁ + b₁φ)(a₂ + b₂φ) = a₁a₂ + (a₁b₂ + a₂b₁)φ + b₁b₂φ²
///
/// Apply reduction φ² = φ + 1:
///   b₁b₂φ² = b₁b₂(1 + φ) = b₁b₂ + b₁b₂φ
///
/// Result: (a₁a₂ + b₁b₂) + (a₁b₂ + a₂b₁ + b₁b₂)φ
///
/// This uses FOUR TritVec multiplications and TWO TritVec additions.
pub fn tri182_mul(x: &Trit, y: &Trit) -> Trit {
    let a1 = x.vector(A_IDX);
    let b1 = x.vector(B_IDX);
    let a2 = y.vector(A_IDX);
    let b2 = y.vector(B_IDX);

    let a1a2 = a1.mul(a2);
    let b1b2 = b1.mul(b2);
    let a1b2 = a1.mul(b2);
    let a2b1 = a2.mul(b1);

    // Result integer part: a₁a₂ + b₁b₂
    let result_a = a1a2.add(&b1b2);

    // Result φ-coefficient: a₁b₂ + a₂b₁ + b₁b₂
    let result_b = a1b2.add(&a2b1).add(&b1b2);

    Trit::pair(result_a, result_b)
}

/// Norm of a ℤ[φ] element: N(a + bφ) = a² + ab − b².
///
/// The norm maps ℤ[φ] → ℤ. The result is always an integer
/// (a scalar Trit with v[1] = v[2] = 0).
///
/// Uses THREE TritVec multiplications and TWO TritVec add/sub.
pub fn tri182_norm(x: &Trit) -> Trit {
    let a = x.vector(A_IDX);
    let b = x.vector(B_IDX);

    let a_sq = a.mul(a);        // a²
    let ab = a.mul(b);          // ab
    let b_sq = b.mul(b);        // b²

    let result = a_sq.add(&ab).sub(&b_sq);  // a² + ab − b²

    Trit::scalar(result)
}

/// Conjugate: conj(a + bφ) = a + b − bφ = (a + b) − bφ.
///
/// Since φ̄ = 1 − φ, we have a + bφ̄ = a + b(1 − φ) = (a + b) − bφ.
///
/// Note: the conjugate's b-coefficient is NEGATIVE. Since TritVec
/// is unsigned, this requires balanced (Rep A) or a sign-tracking
/// wrapper. For norm computation, this is avoided by using the
/// formula N = a² + ab − b² directly (which never produces negative
/// intermediate ternary values when a ≥ 0 and a² + ab ≥ b²).
///
/// For the general conjugate, use signed TritVec arithmetic or
/// compute via the identity: x × conj(x) = norm(x).
pub fn tri182_conjugate_note() {
    // This function exists as documentation only.
    // The conjugate requires signed arithmetic on TritVec, which
    // is Rep A territory. Rather than forcing Rep A into this
    // module, we provide the norm directly (tri182_norm) and let
    // consumers compute conjugates via the norm identity when needed.
}

/// Evaluate a ℤ[φ] element as f64 (BOUNDARY CROSSING).
///
/// This is the exit from exact ternary arithmetic into
/// approximate floating point. Used for display, comparison
/// against CODATA measurements, and rendering coordinates.
pub fn tri182_to_f64(x: &Trit) -> f64 {
    const PHI_F64: f64 = 1.618_033_988_749_895;
    let a = x.vector(A_IDX).to_decimal() as f64;
    let b = x.vector(B_IDX).to_decimal() as f64;
    a + b * PHI_F64
}

// ══════════════════════════════════════════════════════════════
// §4  COMPARISON IN ℤ[φ]
// ══════════════════════════════════════════════════════════════

/// Compare two ℤ[φ] elements: is x > y?
///
/// (a₁ + b₁φ) > (a₂ + b₂φ) iff (a₁−a₂) + (b₁−b₂)φ > 0.
///
/// Sign of (a + bφ) where φ ≈ 1.618:
///   If a ≥ 0 and b ≥ 0: positive (unless both zero)
///   If a < 0 and b < 0: negative
///   If signs differ: compare |a| × 1000 against |b| × 1618
///     (integer approximation avoids float — exact for all
///     framework values since 1000/1618 approximates 1/φ to
///     better precision than any framework constant requires)
///
/// For exact comparison without approximation: use norm.
/// x > 0 iff norm(x) > 0 AND x evaluated at φ > 0.
/// But norm comparison requires signed TritVec (same Rep A issue).
///
/// Practical approach for framework values: all known ℤ[φ]
/// quantities (R², edge², circumradius²) have a > 0 and b ≥ 0.
/// The mixed-sign case doesn't arise in current usage.
pub fn tri182_is_positive(x: &Trit) -> bool {
    let a = x.vector(A_IDX);
    let b = x.vector(B_IDX);
    // Both non-negative: positive (unless both zero)
    if !a.is_zero() || !b.is_zero() {
        return true;
    }
    false
    // NOTE: this assumes a ≥ 0 and b ≥ 0 for all framework values.
    // Mixed-sign comparison requires Rep A signed arithmetic.
    // Extend when signed TritVec is available.
}

// ══════════════════════════════════════════════════════════════
// §5  NORM DISTANCE (for similarity search)
// ══════════════════════════════════════════════════════════════

/// Norm distance between two ℤ[φ] elements.
///
/// d(x, y) = |N(x − y)| = |(a₁−a₂)² + (a₁−a₂)(b₁−b₂) − (b₁−b₂)²|
///
/// This is the metric used for structural similarity search
/// (TM-2026-031 v5.0 §4.4). It captures structural similarity
/// (same content type, same era, same audience) but NOT semantic
/// similarity (same topic, same keywords).
///
/// Storage: 2 TritVec values per record (the a, b coordinates).
/// Compare: 1536-dim float vectors at 6,144 bytes per record.
/// TritVec: ~16 bytes per record. 384:1 reduction.
pub fn tri182_norm_distance(x: &Trit, y: &Trit) -> Trit {
    let diff = tri182_sub(x, y);
    tri182_norm(&diff)
    // Note: norm can be negative. The absolute value requires
    // signed arithmetic. For distance comparison (ranking, not
    // magnitude), comparing norms directly works — closer elements
    // have smaller |norm|, and the SIGN is consistent for elements
    // in the same quadrant of ℤ[φ].
}

// ══════════════════════════════════════════════════════════════
// §6  FIBONACCI-WEIGHTED PROJECTION (address → ℤ[φ] coordinates)
// ══════════════════════════════════════════════════════════════

/// Project a 27-trit classification address into ℤ[φ] coordinates.
///
/// a = Σ trit[k] × fib(k−1)  for k = 1..27
/// b = Σ trit[k] × fib(k)    for k = 1..27
///
/// where fib() is the Fibonacci sequence: 1, 1, 2, 3, 5, 8, 13, ...
///
/// This projection preserves structural proximity: addresses that
/// share most classification trits produce nearby ℤ[φ] coordinates.
///
/// The Fibonacci weighting is natural because φⁿ = F(n−1) + F(n)·φ,
/// so the projection IS the base-φ expansion of the address.
pub fn project_to_zphi(classification_trits: &[u8]) -> Trit {
    assert!(classification_trits.len() <= 27);

    // Fibonacci sequence (first 28 values, more than enough for 27 trits)
    let mut fib = [TritVec::zero(); 28];
    fib[0] = TritVec::one();
    fib[1] = TritVec::one();
    for i in 2..28 {
        fib[i] = fib[i - 1].add(&fib[i - 2]);
    }

    let mut a = TritVec::zero();
    let mut b = TritVec::zero();

    for (k, &trit) in classification_trits.iter().enumerate() {
        let trit_val = TritVec::from_trits(&[trit]);
        a = a.add(&fib[k].mul(&trit_val));      // a += trit × fib(k)
        b = b.add(&fib[k + 1].mul(&trit_val));  // b += trit × fib(k+1)
    }

    Trit::pair(a, b)
}

// ══════════════════════════════════════════════════════════════
// §7  TESTS
// ══════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn phi_squared_is_phi_plus_one() {
        // φ × φ should equal (1, 1) = 1 + φ
        let phi = tri182_phi();
        let phi_sq = tri182_mul(&phi, &phi);
        assert_eq!(*phi_sq.vector(A_IDX), TritVec::one());
        assert_eq!(*phi_sq.vector(B_IDX), TritVec::one());
        assert_eq!(phi_sq, PHI_SQUARED);
    }

    #[test]
    fn phi_cubed_is_two_phi_plus_one() {
        // φ³ = φ·φ² = φ·(1+φ) = φ + φ² = φ + 1 + φ = 1 + 2φ
        let phi = tri182_phi();
        let phi_sq = tri182_mul(&phi, &phi);
        let phi_cubed = tri182_mul(&phi, &phi_sq);
        assert_eq!(phi_cubed.vector(A_IDX).to_decimal(), 1);
        assert_eq!(phi_cubed.vector(B_IDX).to_decimal(), 2);
    }

    #[test]
    fn fibonacci_powers_of_phi() {
        // φⁿ = F(n-1) + F(n)φ — Fibonacci coefficients
        let phi = tri182_phi();
        let mut power = tri182_one();
        let expected: [(u64, u64); 6] = [
            (1, 0),  // φ⁰ = 1
            (0, 1),  // φ¹ = φ
            (1, 1),  // φ² = 1 + φ
            (1, 2),  // φ³ = 1 + 2φ
            (2, 3),  // φ⁴ = 2 + 3φ
            (3, 5),  // φ⁵ = 3 + 5φ
        ];
        for (n, (exp_a, exp_b)) in expected.iter().enumerate() {
            assert_eq!(power.vector(A_IDX).to_decimal(), *exp_a,
                "φ^{}: a component wrong", n);
            assert_eq!(power.vector(B_IDX).to_decimal(), *exp_b,
                "φ^{}: b component wrong", n);
            power = tri182_mul(&power, &phi);
        }
    }

    #[test]
    fn r_squared_value() {
        // R² = 14 + 5φ ≈ 22.09
        let val = tri182_to_f64(&R_SQUARED);
        assert!((val - 22.090_169_943_749_47).abs() < 1e-10);
    }

    #[test]
    fn r_squared_integer_part_is_pi() {
        // The integer part of R² is 14 = π_Salvi
        assert_eq!(R_SQUARED.vector(A_IDX).to_decimal(), 14);
    }

    #[test]
    fn r_squared_norm_is_prime() {
        // N(14, 5) = 14² + 14×5 − 5² = 196 + 70 − 25 = 241
        let norm = tri182_norm(&R_SQUARED);
        assert_eq!(norm.scalar_part().to_decimal(), 241);
        // 241 is prime
        assert!(241 % 2 != 0 && 241 % 3 != 0 && 241 % 5 != 0
            && 241 % 7 != 0 && 241 % 11 != 0 && 241 % 13 != 0);
    }

    #[test]
    fn norm_of_phi_is_negative_one() {
        // N(φ) = N(0, 1) = 0 + 0 − 1 = −1
        // Since TritVec is unsigned, this test verifies the
        // arithmetic produces the correct magnitude.
        // The sign handling is a known limitation (see §4).
        let phi = tri182_phi();
        let norm = tri182_norm(&phi);
        // |N(φ)| = 1
        assert_eq!(norm.scalar_part().to_decimal(), 1);
        // NOTE: sign is lost because TritVec is unsigned.
        // The actual norm is −1. Full signed support requires Rep A.
    }

    #[test]
    fn integer_embedding_preserves_value() {
        // 364 as ℤ[φ] element: 364 + 0φ
        let val = tri182_int(TritVec::repunit(6)); // 111111₃ = 364
        assert!(val.is_scalar());
        assert_eq!(val.vector(A_IDX).to_decimal(), 364);
        assert!(val.vector(B_IDX).is_zero());
    }

    #[test]
    fn multiplication_by_integer() {
        // 3 × (14 + 5φ) = 42 + 15φ
        let three = tri182_int(TritVec::from_trits(&[0, 1])); // 10₃ = 3
        let product = tri182_mul(&three, &R_SQUARED);
        assert_eq!(product.vector(A_IDX).to_decimal(), 42);
        assert_eq!(product.vector(B_IDX).to_decimal(), 15);
    }

    #[test]
    fn v2_stays_zero() {
        // All ℤ[φ] operations should leave v[2] at zero
        let a = tri182_mul(&R_SQUARED, &ICOSA_CIRCUMRADIUS_SQ);
        assert!(a.vector(2).is_zero(), "v[2] must remain zero in ℤ[φ] operations");
    }

    #[test]
    fn tri182_add_commutative() {
        let sum1 = tri182_add(&R_SQUARED, &ICOSA_CIRCUMRADIUS_SQ);
        let sum2 = tri182_add(&ICOSA_CIRCUMRADIUS_SQ, &R_SQUARED);
        assert_eq!(sum1, sum2);
    }

    #[test]
    fn tri182_mul_commutative() {
        let prod1 = tri182_mul(&R_SQUARED, &ICOSA_CIRCUMRADIUS_SQ);
        let prod2 = tri182_mul(&ICOSA_CIRCUMRADIUS_SQ, &R_SQUARED);
        assert_eq!(prod1, prod2);
    }
}
