# The 182° Manifold — Project Summary

**Capomastro Holdings Ltd. — Applied Physics Division**
**Patent(s) Pending — All Rights Reserved**
**April 2026**

---

## What Is This?

PlenumNET's mathematics run on a different geometry than conventional computing. In our system, the number π equals exactly 14, a full circle is 364 degrees (not 360), and every triangle's angles add up to 182 degrees (not 180).

This isn't a rounding error. It's a deliberate design that produces a complete, self-consistent mathematical framework where every important number — from database capacities to network routes to cryptographic keys to spectral wavelengths — derives from one equation.

This document package describes how that geometry becomes the foundation for storage, search, routing, and AI memory across the entire PlenumNET stack.

---

## The Core Idea in One Paragraph

Every piece of content in PlenumNET gets a 54-digit address (in base 3) computed from what the content actually IS. That address works as a database key, a file path, a network route, a similarity score, and an integrity check — all at once. The address space automatically grows when you add data and shrinks when you remove it. No configuration. No migration. No capacity planning. The mathematics handle it.

---

## What's in This Package

### Documents

| File | What It Is | Who Should Read It |
|------|-----------|-------------------|
| **This file (README.md)** | Plain-English overview | Everyone |
| **TM-2026-000_Trit_Specification_v2.0.md** | The spec for Trit — a value type with three base-3 vectors. The type carries no opinion about what the three vectors mean. Consumers assign meaning. | Developers building the type |
| **TM-2026-031_v5.0.md** | The mathematical reference — every formula, every capacity number, every derivation chain, with honest labels on what's proven vs. speculative | Mathematicians, architects |
| **TM-2026-036_v2.0.md** | The operating architecture — how the manifold replaces SQL, replaces the filesystem, and provides AI memory | System architects, product team |
| **REVIEW_RESPONSE.md** | Point-by-point response to the Replit review | Anyone who read the review |

### Code

| File | What It Is | Status |
|------|-----------|--------|
| **constants.rs** | Updated framework constants file with four new sections added to the existing 1,639 lines | Ready to merge — zero existing code changed |
| **ags.rs** | The Active Generator Set module — handles automatic growth and shrink of address spaces using ternary-native arithmetic | Requires Trit type to be built first |
| **tri182.rs** | Icosahedral geometry module — ℤ[φ] arithmetic as a CONSUMER of the Trit type. Defines R² = 14 + 5φ, norm, multiplication, Fibonacci projection. | Requires Trit type to be built first |

---

## The Five Things This Package Defines

### 1. The 182° Triangle (Why Our Geometry Is Different)

In standard geometry, a triangle's angles add up to 180°. In ours, they add up to 182°. That extra 2° per triangle isn't waste — it's structural information baked into the surface itself.

What it gives you: a surface where you can verify data integrity from the shape of the surface alone. If a database is complete, its total curvature adds up to exactly 728° (two full circles of 364°). If it doesn't add up, something is missing or corrupted. This is a mathematical fact, not a software check.

**Defined in:** constants.rs §3a, TM-2026-031 §1.2

### 2. The Coprime Walks (How Addressing Works)

The framework uses sets of numbers that share no common factors (coprime numbers) to create address spaces. The key property: a walk through these addresses visits every position exactly once before repeating. No collisions. No wasted slots.

The address space sizes come from multiplying these coprime numbers together:

- 2 coprime numbers: up to 210 addresses
- 3 coprime numbers: up to 2,730 addresses
- 4 coprime numbers: up to 30,030 addresses
- 5 coprime numbers: up to 120,120 addresses
- 6 coprime numbers: up to 360,360 addresses
- With depth layers (×729): up to 262 million addresses
- Across the network (×1.59 million nodes): up to 418 trillion addresses

These aren't choices you make. The system starts small and grows automatically through these levels as data accumulates.

**Defined in:** constants.rs §7, TM-2026-031 Part II

### 3. The Active Generator Set / AGS (How It Grows and Shrinks)

The AGS is the mechanism that makes address spaces elastic. It starts with two numbers (11 and 13 — the only primes in the polygon set that don't conflict with anything else). As data fills up, the AGS adds another coprime number, which multiplies the address capacity. When data is deleted, the AGS removes a number, shrinking the space.

Growing the address space takes ONE multiplication. Shrinking takes ONE division. Existing data doesn't move — the new addresses are interleaved between existing ones.

The decision to grow or shrink is automatic: grow when the space is 75% full, shrink when it drops below 25%. These thresholds come from the framework's own signal analysis (the HModal duty cycle), not from engineering judgment.

**Defined in:** constants.rs §7a, ags.rs, TM-2026-031 Part III

### 4. The Golden Ratio Ring / ℤ[φ] (Where Geometry Lives)

Many of the framework's geometric quantities involve the golden ratio φ ≈ 1.618. The circumradius squared of the parent Archimedean solid is R² = 14 + 5φ — and the 14 IS our value of π. This isn't a coincidence; the golden ratio is algebraically required by icosahedral symmetry, and the framework's coprime generators (7, 11, 13) appear naturally in the ℤ[φ] arithmetic of these solids.

The ZPhi type in constants.rs stores values as (a, b) meaning a + b×φ, where a and b are integers. All arithmetic stays exact — no floating point, no rounding. The golden ratio's defining property φ² = φ + 1 keeps everything in the ring.

**Defined in:** constants.rs §18, TM-2026-031 §1.4

### 5. Trit (The Foundation We Need to Build)

Today, every constant in the framework is stored as a binary number (u32 in Rust). The value 364 is stored as binary 101101100. But 364 in our system is 111111 in base 3 — a repunit (all ones). Storing it in binary hides this structure.

Trit is a new value type that stores three base-3 vectors:

```rust
pub struct Trit {
    v: [TritVec; 3],
}
```

Three vectors because the system is base 3. The type doesn't decide what the three vectors mean — that's determined by the code using it:

- **Most constants today:** Use v[0] only. The value 364 is v[0] = 111111₃, v[1] = 0, v[2] = 0.
- **Icosahedral geometry (tri182.rs):** Uses v[0] as the integer part and v[1] as the golden ratio coefficient. R² = 14 + 5φ is v[0] = 112₃, v[1] = 12₃, v[2] = 0.
- **Future modules:** Can use v[2] for whatever they need. The foundation doesn't change.

When you do arithmetic on Trit, it operates on all three vectors. When v[1] and v[2] are zero, the arithmetic on them naturally produces zero — essentially free.

The golden ratio arithmetic (how to multiply and take norms of ℤ[φ] elements) is defined separately in tri182.rs, which is a CONSUMER of the Trit type. The Trit type itself has no opinion about the golden ratio.

**Specified in:** TM-2026-000 v2.0

---

## How the Pieces Fit Together

```
Trit (Step 0 — BUILD THIS FIRST)
  │
  │ ← TritVec: packed base-3 storage primitive
  │ ← Trit: three TritVec slots, meaning assigned by consumers
  │ ← invisible binary conversion at API boundaries
  │
  ├──→ tri182.rs (Step 0b — ℤ[φ] arithmetic on Trit)
  │      │
  │      │ ← assigns v[0]=integer part, v[1]=φ-coefficient
  │      │ ← R² = 14 + 5φ, norm, multiplication, projection
  │      │ ← v[2] unused (available for future)
  │      │
  │      └──→ icosahedral geometry, rendering, mesh coordinates
  │
  ├──→ constants.rs (Step 1 — add Trit companions to existing constants)
  │      │
  │      │ ← existing u32 constants stay unchanged
  │      │ ← new _T constants added alongside
  │      │ ← compile-time assertions verify both match
  │      │
  │      └──→ all 12 ternary-math modules (migrate individually)
  │
  └──→ ags.rs (Step 2 — AGS module on top of Trit)
         │
         │ ← automatic address space growth/shrink
         │ ← all arithmetic in base 3, scalar Trit values
         │
         └──→ Operating Architecture (TM-2026-036)
```

---

## What's Done, What's Next

| Item | Status |
|------|--------|
| Mathematical framework (π=14, 364° circle, arc equation, coprime walks) | **Done** — proven, tested, in production |
| constants.rs update (§3a triangle, §3b transfer matrix, §7a AGS, §18 ℤ[φ]) | **Done** — ready to merge, no existing code broken |
| TM-2026-031 v5.0 (mathematical reference) | **Done** — critically reviewed, speculative items labeled |
| TM-2026-036 v2.0 (operating architecture) | **Done** — AGS-aware, gaps listed, eigenvalue caveat added |
| TM-2026-000 v2.0 (Trit spec) | **Done** — three vectors, no opinion about meaning |
| tri182.rs (icosahedral ℤ[φ] module) | **Written** — depends on Trit type existing first |
| ags.rs (AGS module) | **Written** — depends on Trit type existing first |
| Trit implementation (TritVec + Trit) | **Next** — this is the foundation everything else sits on |
| constants.rs Trit migration | **After Trit** — add _T companions, verify with assertions |
| Module-by-module migration | **After constants.rs** — each of 12 ternary-math modules individually |

---

## Decisions (Confirmed After Review)

1. **Trit has three vectors.** Three slots because base 3. No opinion about meaning. Consumers assign meaning. No enum dispatch, no branching.

2. **ℤ[φ] is defined separately in tri182.rs.** It's a consumer of Trit, not embedded in it. Uses v[0] and v[1]. v[2] available for future use. Multiplication, norm, and Fibonacci projection are defined in this module.

3. **The type is called "Trit."** Not "TritInt" — it's not just integers. Three trit vectors, meaning determined at runtime.

4. **No TypeScript Trit.** The React frontend uses the existing binary bridge (u32 values via shared/constants.ts). The frontend displays numbers — it doesn't do ternary arithmetic.

5. **8-byte inline buffer per TritVec** (40 trits each). Covers every framework constant. Values above 3⁴⁰ use the heap path.

6. **Eigenvalue-driven memory tier migration is the target, not the initial implementation.** Initial implementation uses LRU-based aging until the arc equation recurrence is empirically validated against real access patterns.

---

*Copyright (c) 2025–2026 Capomastro Holdings Ltd. (Canada)*
*Applied Physics Division — Patent(s) Pending — All Rights Reserved*
