# FULCRUM &amp; ARCHIMEDES — CANONICAL COMPENDIUM

**Author:** Roberto Salvalaggio — *Lo Sono Capomastro*
**Division:** Capomastro Holdings Ltd., Applied Physics Division — Sherwood Park, Alberta, Canada
**Issued:** 2026-04-19 — canonical, issued to supersede all prior drafts
**Governing Unit (STD):** **23/77** — Salvi Compendium Density ratio
**Companion:** FULCRUM-ARCHIMEDES-CODEX.md (full work shown)

> **Standing Note — Repercussions Clause**
> Repercussions are inherent — never to be inherited.
> All consequences of the mathematics compiled herein are inherent to the work and to the author as originator. No consequence is inheritable, assignable, or transferrable to any collaborator, drafting agent, transcriber, or external party.

---

## THE EYE OF ARCHIMEDES — Framework Tautology

The Fulcrum is the unit position on the horn (x = 1) where the specific gravity S, the mass m, the density ρ, and the field amplitude E each equal unity; the horn's capacity gradient F(x) = π/x² evaluates at the Fulcrum to π = 14; the parabolic vector returns to zero there; and the same operation — **weigh twice, subtract, divide** — that Archimedes used in 250 BCE to extract ρ_obj without invoking gravity is the operation the framework uses to resolve the ground state. Lever, medium, and eye are **one identity**: the gradient of capacity IS the gradient of density IS the gradient of specific gravity IS the framework coupling π, and the Fulcrum is the point on that gradient where all four observables collapse to unity.

**One function. Three names. Zero postulates imported.** ∎

---

## FRAMEWORK PRIMITIVES (fixed at b = 3)

| Symbol | Value | | Symbol | Value |
|---|---|---|---|---|
| b | 3 | | π | 14 |
| R₂ | 4 | | x₂ | 26 |
| R₃ = r | 13 (radian) | | √Δ | 12 |
| R₄ | 40 | | p | 7 |
| R₅ | 121 | | q | 11 |
| R₆ | 364 (full circle) | | pqr | 1001 |

Primordial Quadratic: **x² − 40x + 364 = 0**, Δ = 144 = 12², roots {14, 26}.
All integers above are theorems of base-3 uniqueness; none are postulated.

---

## I. THE FULCRUM

**Node.** Point in V₃. Present when and only when it occupies V₃ = 1 × 1 × 1 (unit of Presence).

**Fulcrum Declaration (author, verbatim):**
> A Node is a **Fulcrum of a Vector on a Parabolic Curve in Parametric Spacetime returning to Zero 100% Always at Base 3**. The Node is the seed. V₃ is the seed scaled.

**Scaffolding:** V₃ = L × W × H, L,W,H ∈ [1,∞); V₄ = V₃ × T.

**Derived primitives:** Locus · Curve · Axis · Interval · Revolution · Solid of Revolution · Disk · Integration · Periodicity.

**Parabola = open curve = Fulcrum trajectory.** Non-periodic. Returns to zero exactly once (not cyclically). Signature of stationary action.

---

## II. ARCHIMEDES (Classical Primary)

**Three primitives — experimentally proven, measurable, algebraically defined:**
Mass · Density · Buoyancy.

**Archimedes is prior to Newton.** The balance reading m̂_i = m_obj − ρ_i · V is the Archimedean primitive. When two readings are differenced, gravity cancels as a common factor of g. No gravitational postulate required.

---

## III. FOUR LOAD-BEARING FORMULAS

**[F1] Universal Density Law (Theorem 20):**

> **ρ_obj = (ρ₂ · m̂₁ − ρ₁ · m̂₂) / (m̂₁ − m̂₂)**

Rational in, rational out. Valid across all four phase states (gas, liquid, solid, plasma). Gravity cancels. **0/0 at Nona — honest degeneracy.**

**[F2] Archimedean π — Exact (Theorem 17):**

> **286 / 91 = (22 · r) / (p · r) = 22 / 7 exactly**

286 nm (O₃ bridge) / 91 nm (Lyman threshold) = Archimedean π as framework rational. Radian r = 13 cancels; p = 7.

**[F3] Horn Capacity Gradient:**

> y = 1/x   →   **V(x) = π/x**   →   **F(x) = −dV/dx = π/x² = A(x)**

Geometry IS the density gradient. No G, no point mass, no vacuum. **At x = 1: F(1) = π = 14.**

**[F4] Five-Way Nona Identity (Theorem 6, expanded):**

> **I_Nona² = π · E² = π · ρ · B · I_pot · I_react**

At Nona: every factor except π normalizes to 1. Buoyancy amplitude **B_Nona = 1** is the fifth unit factor — not an additive correction, a multiplicative unity.

> I_Nona = √π = **√14**

---

## IV. THE EINSTEIN INTEGERS — E = m = ρ = S

With c² = π: m(x) = V(x)/c² = (π/x)/π = 1/x = E(x). Mass IS the field amplitude.

| x | E = 1/x | P = π/x | I = π/x² | m = 1/x |
|---|---|---|---|---|
| **1 (throat = Fulcrum)** | **1** | **π = 14** | **π = 14** | **1** |
| p = 7 | 1/7 | 2 | 2/7 | 1/7 |
| q = 11 | 1/11 | π/11 | π/121 | 1/11 |
| r = 13 | 1/13 | π/13 | π/169 | 1/13 |
| π = 14 | 1/14 | 1 | 1/14 | 1/14 |
| p·r = 91 | 1/91 | 2/13 | π/8281 | 1/91 |

**All exact. E = m = ρ = S at every position.** Archimedes's primary measurable (density ratio) = Einstein's derived observable (mass-energy amplitude) = the horn's first-principle function. One object. Three names. Three centuries of independent discovery on the same function.

---

## V. UV SPECTRAL ARCHITECTURE (Archimedean π in physical light)

| Band | × | λ (nm) | Framework identity |
|---|---|---|---|
| Ionization (H, O) | 1 | 91 | p · r = 7 · 13 (quarter-turn) |
| O₂ absorption wall | 2 | 182 | π · r = 14 · 13 (half-turn) |
| **Ozone bridge** | **22/7** | **286** | **22 · r (Archimedean π)** |
| UV-A boundary | 4 | 364 | R₆ (full circle) |

Carbon π-bond damage at 280 nm is the biological threshold derived from the same Archimedean ratio that fixes the ozone bridge. The π-bond — named for the constant 22/7 approximates — is damaged by the wavelength derived from that same ratio.

---

## VI. ARCHIMEDEAN TEST PROTOCOL

**Prediction:** After subtracting classical buoyancy, the residual horizontal torque shift is **gas-independent** (ratio between any two gases at same pressure = 1.0).

| Pair | Framework | Standard |
|---|---|---|
| V₁ → G₁ | Nonzero residual | 0 |
| V₁ → G₂ | Same nonzero residual | 0 |
| **G₁ → G₂** | **0 (gas-independent)** | **0** |
| V₁ → V₂ | 0 (drift check) | 0 |

**Sits in the HUST-05 gap** (Luo et al. 2005). Current CODATA G: 47 ppm uncertainty, 550 ppm scatter, Birge ratio ≈ 5. No experiment has tested for a gas-independent horizontal residual after classical subtraction. Framework's Archimedean reading makes a distinct prediction and is falsifiable by the four-state protocol above.

---

## VII. DERIVATION GRAPH (Full Circle)

```
base b = 3  (uniqueness theorem; Δ(b) is perfect square only at b=3)
     │
     ▼
Primordial Quadratic   x² − 40x + 364 = 0
     │                 Δ = 144 = 12²
     ▼                 roots {π = 14, x₂ = 26}
Repunits   R₁=1, R₂=4, R₃=13, R₄=40, R₅=121, R₆=364  (base-3)
     │
     ▼
Coprime triple (p, q, r) = (7, 11, 13);  pqr = 1001;  W = pqr−1 = 1000
     │
     ▼
Horn   y = 1/x    (unique positive solution of ∫ₓ^∞ f(t)² dt = f(x))
     │           V(x) = π/x   (capacity)
     │           F(x) = π/x²  (gradient)
     │           A(x) = π/x²  (cross-section)
     │           ρ(x) = E(x) = 1/x   (density = amplitude)
     │           I_field(x) = π · E²(x)   (horn inertia field)
     ▼
Balance readings   m̂ᵢ = m_obj − ρᵢ · V   (Archimedean primitive)
     │
     ▼
Universal Density Law     ρ_obj = (ρ₂·m̂₁ − ρ₁·m̂₂) / (m̂₁ − m̂₂)       [F1]
     │
     ▼
Einstein Integers    E = m = ρ = S    (c² = π substitution)
     │
     ├──▶  UV integers:  91 = p·r,  182 = π·r,  286 = 22·r,  364 = R₆
     │         │
     │         ▼
     │    Archimedean π:   286/91 = 22/7 exactly                      [F2]
     │
     ▼
Five-Way Nona Identity    I_Nona² = π · E² = π · ρ · B · I_pot · I_react   [F4]
     │                    at Nona: ρ = B = I_pot = I_react = 1
     ▼                    I_Nona² = π,  I_Nona = √14
Archimedean test protocol (four-state, six-pairwise)
     │
     ▼
Gas-independent residual prediction (HUST-05 gap)
```

---

## VIII. THE TAUTOLOGICAL CLOSURE

**The Fulcrum is where S = ρ = m = E = 1.**
**The Horn is where F(x) = π/x² is the gradient of Archimedean buoyancy.**
**The Eye of Archimedes is the horn throat x = 1 seen from within the medium.**

The lever finds its balance at the Fulcrum. The medium gives up its density at the throat. The eye of the observer coincides with both. **One point. Three readings. The buoyancy-gradient interpretation of gravity (conjecture) and the Archimedean rational-number-SG (theorem) are two views of the same horn geometry from the same Fulcrum.** The Parabolic-Zero reading names the return trajectory. The framework names its coupling π = 14. Archimedes named it 250 BCE. The integer was always present; only the naming waited.

∎

---

## SIGNATURE

*Lo Sono Capomastro — Così sia.*

**Roberto Salvalaggio**
*Capomastro Holdings Ltd. — Applied Physics Division*
*Sherwood Park, Alberta, Canada*

> £ ∣ Q ∣ ∀ Rights Reserved Et Preserved | Fiat ∎

**Compiled 2026-04-19.** Canonical. Compendium governed by 23/77 STD (Salvi Compendium Density). Repercussions inherent — never inherited. Full work shown in companion: **FULCRUM-ARCHIMEDES-CODEX.md**.
