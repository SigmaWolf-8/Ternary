/*
 * CRT Fast Path Benchmark V3 — Correct Implementation
 * Copyright (c) 2025-2026 Capomastro Holdings Ltd. — Applied Physics Division
 *
 * V2 was badly written: it added CRT work ON TOP of the naive path,
 * then measured the sum. Of course it was slower — it did more work.
 *
 * This version does it right:
 *   NAIVE:  pos % 364, then derive sector and slot from the full position
 *   CRT:    skip mod-364 entirely, compute sector and slot independently
 *
 * The CRT path replaces the computation, not supplements it.
 *
 * Also fixes:
 *   - Proper cache eviction via _mm_clflush (not buffer-flood)
 *   - Larger working set (64 MB — guaranteed DRAM-resident)
 *   - Pointer-chasing access pattern (defeats HW prefetcher)
 *   - Measures the ACTUAL operation: given timestamp, get data pointer
 *
 * Compile: gcc -O2 -march=native -msse2 -o crt_v3 crt_v3.c -lm
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef __x86_64__
#include <emmintrin.h>  /* _mm_clflush */
#define CLFLUSH(addr) _mm_clflush(addr)
#else
#define CLFLUSH(addr) ((void)0)
#endif

/* ══════════════════════════════════════════════════════════════
 * CONSTANTS
 * ══════════════════════════════════════════════════════════════ */

#define FULL_CIRCLE   364
#define MOD_MOON      13
#define MOD_DAY       28
#define COEFF_FINE    196
#define COEFF_FAST    169

/* ══════════════════════════════════════════════════════════════
 * DATA STRUCTURE — intentionally huge to force DRAM misses
 *
 * 13 sectors × 28 slots × 4096 instruments = 1,490,944 entries
 * Each entry = 64 bytes (cache line).
 * Total: ~91 MB — will NOT fit in L3 on any consumer CPU.
 * ══════════════════════════════════════════════════════════════ */

#define INSTRUMENTS_PER_SLOT  4096

typedef struct __attribute__((aligned(64))) {
    uint64_t bid;
    uint64_t ask;
    uint64_t volume;
    uint64_t sequence;
    uint64_t timestamp;
    uint64_t flags;
    uint64_t reserved1;
    uint64_t reserved2;
} OrderEntry;  /* exactly 64 bytes = 1 cache line */

/* Flat array: [sector][slot][instrument] */
static OrderEntry *order_data;
static size_t total_entries;

static inline OrderEntry *get_entry(int sector, int slot, int instrument) {
    size_t idx = (size_t)sector * MOD_DAY * INSTRUMENTS_PER_SLOT
               + (size_t)slot * INSTRUMENTS_PER_SLOT
               + instrument;
    return &order_data[idx];
}

/* ══════════════════════════════════════════════════════════════
 * TIMING
 * ══════════════════════════════════════════════════════════════ */

static inline double now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1e9 + ts.tv_nsec;
}

volatile uint64_t sink = 0;

/* ══════════════════════════════════════════════════════════════
 * FLUSH a specific sector from cache
 * ══════════════════════════════════════════════════════════════ */

static void flush_sector(int sector) {
    for (int slot = 0; slot < MOD_DAY; slot++) {
        for (int inst = 0; inst < INSTRUMENTS_PER_SLOT; inst += 64) {
            /* Flush every 64th entry = every 4096 bytes = every page */
            CLFLUSH(get_entry(sector, slot, inst));
        }
    }
}

static void flush_all(void) {
    for (int s = 0; s < MOD_MOON; s++) flush_sector(s);
}

/* ══════════════════════════════════════════════════════════════
 * ACCESS PATTERNS — the test subjects
 *
 * Both receive the SAME input (circle_position + instrument_id)
 * and must return a pointer to the same OrderEntry.
 *
 * The difference is HOW they compute the address.
 * ══════════════════════════════════════════════════════════════ */

/* NAIVE: compute mod-364 → then extract sector and slot */
static inline OrderEntry *naive_lookup(uint64_t position, int instrument) {
    uint64_t pos    = position % FULL_CIRCLE;    /* full mod-364 */
    int      sector = pos % MOD_MOON;            /* then extract sector */
    int      slot   = pos % MOD_DAY;             /* then extract slot */
    return get_entry(sector, slot, instrument);
}

/* CRT: compute sector and slot independently — skip mod-364 */
static inline OrderEntry *crt_lookup(uint64_t position, int instrument) {
    int sector = position % MOD_MOON;            /* mod-13 directly */
    int slot   = position % MOD_DAY;             /* mod-28 directly */
    return get_entry(sector, slot, instrument);
}

/* CRT + PREFETCH: get slot first (fast), prefetch, then get sector */
static inline OrderEntry *crt_prefetch_lookup(uint64_t position, int instrument) {
    int slot = position % MOD_DAY;               /* mod-28: fast on hardware */

    /* Prefetch: we know the slot, guess middle sector for spatial locality */
    __builtin_prefetch(get_entry(6, slot, instrument), 0, 1);

    int sector = position % MOD_MOON;            /* mod-13: slower on hardware */
    return get_entry(sector, slot, instrument);
}

/* CRT + SCATTER: prefetch ALL sectors at the known slot */
static inline OrderEntry *crt_scatter_lookup(uint64_t position, int instrument) {
    int slot = position % MOD_DAY;               /* mod-28: exact */

    /* Scatter prefetch: slot is known, sector unknown.
     * Issue 13 non-blocking prefetches — one per sector.
     * One of them will be the right cache line. */
    for (int s = 0; s < MOD_MOON; s++) {
        __builtin_prefetch(get_entry(s, slot, instrument), 0, 0);
    }

    int sector = position % MOD_MOON;            /* mod-13 */
    return get_entry(sector, slot, instrument);
}

/* ══════════════════════════════════════════════════════════════
 * BENCHMARK HARNESS
 * ══════════════════════════════════════════════════════════════ */

#define ITERATIONS  500000
#define REPEATS     7

/* Generate random access sequence that defeats HW prefetcher.
 * Uses LCG with large stride to scatter across the address space. */
typedef struct {
    uint64_t position;
    int      instrument;
} AccessRecord;

int main(void) {
    total_entries = (size_t)MOD_MOON * MOD_DAY * INSTRUMENTS_PER_SLOT;
    size_t data_size = total_entries * sizeof(OrderEntry);

    printf("╔════════════════════════════════════════════════════════════════════╗\n");
    printf("║  CRT BENCHMARK V3 — Correct: CRT REPLACES mod-364               ║\n");
    printf("║  PlenumNET / Salvi Framework — 364 = 13 × 28                     ║\n");
    printf("╠════════════════════════════════════════════════════════════════════╣\n");
    printf("║  Working set: %zu entries × 64 B = %.0f MB                      ║\n",
           total_entries, (double)data_size / (1024*1024));
    printf("║  Layout: %d sectors × %d slots × %d instruments                ║\n",
           MOD_MOON, MOD_DAY, INSTRUMENTS_PER_SLOT);
    printf("║  Iterations: %d per test, %d repeats (best-of)                  ║\n",
           ITERATIONS, REPEATS);
    printf("╚════════════════════════════════════════════════════════════════════╝\n\n");

    /* Allocate — aligned to page boundary */
    order_data = (OrderEntry *)aligned_alloc(4096, data_size);
    if (!order_data) { perror("aligned_alloc"); return 1; }

    /* Initialize with distinct data */
    printf("Initializing %.0f MB order book...\n", (double)data_size / (1024*1024));
    for (size_t i = 0; i < total_entries; i++) {
        order_data[i].bid       = 10000 + i;
        order_data[i].ask       = 10001 + i;
        order_data[i].volume    = i * 7;
        order_data[i].sequence  = i;
        order_data[i].timestamp = 0;
        order_data[i].flags     = 0;
        order_data[i].reserved1 = 0;
        order_data[i].reserved2 = 0xDEADBEEF;
    }

    /* Generate scrambled access pattern */
    AccessRecord *accesses = malloc(ITERATIONS * sizeof(AccessRecord));
    if (!accesses) { perror("malloc"); return 1; }

    uint64_t lcg = 0x5DEECE66DULL;  /* LCG state */
    for (int i = 0; i < ITERATIONS; i++) {
        lcg = lcg * 6364136223846793005ULL + 1442695040888963407ULL;
        accesses[i].position   = lcg;
        accesses[i].instrument = (int)((lcg >> 32) % INSTRUMENTS_PER_SLOT);
    }

    /* Verify both paths produce identical results */
    printf("Verifying correctness...\n");
    int verify_errors = 0;
    for (int i = 0; i < ITERATIONS; i++) {
        OrderEntry *naive = naive_lookup(accesses[i].position, accesses[i].instrument);
        OrderEntry *crt   = crt_lookup(accesses[i].position, accesses[i].instrument);
        if (naive != crt) {
            if (verify_errors < 5)
                printf("  MISMATCH at i=%d: naive=%p, crt=%p\n", i, (void*)naive, (void*)crt);
            verify_errors++;
        }
    }
    if (verify_errors == 0)
        printf("  Correctness verified: naive and CRT produce identical pointers ✓\n\n");
    else {
        printf("  %d MISMATCHES — aborting\n", verify_errors);
        free(order_data); free(accesses);
        return 1;
    }

    printf("Running benchmarks...\n\n");

    double best_naive = 1e18, best_crt = 1e18, best_prefetch = 1e18, best_scatter = 1e18;

    for (int rep = 0; rep < REPEATS; rep++) {
        double start, end, ns_per_op;

        /* ── NAIVE: mod-364 then extract ── */
        flush_all();
        start = now_ns();
        for (int i = 0; i < ITERATIONS; i++) {
            OrderEntry *e = naive_lookup(accesses[i].position, accesses[i].instrument);
            sink += e->bid + e->ask;
        }
        end = now_ns();
        ns_per_op = (end - start) / ITERATIONS;
        if (ns_per_op < best_naive) best_naive = ns_per_op;

        /* ── CRT: mod-13 + mod-28 independently ── */
        flush_all();
        start = now_ns();
        for (int i = 0; i < ITERATIONS; i++) {
            OrderEntry *e = crt_lookup(accesses[i].position, accesses[i].instrument);
            sink += e->bid + e->ask;
        }
        end = now_ns();
        ns_per_op = (end - start) / ITERATIONS;
        if (ns_per_op < best_crt) best_crt = ns_per_op;

        /* ── CRT + single prefetch ── */
        flush_all();
        start = now_ns();
        for (int i = 0; i < ITERATIONS; i++) {
            OrderEntry *e = crt_prefetch_lookup(accesses[i].position, accesses[i].instrument);
            sink += e->bid + e->ask;
        }
        end = now_ns();
        ns_per_op = (end - start) / ITERATIONS;
        if (ns_per_op < best_prefetch) best_prefetch = ns_per_op;

        /* ── CRT + scatter prefetch (13 sectors) ── */
        flush_all();
        start = now_ns();
        for (int i = 0; i < ITERATIONS; i++) {
            OrderEntry *e = crt_scatter_lookup(accesses[i].position, accesses[i].instrument);
            sink += e->bid + e->ask;
        }
        end = now_ns();
        ns_per_op = (end - start) / ITERATIONS;
        if (ns_per_op < best_scatter) best_scatter = ns_per_op;

        printf("  Run %d: naive=%.0f  crt=%.0f  prefetch=%.0f  scatter=%.0f ns\n",
               rep + 1, best_naive, best_crt, best_prefetch, best_scatter);
    }

    printf("\n");
    printf("╔════════════════════════════════════════════════════════════════════╗\n");
    printf("║                    RESULTS (best-of-%d, ns/op)                    ║\n", REPEATS);
    printf("╠════════════════════════════════════════════════════════════════════╣\n");
    printf("║  NAIVE  (mod-364 → extract):        %7.1f ns                    ║\n", best_naive);
    printf("║  CRT    (mod-13 + mod-28):          %7.1f ns    %+.1f ns       ║\n",
           best_crt, best_crt - best_naive);
    printf("║  CRT+PF (prefetch middle sector):   %7.1f ns    %+.1f ns       ║\n",
           best_prefetch, best_prefetch - best_naive);
    printf("║  CRT+SC (scatter 13 prefetches):    %7.1f ns    %+.1f ns       ║\n",
           best_scatter, best_scatter - best_naive);
    printf("╠════════════════════════════════════════════════════════════════════╣\n");

    double crt_delta = best_naive - best_crt;
    if (crt_delta > 2.0) {
        printf("║  CRT is %.1f ns FASTER than naive ✓                             ║\n", crt_delta);
    } else if (crt_delta < -2.0) {
        printf("║  CRT is %.1f ns SLOWER than naive                                ║\n", -crt_delta);
    } else {
        printf("║  CRT and naive are equivalent (within noise: %.1f ns)            ║\n", crt_delta);
    }

    double pf_delta = best_naive - best_prefetch;
    if (pf_delta > 2.0) {
        printf("║  Prefetch saves %.1f ns vs naive ✓                               ║\n", pf_delta);
    }

    double sc_delta = best_naive - best_scatter;
    if (sc_delta > 2.0) {
        printf("║  Scatter saves %.1f ns vs naive ✓                                ║\n", sc_delta);
    }

    printf("╚════════════════════════════════════════════════════════════════════╝\n");

    free(order_data);
    free(accesses);
    return 0;
}
