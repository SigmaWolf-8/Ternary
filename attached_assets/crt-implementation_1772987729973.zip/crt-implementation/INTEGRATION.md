# CRT Fast Path — Integration Guide

## Placement Map

| File | Repo Path | Purpose |
|------|-----------|---------|
| `crt_fast_path.rs` | `src/kernel/src/hptp/` | Kernel CRT module (add `mod crt_fast_path;` to `src/kernel/src/hptp/mod.rs`) |
| `crt-fast-path.ts` | `shared/` | Server-side CRT decomposition + PLATFORM constants |
| `xplenum_crt_unit.v` | `XPlenum/rtl/` | Hardware pipeline (4-stage progressive refinement) |
| `xplenum_crt_tb.v` | `XPlenum/rtl/tests/` or `XPlenum/tests/` | Exhaustive testbench (370 tests) |
| `xplenum_crt_formal_props.v` | `XPlenum/rtl/formal/` | SymbiYosys formal verification properties |
| `xplenum_crt_formal.sby` | `XPlenum/rtl/formal/` | SymbiYosys BMC + induction config |
| `crt_prefetch.c` | `benchmarks/` or `docs/benchmarks/` | Cache prefetch benchmark (reference) |
| `crt_bench_v2.c` | `benchmarks/` or `docs/benchmarks/` | ALU throughput benchmark (reference) |

## Wiring Steps

### 1. Kernel HPTP (`src/kernel/src/hptp/mod.rs`)

Add:
```rust
pub mod crt_fast_path;
```

This makes the module available as `hptp::crt_fast_path::decompose()`, etc.

### 2. PLATFORM Constants (`shared/constants.ts`)

Add to the PLATFORM object:
```typescript
CRT: {
  FULL_CIRCLE: 364,
  MOD_MOON: 13,
  MOD_DAY: 28,
  INV_13_MOD_28: 13,   // 13 is self-inverse mod 28
  INV_28_MOD_13: 7,
  COEFF_FINE: 196,      // 28 × 7
  COEFF_FAST: 169,      // 13 × 13
  CLOCK_SOURCES: 7,
  DAYS_PER_SOURCE: 52,  // 364 / 7 = 52 exactly
},
```

### 3. XPlenum Top-Level (`XPlenum/rtl/xplenum_top_v2.v`)

Instantiate alongside existing units (custom-1 opcode space):
```verilog
xplenum_crt_unit u_crt (
    .clk            (clk),
    .rst_n          (rst_n),
    .in_valid       (crt_in_valid),
    .rs1_data       (rs1_data),
    .in_mode        (1'b0),
    .rd_data        (crt_rd_data),
    .out_valid      (crt_out_valid),
    .coarse_valid   (crt_coarse_valid),
    .quarter_valid  (crt_quarter_valid),
    .quarter_phase  (crt_quarter),
    .mod7_result    (crt_mod7),
    .mod28_result   (crt_mod28),
    .mod13_result   (crt_mod13),
    .circle_pos     (crt_circle_pos)
);
```

### 4. HPTP Clock Source Selection

In `src/kernel/src/hptp/protocol.rs`, use `crt_fast_path::clock_source_index()`:
```rust
use super::crt_fast_path;

fn select_clock_source(circle_position: u64) -> ClockSource {
    let idx = crt_fast_path::clock_source_index(circle_position);
    ClockSource::ALL[idx as usize]
}
```

This replaces any existing clock rotation logic, connecting `coprime_clock_rotation.rs`
(which validates the coprime step) with the CRT module (which computes the mod-7 index).

## Benchmark Results (V3 — March 2026, 91 MB DRAM-resident, GCC -O2)

| Method | ns/op | vs Naive | Mechanism |
|--------|-------|----------|-----------|
| NAIVE (mod-364 → extract) | 31.5 | baseline | Serial dependency chain |
| **CRT (mod-13 + mod-28)** | **24.4** | **-7.1 ns (22.5%)** | **ILP: parallel ALU** |
| CRT + single prefetch | 27.1 | -4.4 ns | Prefetch wrong 12/13 |
| CRT scatter (×13) | 222.5 | +190.9 ns | TLB thrashing |

**The win is ILP, not prefetch.** Naive: serial chain `mod-364 → %13 → %28`.
CRT: `%13` and `%28` fire simultaneously on separate ALU ports. 7.1 ns saved.

Earlier V1-V2 benchmarks were badly written (CRT added on top instead of replacing,
3.25 MB fit in L3). V3 fixes both.

| Hardware (XPlenum) | Cycles | Info |
|--------------------|--------|------|
| quarter_phase | 0 (wire) | 2 bits |
| mod7 (clock source) | 1 | 0-6 |
| mod28 (day slot) | 2 | 0-27, exact |
| mod13 (moon sector) | 3 | 0-12 |
| circle_pos (full) | 4 | 0-363 |

370 simulation tests, 0 errors. At 200 MHz: 10 ns coarse head start.

## Key Mathematical Properties (Verified)

- 364 CRT round-trips: decompose → reconstruct = identity (exhaustive)
- CRT components are INDEPENDENT: day carries 0 information about moon
- Sector prediction from day alone: 7.7% = 1/13 (random, as expected)
- Clock distribution: 364 = 7 × 52, all 7 sources hit exactly 52 times
- 13 does NOT generate Z₃₆₄ (gcd(13,364) = 13), but CRT still works
  because decomposition doesn't require a single generator
