// ═══════════════════════════════════════════════════════════════════════
// ADD TO tlsponge385.rs — alongside existing hash_hex_tis (line ~481)
//
// Variable-length TIS-27 hash that mirrors hash() signature.
// Required by wasm_exports.rs sponge_hash_tis().
// ═══════════════════════════════════════════════════════════════════════

/// TIS-27 variable-length hash — mirrors `hash()` but uses 4-round mode.
///
/// Intended for: scan hash, identity verification, HMAC fast-path.
/// NOT for primary key derivation or authenticated encryption (use full
/// 9-round `hash()` for those).
///
/// # Arguments
/// * `input` — arbitrary byte input
/// * `output_len` — desired output length in bytes
///
/// # Returns
/// `Vec<u8>` of `output_len` bytes derived from the TIS-27 sponge.
pub fn hash_tis(input: &[u8], output_len: usize) -> Vec<u8> {
    let trits = bytes_to_trits_pub(input);
    let mut s = Sponge385Pub::new_tis();
    s.absorb(&trits);
    let out_trits = s.squeeze(output_len * 6); // 6 trits ≈ 1 byte (⌈log₃(256)⌉)
    trits_to_bytes_pub(&out_trits, output_len)
}

// NOTE: If trits_to_bytes_pub does not exist, add:
//
// pub fn trits_to_bytes_pub(trits: &[i8], byte_count: usize) -> Vec<u8> {
//     let mut bytes = Vec::with_capacity(byte_count);
//     for chunk in trits.chunks(6) {
//         let mut val: u16 = 0;
//         for (i, &t) in chunk.iter().enumerate() {
//             val += ((t + 1) as u16) * 3u16.pow(i as u32);
//         }
//         bytes.push((val % 256) as u8);
//         if bytes.len() >= byte_count { break; }
//     }
//     bytes.truncate(byte_count);
//     bytes
// }
//
// Verify this matches the existing trit-to-byte conversion used by hash().
