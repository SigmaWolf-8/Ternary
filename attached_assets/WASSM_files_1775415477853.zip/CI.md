# ternary-math CI Matrix

## Rust Version
- **MSRV**: 1.77.0 (specified in `Cargo.toml` `rust-version`)
- **Stable**: latest stable (primary CI target)
- **Nightly**: optional, for Kani/MIRI proofs only

## Cargo.lock Policy
Cargo.lock is committed to VCS. All dependencies use exact `=` pins.
Both CI and Makefile use `--locked` to enforce reproducible builds.

## Target Triples

| Target | Features | Build | Test | Expected Duration |
|--------|----------|-------|------|-------------------|
| `x86_64-unknown-linux-gnu` | default (parallel) | ✅ | ✅ | ~90s |
| `x86_64-unknown-linux-gnu` | no-default-features | ✅ | ✅ | ~60s |
| `aarch64-unknown-linux-gnu` | default | ✅ | cross | ~120s |
| `wasm32-unknown-unknown` | no-default-features | ✅ | wasm-pack test | ~45s |

## Pipeline Steps

```
1. cargo fmt --check
2. cargo clippy --all-targets -- -D warnings
3. make native                    # cargo build --locked --release
4. make test                      # cargo test --locked (default + no-default-features)
5. make wasm                      # wasm-pack build (enforces minimum version)
6. make wasm-test                 # wasm-pack test --headless --chrome
7. make audit                     # cargo audit + banned-crate check (no ^ anchor)
```

## WASM Build
- **wasm-pack**: >= 0.13.1 (enforced by `make wasm` version check)
- **Install**: `cargo install wasm-pack --version 0.13.1`
- **Output**: `pkg/ternary_math.js`, `pkg/ternary_math_bg.wasm`, `pkg/ternary_math.d.ts`

## Benchmarks
- Run on tagged releases only (not every PR)
- Targets: `inter_cube`, `ttc_benchmark`, `crypto_benchmarks`
- Duration: ~5 min total on x86_64
