# Phase 2 — Trit Struct and Golden-Ratio Arithmetic

## What Was Built

`trit.rs` — the three-vector algebraic value type that sits on top of TritInt (Phase 1). Every value in PlenumNET is a Trit: three ternary integers representing `a + bφ + cω`.

## The Type

```rust
pub struct Trit {
    pub v: [TritInt; 3],
}
```

- `v[0]` = integer part (ℤ)
- `v[1]` = golden ratio coefficient (φ)
- `v[2]` = cube root of unity coefficient (ω)

A plain integer like 364 is `v[0] = 364, v[1] = 0, v[2] = 0`. The circumradius squared R² = 14 + 5φ is `v[0] = 14, v[1] = 5, v[2] = 0`. Same type, different components active.

## What's In the File

**Constructors (all const fn):** `zero`, `one`, `scalar`, `golden`, `eisenstein`, `new`, `from_trits`, `repunit`, `from_u64`

**Arithmetic:**
- `add` / `sub` — component-wise, always valid
- `scale` — multiply all three components by a TritInt
- `mul_golden` — ℤ[φ] multiplication using φ² = φ + 1 reduction (4 TritInt multiplications, addition-only reduction, safe with unsigned arithmetic)
- `mul_scalar` — plain integer multiplication on v[0] only
- `norm_golden` — N(a + bφ) = a² + ab − b² (maps ℤ[φ] → ℤ)

**Why no mul_eisenstein:** The ω reduction rule (ω² = −1 − ω) produces negative values. TritInt is unsigned. Eisenstein multiplication is deferred to Phase 3 when Rep A (balanced ternary, {−1, 0, +1}) provides signed arithmetic.

**Framework constants defined as Trit values:**
- `R_SQUARED_T` = 14 + 5φ (circumradius squared, norm = 241 prime)
- `FULL_CIRCLE_T` = 364
- `PI_T` = 14
- `HALF_TURN_T` = 182
- `PHI_SQUARED_T` = 1 + φ

**Traits:** Display, PartialEq, Eq, Hash, Clone, Add, Sub, AddAssign, SubAssign. Mul/Div/Ord intentionally absent — multiplication requires choosing an algebra (`mul_golden` vs `mul_scalar`).

**Display format:**
- Scalar: `112₃`
- Golden: `112₃ + 12₃φ`
- Eisenstein: `21₃ + 2₃ω`

## Test Coverage

51 tests, 5 `#[should_panic]` tests. Key verifications:

- φ² = φ + 1 (the defining relation)
- Fibonacci powers: φⁿ = F(n−1) + F(n)·φ verified through φ⁵
- R² = 14 + 5φ with norm = 241 (prime, verified by trial division)
- mul_golden commutativity, associativity, identity
- Every mul_golden test asserts v[2] stays zero
- Panic on: negative norm, mul_scalar on non-scalar, mul_golden with ω-component, norm_golden with ω-component

## Files

| File | Destination | What Changed |
|------|------------|-------------|
| `trit.rs` | `ternary-math/src/trit.rs` | New file — 508 lines |
| `lib.rs` | `ternary-math/src/lib.rs` | Added `pub mod trit;` after `pub mod trit_int;` |

## Known Items

1. **Two-thirds zero:** A scalar Trit carries two zero TritInts (v[1] and v[2]). This is the mathematically correct additive identity, not wasted space — but it does mean most Trit values carry two empty components. The alternative (enum dispatch) was rejected for architectural reasons.

2. **Eisenstein deferred:** mul_eisenstein and norm_eisenstein require signed arithmetic (Phase 3). The v[2] slot is addressable and constructable now, but no ω-specific multiplication exists yet.

3. **norm_golden panics on negative norms:** Elements where b² > a² + ab produce negative norms that unsigned TritInt can't hold. All framework constants (R², edge², circumradius²) have positive norms. General-purpose norm requires signed arithmetic (Phase 3).

## Dependencies

Phase 1 — TritInt (must pass `cargo test` before this file is added)
