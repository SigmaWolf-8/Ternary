# Phase 5 — Production Hardening (Zeroize, Serde, WASM, Benchmarks)

## What Was Built

Production-grade traits, serialization, WASM exports, and benchmarks for the Trit type system.

## Files

| File | Destination | Lines | What |
|------|------------|-------|------|
| `trit_int.rs` | `ternary-math/src/trit_int.rs` | 2,351 | Phase 3 base + Zeroize, TritIntError, try_from_repr_c, Serde. 82 tests. |
| `trit.rs` | `ternary-math/src/trit.rs` | 1,438 | Phase 4 base + Zeroize, Serde (custom visitor deserializer). 74 tests. |
| `wasm_exports_phase5.rs` | Paste into `ternary-math/src/wasm_exports.rs` | 214 | 13 WASM functions for TritInt and Trit. |
| `Cargo.toml` | `ternary-math/Cargo.toml` | 64 | Added `serde` feature flag, `serde_json` dev-dep, `trit_benchmarks` bench target. |
| `benches/trit_benchmarks.rs` | `ternary-math/benches/trit_benchmarks.rs` | 90 | 8 Criterion benchmarks (native-only). |

## What Phase 5 Adds

### Zeroize
- `impl Zeroize for TritInt` — zeros packed buffer, resets trit_count to 0
- `impl Zeroize for Trit` — calls zeroize on all three TritInt components
- Phase 6 must extend for heap path (heap buffers zeroed before deallocation)

### TritIntError + try_from_repr_c
- `TritIntError` enum: `InvalidDigit(u8)` for zero/invalid digits, `TooLong` for >40 trits
- Implements `Display` and `std::error::Error` for Serde and WASM error conversion
- `try_from_repr_c` — single enforcement point for untrusted input validation
- Both Serde and WASM callers go through this function

### Serde (behind `#[cfg(feature = "serde")]`)
- **TritInt** serializes as Rep C array (MSB-first, matching `to_repr_c()` output order)
- Zero-valued TritInt → `[]` (empty array)
- Example: TritInt 14 = 112₃ → Rep C `[2,2,3]`
- **Trit** serializes as `{"v":[[repr_c_0],[repr_c_1],[repr_c_2]]}`
- Example: R² = 14+5φ → `{"v":[[2,2,3],[2,2],[]]}`
- Deserialization uses `try_from_repr_c`, returns `serde::de::Error::custom(...)` — never panics
- Custom `Deserialize` on Trit uses visitor pattern (no `derive` feature required on serde)

### WASM Exports
- 13 `#[wasm_bindgen]` wrapper functions in wasm_exports.rs
- TritInt: `trit_int_from_u64`, `trit_int_to_decimal`, `trit_int_display`, `trit_int_to_repr_c`, `trit_int_from_repr_c`
- Trit: `trit_new_scalar`, `trit_new_golden`, `trit_display`, `trit_to_f64`
- Arithmetic: `trit_add`, `trit_mul_golden`, `trit_norm_golden`
- Trit crosses WASM boundary as JSON string `{"v":[[...],[...],[...]]}`
- All error paths return `Result<_, JsValue>` — no panics at the WASM boundary
- Input length enforced before calling `try_from_repr_c`
- Uses thin wrapper functions (not direct struct export) because TritInt/Trit contain private enums and non-Copy arrays

### Criterion Benchmarks (native-only)
- TritInt::add (8-trit), TritInt::mul (8×8 trit), TritInt::div_mod (16÷8 trit)
- Trit::mul_golden, Trit::mul_eisenstein, Trit::norm_golden
- Ags::crt_project (seed generators)
- tri182::project_to_zphi (27-trit address)
- Criterion does NOT run on WASM — stated in file header

## Verification

```bash
# Standard tests
cargo test --workspace

# Serde tests (behind feature flag)
cargo test --workspace --features serde

# WASM compilation
cargo build --target wasm32-unknown-unknown --no-default-features
cargo build --target wasm32-unknown-unknown --no-default-features --features serde

# Benchmarks (native-only)
cargo bench --bench trit_benchmarks
```

## Dependencies Added to Cargo.toml

- `serde = { version = "1", optional = true }` — production dependency, behind feature flag
- `serde_json = "1"` — dev-dependency only (round-trip tests)
- `[[bench]] name = "trit_benchmarks"` — new benchmark target
