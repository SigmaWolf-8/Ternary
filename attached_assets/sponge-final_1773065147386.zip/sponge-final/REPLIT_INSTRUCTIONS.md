# Replit Instructions — Sponge Update

## Overview

Two sponge implementations, two different jobs:

| Sponge | Location | Security | Speed | Use For |
|--------|----------|----------|-------|---------|
| **Kernel sponge** | `src/kernel/src/crypto/sponge.rs` | 385-bit PQ | ~5,500 ns | Signing, key derivation, identity, TDNS registration, FIPS |
| **TIS-27** | `ternary-math/src/tis_sponge.rs` | 43 bits (non-crypto) | ~303 ns | Wire packet integrity, scan checks on authenticated channels |

## Step 1: Restore TIS-27

TIS-27 was deleted in error. Restore it:

**Create** `ternary-math/src/tis_sponge.rs` with the provided `tis_sponge.rs` file.

**Create** `shared/tis-sponge.ts` with the provided `tis-sponge.ts` file.

**Add** to `ternary-math/src/lib.rs` if not already present:
```rust
pub mod tis_sponge;
```

## Step 2: Optimize the kernel sponge

**Replace** `src/kernel/src/crypto/sponge.rs` with the provided `sponge.rs` file.

Changes from v1:
- Rounds: 27 → 9 (= 3², 3× safety margin over full diffusion)
- Substitution: 3-neighbor → 7-neighbor (±1, ±7, ±13, all coprime to 729)
- Same state (729), same rate (243), same capacity (486), same API

BREAKING CHANGE: hash outputs differ from v1. Tests that compare
specific hash bytes need expected values regenerated. Tests that check
properties (determinism, length, valid trits, avalanche) pass as-is.

No changes to `src/kernel/src/crypto/mod.rs` or `Cargo.toml`.

## Step 3: Verify gf3_algebra files

`ternary-math/src/gf3_algebra.rs` — should have NO sponge code
`shared/gf3-algebra.ts` — should have NO sponge code

If they contain PI_TABLE, sponge_theta, TIS27_ROUNDS, or similar,
replace with the clean versions from the previous delivery (94 LOC Rust,
77 LOC TypeScript).

## Step 4: Run tests

```bash
cd src/kernel && cargo test --all-features 2>&1
npx vitest run
```

## What NOT to change

- `src/kernel/src/crypto/mod.rs` — unchanged
- `src/kernel/Cargo.toml` — unchanged
- Any other crypto module — unchanged
