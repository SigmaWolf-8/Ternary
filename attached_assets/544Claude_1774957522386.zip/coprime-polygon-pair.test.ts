/**
 * Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
 * Patent(s) Pending — All Rights Reserved — Applied Physics Division
 *
 * TM-2026-025 — Coprime Polygon Pair Structural Identity Tests
 *
 * Verifies all structural identities from the memorandum:
 *   - Generator Duality (Theorem 1.1)
 *   - Euclidean Ladder (§2)
 *   - CRT Decompositions (§3)
 *   - Combined Vertices (§4)
 *   - Palindromic Interleave (§5)
 *   - Unified Equation Connections (§6)
 *   - DDT Zero-Count (§7)
 *   - Bézout Identity (§8)
 *
 * Add to: tests/ alongside existing vitest suites
 */

import { describe, it, expect } from 'vitest';

// ──────────────────────────────────────────────────────────────────────
// Constants under test — sourced from PLATFORM.COPRIME_POLYGON_PAIR
// (import from shared/constants once integrated)
// ──────────────────────────────────────────────────────────────────────

const CPP = {
  ARC: 143,
  HENDECAGON_EDGES: 11,
  TRIDECAGON_EDGES: 13,
  COMBINED_VERTICES: 23,
  INTERLEAVE: [1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1] as const,
  PLENUM_SQUARE_GAP: 286,
  BEZOUT: [6, -5] as const,
  CRT_364: [3, 3, 0] as const,
  CRT_756: [8, 3] as const,
  TERNARY_RADIANS: 11,
  EUCLIDEAN_CONTINUED_FRACTION: [2, 1, 1, 5] as const,
  Z364_GENERATOR: 11,
  Z28_GENERATOR: 13,
};

// Framework constants (from PLATFORM)
const FULL_CIRCLE = 364;
const TWO_PI = 28;
const RADIAN = 13;
const HALF_CIRCLE = 182;
const REJECTED_ROOT = 650;
const SPONGE_STATE_WIDTH = 54;
const BRANCH_NUMBER = 8;
const TRIBONACCI_8 = 24;

// ──────────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────────

function gcd(a: number, b: number): number {
  while (b !== 0) { [a, b] = [b, a % b]; }
  return a;
}

function eulerTotient(n: number): number {
  let result = n;
  let temp = n;
  for (let p = 2; p * p <= temp; p++) {
    if (temp % p === 0) {
      while (temp % p === 0) temp /= p;
      result -= result / p;
    }
  }
  if (temp > 1) result -= result / temp;
  return result;
}

function generateWalk(stride: number, modulus: number): number[] {
  return Array.from({ length: modulus }, (_, k) => (stride * k) % modulus);
}

// ──────────────────────────────────────────────────────────────────────
// Test suite
// ──────────────────────────────────────────────────────────────────────

describe('TM-2026-025: (11, 13) Coprime Polygon Pair', () => {

  // ── §1: Generator Duality ──────────────────────────────────────────

  describe('§1 Generator Duality Theorem', () => {

    it('143 = 11 × 13 (product identity)', () => {
      expect(CPP.HENDECAGON_EDGES * CPP.TRIDECAGON_EDGES).toBe(CPP.ARC);
      expect(CPP.ARC).toBe(143);
    });

    it('143 = 11 ternary radians', () => {
      expect(CPP.ARC).toBe(CPP.TERNARY_RADIANS * RADIAN);
    });

    it('11 generates Z₃₆₄ (visits all 364 positions)', () => {
      const visited = new Set(generateWalk(11, FULL_CIRCLE));
      expect(visited.size).toBe(FULL_CIRCLE);
    });

    it('13 does NOT generate Z₃₆₄ (visits only 28 positions)', () => {
      const visited = new Set(generateWalk(13, FULL_CIRCLE));
      expect(visited.size).toBe(TWO_PI); // 28, not 364
    });

    it('gcd(11, 364) = 1', () => {
      expect(gcd(11, FULL_CIRCLE)).toBe(1);
    });

    it('gcd(13, 364) = 13 (not 1)', () => {
      expect(gcd(13, FULL_CIRCLE)).toBe(13);
    });

    it('13 generates Z₂₈ (visits all 28 positions)', () => {
      const visited = new Set(generateWalk(13, TWO_PI));
      expect(visited.size).toBe(TWO_PI);
    });

    it('11 also generates Z₂₈ (both are units of Z₂₈)', () => {
      const visited = new Set(generateWalk(11, TWO_PI));
      expect(visited.size).toBe(TWO_PI);
    });

    it('stride-11 and stride-13 produce different walk orderings on Z₂₈', () => {
      const walk11 = generateWalk(11, TWO_PI);
      const walk13 = generateWalk(13, TWO_PI);
      // Same set, different order
      expect(new Set(walk11)).toEqual(new Set(walk13));
      expect(walk11).not.toEqual(walk13);
    });
  });

  // ── §2: Euclidean Ladder ───────────────────────────────────────────

  describe('§2 Euclidean Ladder', () => {

    it('gcd(364, 143) = 13 (the radian)', () => {
      expect(gcd(FULL_CIRCLE, CPP.ARC)).toBe(RADIAN);
    });

    it('all Euclidean remainders are multiples of 13', () => {
      let a = FULL_CIRCLE;
      let b = CPP.ARC;
      const remainders: number[] = [];
      while (b !== 0) {
        const r = a % b;
        if (r !== 0) remainders.push(r);
        a = b;
        b = r;
      }
      // Remainders: 78, 65, 13
      expect(remainders).toEqual([78, 65, 13]);
      for (const r of remainders) {
        expect(r % 13).toBe(0);
      }
    });

    it('Euclidean remainders in ternary radians: [6, 5, 1]', () => {
      expect(78 / 13).toBe(6);
      expect(65 / 13).toBe(5);
      expect(13 / 13).toBe(1);
    });

    it('continued fraction 364/143 = [2; 1, 1, 5]', () => {
      // Verify by building the CF from the Euclidean algorithm
      const cf: number[] = [];
      let a = FULL_CIRCLE;
      let b = CPP.ARC;
      while (b !== 0) {
        cf.push(Math.floor(a / b));
        [a, b] = [b, a % b];
      }
      expect(cf).toEqual([2, 1, 1, 5]);
      expect(CPP.EUCLIDEAN_CONTINUED_FRACTION).toEqual([2, 1, 1, 5]);
    });

    it('final convergent of [2; 1, 1, 5] is 28/11', () => {
      const cf = CPP.EUCLIDEAN_CONTINUED_FRACTION;
      // Build convergents: h[-1]=1, h[0]=cf[0]; k[-1]=0, k[0]=1
      let [hPrev, hCurr] = [1, cf[0]];
      let [kPrev, kCurr] = [0, 1];
      for (let i = 1; i < cf.length; i++) {
        [hPrev, hCurr] = [hCurr, cf[i] * hCurr + hPrev];
        [kPrev, kCurr] = [kCurr, cf[i] * kCurr + kPrev];
      }
      expect(hCurr).toBe(28); // Z₂₈ order
      expect(kCurr).toBe(11); // Z₃₆₄ generator
    });
  });

  // ── §3: CRT Decompositions ─────────────────────────────────────────

  describe('§3 CRT Decompositions', () => {

    it('Z₃₆₄ ≅ Z₄ × Z₇ × Z₁₃ image: (3, 3, 0)', () => {
      expect(CPP.ARC % 4).toBe(3);
      expect(CPP.ARC % 7).toBe(3);
      expect(CPP.ARC % 13).toBe(0);
      expect(CPP.CRT_364).toEqual([3, 3, 0]);
    });

    it('Z₇₅₆ ≅ Z₂₇ × Z₂₈ dual-circle image: (8, 3)', () => {
      expect(CPP.ARC % 27).toBe(8);
      expect(CPP.ARC % 28).toBe(3);
      expect(CPP.CRT_756).toEqual([8, 3]);
    });

    it('143 mod 27 = 8 = branch number B(Mθ)', () => {
      expect(CPP.ARC % 27).toBe(BRANCH_NUMBER);
    });

    it('143 mod 28 = 3 = Rep C maximum', () => {
      expect(CPP.ARC % 28).toBe(3);
    });

    it('364 = 4 × 7 × 13 (pairwise coprime factorization)', () => {
      expect(4 * 7 * 13).toBe(FULL_CIRCLE);
      expect(gcd(4, 7)).toBe(1);
      expect(gcd(4, 13)).toBe(1);
      expect(gcd(7, 13)).toBe(1);
    });

    it('756 = 27 × 28 and gcd(27, 28) = 1', () => {
      expect(27 * 28).toBe(756);
      expect(gcd(27, 28)).toBe(1);
    });
  });

  // ── §4: Combined Vertices ──────────────────────────────────────────

  describe('§4 The 23 Combined Vertices', () => {

    it('23 = 11 + 13 − 1 (shared vertex at 0°)', () => {
      expect(CPP.COMBINED_VERTICES).toBe(CPP.HENDECAGON_EDGES + CPP.TRIDECAGON_EDGES - 1);
    });

    it('23 = 11⁻¹ mod 28 (multiplicative inverse)', () => {
      expect((11 * 23) % 28).toBe(1);
    });

    it('23 is coprime to 54 (valid sponge stride)', () => {
      expect(gcd(23, SPONGE_STATE_WIDTH)).toBe(1);
    });

    it('23 is prime', () => {
      for (let p = 2; p * p <= 23; p++) {
        expect(23 % p).not.toBe(0);
      }
    });

    it('13 is self-inverse mod 28', () => {
      expect((13 * 13) % 28).toBe(1);
    });
  });

  // ── §5: Palindromic Interleave ─────────────────────────────────────

  describe('§5 Palindromic Interleave', () => {

    it('length = 11 (hendecagon edges)', () => {
      expect(CPP.INTERLEAVE.length).toBe(CPP.HENDECAGON_EDGES);
    });

    it('sum = 12 = 13 − 1', () => {
      const sum = CPP.INTERLEAVE.reduce((a, b) => a + b, 0);
      expect(sum).toBe(CPP.TRIDECAGON_EDGES - 1);
      expect(sum).toBe(12);
    });

    it('is palindromic', () => {
      const il = CPP.INTERLEAVE;
      for (let i = 0; i < il.length; i++) {
        expect(il[i]).toBe(il[il.length - 1 - i]);
      }
    });

    it('has exactly one central "2" at index 5', () => {
      const il = CPP.INTERLEAVE;
      const twoIndices = il.reduce<number[]>((acc, v, i) => v === 2 ? [...acc, i] : acc, []);
      expect(twoIndices).toEqual([5]); // center of length-11 array
    });

    it('all non-center entries are 1', () => {
      const il = CPP.INTERLEAVE;
      for (let i = 0; i < il.length; i++) {
        if (i !== 5) expect(il[i]).toBe(1);
      }
    });
  });

  // ── §6: Unified Equation Connections ───────────────────────────────

  describe('§6 Unified Equation Connections', () => {

    it('650 − 364 = 286 = 2 × 143', () => {
      expect(REJECTED_ROOT - FULL_CIRCLE).toBe(CPP.PLENUM_SQUARE_GAP);
      expect(CPP.PLENUM_SQUARE_GAP).toBe(2 * CPP.ARC);
      expect(CPP.PLENUM_SQUARE_GAP).toBe(286);
    });

    it('182 − 143 = 39 = 3 × 13 = 3 radians', () => {
      expect(HALF_CIRCLE - CPP.ARC).toBe(39);
      expect(39).toBe(3 * RADIAN);
    });

    it('182 + 143 = 325 = 25 × 13 = 25 radians', () => {
      expect(HALF_CIRCLE + CPP.ARC).toBe(325);
      expect(325).toBe(25 * RADIAN);
    });

    it('650 − 143 = 507 = 3 × 13² = 39 × 13', () => {
      expect(REJECTED_ROOT - CPP.ARC).toBe(507);
      expect(507).toBe(3 * 13 * 13);
    });

    it('650 = 364 + 2(143) (full circle + 2 coprime arcs)', () => {
      expect(FULL_CIRCLE + 2 * CPP.ARC).toBe(REJECTED_ROOT);
    });

    it('unified equation roots: 182 + 650 = 832, 182 × 650 = 118300', () => {
      expect(HALF_CIRCLE + REJECTED_ROOT).toBe(832);
      expect(HALF_CIRCLE * REJECTED_ROOT).toBe(118300);
    });

    it('φ(364) − φ(143) = 24 = T₈ (Tribonacci-controlled)', () => {
      expect(eulerTotient(FULL_CIRCLE)).toBe(144);
      expect(eulerTotient(CPP.ARC)).toBe(120);
      expect(eulerTotient(FULL_CIRCLE) - eulerTotient(CPP.ARC)).toBe(TRIBONACCI_8);
    });

    it('all differences reduce to products of {3, 11, 13}', () => {
      const diffs = [
        REJECTED_ROOT - FULL_CIRCLE,   // 286 = 2 × 11 × 13
        HALF_CIRCLE - CPP.ARC,          // 39  = 3 × 13
        REJECTED_ROOT - CPP.ARC,        // 507 = 3 × 13 × 13
      ];
      for (const d of diffs) {
        let n = d;
        for (const p of [2, 3, 11, 13]) {
          while (n % p === 0) n /= p;
        }
        expect(n).toBe(1); // fully factored by {2, 3, 11, 13}
      }
    });
  });

  // ── §7: DDT Zero-Count ─────────────────────────────────────────────

  describe('§7 DDT Zero-Count Alignment', () => {

    it('DDT zero count = 364 (full circle)', () => {
      // From TM-2026-008 Appendix B: 364 zero entries in 702 total
      const totalEntries = 26 * 27; // |GF(27)*| × |GF(27)|
      expect(totalEntries).toBe(702);
      // 364 zeros + 312 twos + 26 threes = 702
      expect(364 + 312 + 26).toBe(702);
    });

    it('26 = |GF(27)*| = 2 × 13', () => {
      expect(27 - 1).toBe(26);
      expect(26).toBe(2 * 13);
    });
  });

  // ── §8: Bézout Identity ────────────────────────────────────────────

  describe('§8 Bézout Identity', () => {

    it('11 × 6 + 13 × (−5) = 1', () => {
      const [a, b] = CPP.BEZOUT;
      expect(CPP.HENDECAGON_EDGES * a + CPP.TRIDECAGON_EDGES * b).toBe(1);
    });

    it('Bézout coefficient 6 = φ(7)', () => {
      expect(CPP.BEZOUT[0]).toBe(eulerTotient(7));
    });
  });

  // ── Sponge stride validity ─────────────────────────────────────────

  describe('Sponge stride coprimality', () => {

    it('all three values {11, 13, 23} are coprime to 54', () => {
      expect(gcd(11, SPONGE_STATE_WIDTH)).toBe(1);
      expect(gcd(13, SPONGE_STATE_WIDTH)).toBe(1);
      expect(gcd(23, SPONGE_STATE_WIDTH)).toBe(1);
    });

    it('the (7, 11, 13) coprime walk triple has combined stride 1001', () => {
      expect(7 * 11 * 13).toBe(1001);
    });
  });
});
