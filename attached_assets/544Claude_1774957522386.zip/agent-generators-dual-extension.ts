/**
 * Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
 * Patent(s) Pending — All Rights Reserved — Applied Physics Division
 *
 * Dual-Generator (11, 13) Extension for shared/agent-generators.ts
 * Reference: TM-2026-025 — The (11, 13) Coprime Polygon Pair
 *
 * APPEND this to the existing agent-generators.ts module.
 * Uses PLATFORM constants — all values sourced from COPRIME_POLYGON_PAIR.
 */

// ──────────────────────────────────────────────────────────────────────
// Named constants — add at module level
// ──────────────────────────────────────────────────────────────────────

/**
 * Z₃₆₄ canonical generator — stride that traverses the full 364° ternary circle.
 * gcd(11, 364) = 1, so (11k mod 364) visits all 364 positions.
 * 13 does NOT generate Z₃₆₄ (since 13 | 364, period = 28 not 364).
 * Formally verified: generator_theorem_harness.rs, §7.2 of the guide.
 *
 * TM-2026-025 §1, Theorem 1.1 (Generator Duality)
 */
export const Z364_CANONICAL_GENERATOR = 11;

/**
 * The (11, 13) dual-generator pair for Z₂₈ scheduling.
 *
 * Generator Duality: 13 generates Z₂₈ (radian cycle),
 * 11 generates Z₃₆₄ (full circle). Both are Z₂₈ generators
 * (φ(28) = 12, both 11 and 13 are in the unit group).
 *
 * Their multiplicative inverses in Z₂₈:
 *   13 is self-inverse (13 × 13 = 169 = 6 × 28 + 1)
 *   11⁻¹ = 23            (11 × 23 = 253 = 9 × 28 + 1)
 *
 * Combined product: 11 × 13 = 143 = 11 ternary radians.
 * CRT(143) in Z₂₇ × Z₂₈ = (8, 3): branch number and Rep C max.
 */
export const DUAL_GENERATOR_PAIR = {
  /** Primary: radian-cycle generator (canonical, Invariant 10) */
  primary: {
    stride: 13,
    role: 'radian_cycle' as const,
    group: 'Z28' as const,
    inverseStride: 13, // self-inverse
    generatesZ364: false,
  },
  /** Secondary: full-circle generator */
  secondary: {
    stride: 11,
    role: 'full_circle' as const,
    group: 'Z364' as const,
    inverseStride: 23, // 11⁻¹ mod 28
    generatesZ364: true,
  },
  /** Product of the pair */
  arc: 143,
  /** Combined vertices from interleaving hendecagon + tridecagon */
  combinedVertices: 23,
  /** Palindromic interleave pattern: 11 entries summing to 12 */
  interleave: [1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1] as const,
  /** Bézout coefficients: 11 × 6 + 13 × (−5) = 1 */
  bezout: [6, -5] as const,
} as const;

/**
 * Generate the stride-11 coprime walk on Z₂₈.
 * Returns all 28 positions in the order visited by (11k mod 28).
 * This is the secondary/redundant walk — use alongside the
 * canonical stride-13 walk for dual-coverage heartbeat monitoring.
 */
export function getStride11Walk(): number[] {
  const walk: number[] = [];
  for (let k = 0; k < 28; k++) {
    walk.push((11 * k) % 28);
  }
  return walk;
}

/**
 * Generate a dual-generator schedule pairing stride-13 and stride-11 walks
 * with the interleave pattern as handoff rhythm.
 *
 * The interleave [1,1,1,1,1,2,1,1,1,1,1] defines how tridecagon (stride-13)
 * vertices distribute between hendecagon (stride-11) gaps when the two
 * regular polygons are inscribed in the same circle. As a scheduling kernel:
 *   - "1" entries: one step of the stride-13 walk per stride-11 step
 *   - "2" entry (center): two steps of the stride-13 walk per stride-11 step
 *
 * @returns Object containing both walks and the interleave-driven combined schedule
 */
export function getDualGeneratorSchedule(): {
  primaryWalk: number[];
  secondaryWalk: number[];
  interleave: readonly number[];
  combinedSchedule: Array<{ position: number; source: 'primary' | 'secondary' }>;
} {
  const primaryWalk: number[] = [];
  const secondaryWalk: number[] = [];

  for (let k = 0; k < 28; k++) {
    primaryWalk.push((13 * k) % 28);
    secondaryWalk.push((11 * k) % 28);
  }

  // Build combined schedule using interleave as handoff rhythm
  // The interleave pattern tells how many primary (stride-13) steps
  // occur between each secondary (stride-11) step
  const combinedSchedule: Array<{ position: number; source: 'primary' | 'secondary' }> = [];
  let primaryIdx = 0;
  let secondaryIdx = 0;
  const interleave = DUAL_GENERATOR_PAIR.interleave;

  for (let i = 0; i < interleave.length && secondaryIdx < 28; i++) {
    // Each interleave entry: emit that many primary steps, then one secondary step
    for (let j = 0; j < interleave[i] && primaryIdx < 28; j++) {
      combinedSchedule.push({ position: primaryWalk[primaryIdx], source: 'primary' });
      primaryIdx++;
    }
    if (secondaryIdx < 28) {
      combinedSchedule.push({ position: secondaryWalk[secondaryIdx], source: 'secondary' });
      secondaryIdx++;
    }
  }

  // Drain remaining primary steps
  while (primaryIdx < 28) {
    combinedSchedule.push({ position: primaryWalk[primaryIdx], source: 'primary' });
    primaryIdx++;
  }
  // Drain remaining secondary steps
  while (secondaryIdx < 28) {
    combinedSchedule.push({ position: secondaryWalk[secondaryIdx], source: 'secondary' });
    secondaryIdx++;
  }

  return {
    primaryWalk,
    secondaryWalk,
    interleave,
    combinedSchedule,
  };
}

// ──────────────────────────────────────────────────────────────────────
// Structural identity assertions — call from test suite
// ──────────────────────────────────────────────────────────────────────

export function verifyDualGeneratorInvariants(): void {
  const DG = DUAL_GENERATOR_PAIR;

  // Generator Duality: product = arc
  console.assert(DG.primary.stride * DG.secondary.stride === DG.arc,
    '13 × 11 = 143');

  // Both generate Z₂₈ (visit all 28 positions)
  const visited13 = new Set<number>();
  const visited11 = new Set<number>();
  for (let k = 0; k < 28; k++) {
    visited13.add((13 * k) % 28);
    visited11.add((11 * k) % 28);
  }
  console.assert(visited13.size === 28, 'stride-13 visits all 28 positions');
  console.assert(visited11.size === 28, 'stride-11 visits all 28 positions');

  // The walks produce DIFFERENT orderings
  const walk13 = Array.from({ length: 28 }, (_, k) => (13 * k) % 28);
  const walk11 = Array.from({ length: 28 }, (_, k) => (11 * k) % 28);
  const sameOrder = walk13.every((v, i) => v === walk11[i]);
  console.assert(!sameOrder, 'stride-11 and stride-13 produce different orderings');

  // Inverse verification
  console.assert((11 * 23) % 28 === 1, '11⁻¹ mod 28 = 23');
  console.assert((13 * 13) % 28 === 1, '13 is self-inverse mod 28');

  // Combined vertices
  console.assert(DG.combinedVertices === 11 + 13 - 1, '23 = 11 + 13 − 1');
  console.assert(DG.combinedVertices === DG.secondary.inverseStride,
    '23 = 11⁻¹ mod 28');

  // Interleave palindrome
  const il = DG.interleave;
  console.assert(il.length === 11, 'Interleave length = 11');
  for (let i = 0; i < il.length; i++) {
    console.assert(il[i] === il[il.length - 1 - i],
      `Palindromic at index ${i}`);
  }
  const sum = il.reduce((a: number, b: number) => a + b, 0);
  console.assert(sum === 12, 'Interleave sum = 12 = 13 − 1');

  // Bézout identity
  console.assert(11 * DG.bezout[0] + 13 * DG.bezout[1] === 1,
    '11 × 6 + 13 × (−5) = 1');

  // 11 generates Z₃₆₄ but 13 does NOT
  const visited11_364 = new Set<number>();
  for (let k = 0; k < 364; k++) {
    visited11_364.add((11 * k) % 364);
  }
  console.assert(visited11_364.size === 364, '11 generates Z₃₆₄');

  const visited13_364 = new Set<number>();
  for (let k = 0; k < 364; k++) {
    visited13_364.add((13 * k) % 364);
  }
  console.assert(visited13_364.size === 28,
    '13 does NOT generate Z₃₆₄ (period = 364/13 = 28)');

  console.log('✓ All dual-generator invariants verified.');
}
