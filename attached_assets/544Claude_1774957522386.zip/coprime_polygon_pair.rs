// Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
// Patent(s) Pending — All Rights Reserved — Applied Physics Division
//
// (11, 13) Coprime Polygon Pair — Addition to coprime_walk.rs
// Reference: TM-2026-025 — The (11, 13) Coprime Polygon Pair
//
// APPEND this block to the existing coprime_walk.rs module.
// The (7, 11, 13) triple and combined stride 1001 remain unchanged.
// This adds the (11, 13) sub-pair as a named structural element.

// ──────────────────────────────────────────────────────────────────────
// Named constants — (11, 13) coprime polygon pair
// ──────────────────────────────────────────────────────────────────────

/// Combined arc of the (11, 13) coprime polygon pair: 11 × 13 = 143° = 11 ternary radians.
///
/// CRT decompositions:
///   143 mod 27 = 8  (branch number B(Mθ) — TM-2026-008 Theorem 3.4)
///   143 mod 28 = 3  (Rep C maximum)
///   143 in Z₃₆₄ ≅ Z₄ × Z₇ × Z₁₃ → (3, 3, 0)
///
/// Unified equation bridge: 650 − 364 = 286 = 2 × COPRIME_ARC.
pub const COPRIME_ARC: u32 = 143;

/// Combined distinct vertices from interleaving hendecagon (11) and tridecagon (13).
/// 11 + 13 − 1 (shared vertex at 0°) = 23.
///
/// Triple structural duty:
///   1. 11⁻¹ mod 28 = 23  (multiplicative inverse in Z₂₈)
///   2. x²³ over GF(27) achieves DP_max = 1/9  (optimal chi exponent, TM-2026-008 §3.2)
///   3. gcd(23, 54) = 1  (valid TIS-27 sponge stride)
pub const COMBINED_VERTICES: u32 = 23;

/// Palindromic interleave pattern from inscribing both polygons in the 364° circle.
/// 11 entries summing to 12 = 13 − 1. Symmetric around central position (index 5).
/// The single "2" at center marks the angular region where tridecagon and hendecagon
/// vertices are closest to coinciding.
///
/// As a scheduling kernel: "1" entries = uniform single-step intervals,
/// "2" entry = deliberate syncopation (handoff point between generators).
pub const INTERLEAVE_PATTERN: [u8; 11] = [1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1];

/// Hendecagon edge count — the full-circle generator (stride for Z₃₆₄).
/// gcd(11, 364) = 1, so (11k mod 364) visits all 364 positions.
/// Formally verified in generator_theorem_harness.rs.
pub const HENDECAGON_EDGES: u32 = 11;

/// Tridecagon edge count — the radian-cycle generator (stride for Z₂₈).
/// gcd(13, 28) = 1 (Invariant 10). Also the canonical TIS-27 sponge stride.
pub const TRIDECAGON_EDGES: u32 = 13;

/// Plenum Square gap: 650 − 364 = 286 = 2 × 143.
/// Names the arithmetic distance between the rejected root (650)
/// and the full circle (364) in the unified arc equation.
pub const PLENUM_SQUARE_GAP: u32 = 286;

/// Bézout coefficients for the (11, 13) coprime pair.
/// 11 × 6 + 13 × (−5) = 1.
/// Note: 6 = φ(7), the Euler totient of the third prime factor of 364.
pub const BEZOUT_COEFFICIENTS: (i32, i32) = (6, -5);

/// Euler totient gap: φ(364) − φ(143) = 144 − 120 = 24 = T₈.
pub const TOTIENT_GAP: u32 = 24;

/// Continued fraction representation of 364/143 = [2; 1, 1, 5].
/// Final convergent: 28/11 = Z₂₈ order / Z₃₆₄ generator.
pub const CONTINUED_FRACTION: [u32; 4] = [2, 1, 1, 5];

// ──────────────────────────────────────────────────────────────────────
// Helper: GCD (Euclidean algorithm)
// ──────────────────────────────────────────────────────────────────────

/// Compute gcd(a, b) via the Euclidean algorithm.
const fn const_gcd(mut a: u32, mut b: u32) -> u32 {
    while b != 0 {
        let t = b;
        b = a % b;
        a = t;
    }
    a
}

/// Euler totient function for small values.
fn euler_totient(mut n: u32) -> u32 {
    let mut result = n;
    let mut p = 2u32;
    let mut temp = n;
    while p * p <= temp {
        if temp % p == 0 {
            while temp % p == 0 {
                temp /= p;
            }
            result -= result / p;
        }
        p += 1;
    }
    if temp > 1 {
        result -= result / temp;
    }
    result
}

// ──────────────────────────────────────────────────────────────────────
// Compile-time assertions (const evaluation)
// ──────────────────────────────────────────────────────────────────────

// Product identity
const _: () = assert!(HENDECAGON_EDGES * TRIDECAGON_EDGES == COPRIME_ARC,
    "11 × 13 = 143");

// Combined vertices
const _: () = assert!(HENDECAGON_EDGES + TRIDECAGON_EDGES - 1 == COMBINED_VERTICES,
    "11 + 13 − 1 = 23");

// Coprimality: 11 generates Z₃₆₄
const _: () = assert!(const_gcd(HENDECAGON_EDGES, 364) == 1,
    "gcd(11, 364) = 1");

// 13 does NOT generate Z₃₆₄
const _: () = assert!(const_gcd(TRIDECAGON_EDGES, 364) == 13,
    "gcd(13, 364) = 13");

// 13 generates Z₂₈
const _: () = assert!(const_gcd(TRIDECAGON_EDGES, 28) == 1,
    "gcd(13, 28) = 1");

// Both are valid sponge strides (coprime to 54)
const _: () = assert!(const_gcd(HENDECAGON_EDGES, 54) == 1,
    "gcd(11, 54) = 1");
const _: () = assert!(const_gcd(TRIDECAGON_EDGES, 54) == 1,
    "gcd(13, 54) = 1");
const _: () = assert!(const_gcd(COMBINED_VERTICES, 54) == 1,
    "gcd(23, 54) = 1");

// Plenum Square gap
const _: () = assert!(PLENUM_SQUARE_GAP == 2 * COPRIME_ARC,
    "286 = 2 × 143");
const _: () = assert!(650 - 364 == PLENUM_SQUARE_GAP,
    "650 − 364 = 286");

// CRT images
const _: () = assert!(COPRIME_ARC % 27 == 8,
    "143 mod 27 = 8 (branch number)");
const _: () = assert!(COPRIME_ARC % 28 == 3,
    "143 mod 28 = 3 (Rep C max)");
const _: () = assert!(COPRIME_ARC % 4 == 3,
    "143 mod 4 = 3");
const _: () = assert!(COPRIME_ARC % 7 == 3,
    "143 mod 7 = 3");
const _: () = assert!(COPRIME_ARC % 13 == 0,
    "143 mod 13 = 0");

// Bézout identity
const _: () = assert!(
    (HENDECAGON_EDGES as i32) * BEZOUT_COEFFICIENTS.0
  + (TRIDECAGON_EDGES as i32) * BEZOUT_COEFFICIENTS.1 == 1,
    "11 × 6 + 13 × (−5) = 1");

// Half-circle − coprime arc = 3 radians
const _: () = assert!(182 - COPRIME_ARC == 3 * 13,
    "182 − 143 = 39 = 3 radians");

// Interleave length
const _: () = assert!(INTERLEAVE_PATTERN.len() == HENDECAGON_EDGES as usize,
    "Interleave length = 11");

// ──────────────────────────────────────────────────────────────────────
// Runtime tests
// ──────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod coprime_polygon_pair_tests {
    use super::*;

    #[test]
    fn test_product_identity() {
        assert_eq!(HENDECAGON_EDGES * TRIDECAGON_EDGES, COPRIME_ARC);
        assert_eq!(COPRIME_ARC, 143);
    }

    #[test]
    fn test_combined_vertices() {
        assert_eq!(COMBINED_VERTICES, HENDECAGON_EDGES + TRIDECAGON_EDGES - 1);
        assert_eq!(COMBINED_VERTICES, 23);
    }

    #[test]
    fn test_generator_duality_11_generates_z364() {
        // 11 generates Z₃₆₄: the walk (11k mod 364) visits all 364 positions
        let mut visited = std::collections::HashSet::new();
        for k in 0..364u32 {
            visited.insert((11 * k) % 364);
        }
        assert_eq!(visited.len(), 364,
            "stride-11 must visit all 364 positions in Z₃₆₄");
    }

    #[test]
    fn test_generator_duality_13_does_not_generate_z364() {
        // 13 does NOT generate Z₃₆₄: period is 364/gcd(13,364) = 364/13 = 28
        let mut visited = std::collections::HashSet::new();
        for k in 0..364u32 {
            visited.insert((13 * k) % 364);
        }
        assert_eq!(visited.len(), 28,
            "stride-13 visits only 28 of 364 positions (period = 28)");
    }

    #[test]
    fn test_both_generate_z28() {
        // Both 11 and 13 generate Z₂₈
        for stride in [11u32, 13] {
            let mut visited = std::collections::HashSet::new();
            for k in 0..28u32 {
                visited.insert((stride * k) % 28);
            }
            assert_eq!(visited.len(), 28,
                "stride-{} must visit all 28 positions in Z₂₈", stride);
        }
    }

    #[test]
    fn test_different_walk_orders() {
        // stride-11 and stride-13 produce different orderings of Z₂₈
        let walk11: Vec<u32> = (0..28).map(|k| (11 * k) % 28).collect();
        let walk13: Vec<u32> = (0..28).map(|k| (13 * k) % 28).collect();
        assert_ne!(walk11, walk13, "The two walks must have different orderings");
    }

    #[test]
    fn test_multiplicative_inverse_23() {
        // 11⁻¹ mod 28 = 23
        assert_eq!((11u32 * 23) % 28, 1, "11 × 23 ≡ 1 (mod 28)");
        assert_eq!(COMBINED_VERTICES, 23);
    }

    #[test]
    fn test_coprimality_conditions() {
        assert_eq!(const_gcd(11, 364), 1, "gcd(11, 364) = 1");
        assert_eq!(const_gcd(13, 364), 13, "gcd(13, 364) = 13");
        assert_eq!(const_gcd(13, 28), 1, "gcd(13, 28) = 1");
        assert_eq!(const_gcd(11, 54), 1, "gcd(11, 54) = 1");
        assert_eq!(const_gcd(13, 54), 1, "gcd(13, 54) = 1");
        assert_eq!(const_gcd(23, 54), 1, "gcd(23, 54) = 1");
        assert_eq!(const_gcd(11, 13), 1, "gcd(11, 13) = 1");
    }

    #[test]
    fn test_interleave_palindromic() {
        let il = INTERLEAVE_PATTERN;
        for i in 0..il.len() {
            assert_eq!(il[i], il[il.len() - 1 - i],
                "Interleave must be palindromic at position {}", i);
        }
    }

    #[test]
    fn test_interleave_sum() {
        let sum: u32 = INTERLEAVE_PATTERN.iter().map(|&x| x as u32).sum();
        assert_eq!(sum, 12, "Interleave sum = 12 = 13 − 1");
        assert_eq!(sum, TRIDECAGON_EDGES - 1);
    }

    #[test]
    fn test_interleave_length() {
        assert_eq!(INTERLEAVE_PATTERN.len(), HENDECAGON_EDGES as usize,
            "Interleave length = hendecagon edges = 11");
    }

    #[test]
    fn test_plenum_square_gap() {
        assert_eq!(PLENUM_SQUARE_GAP, 2 * COPRIME_ARC, "286 = 2 × 143");
        assert_eq!(650u32 - 364, PLENUM_SQUARE_GAP, "650 − 364 = 286");
    }

    #[test]
    fn test_bezout_identity() {
        let (a, b) = BEZOUT_COEFFICIENTS;
        let result = (HENDECAGON_EDGES as i32) * a + (TRIDECAGON_EDGES as i32) * b;
        assert_eq!(result, 1, "11 × 6 + 13 × (−5) = 1");
    }

    #[test]
    fn test_crt_z364() {
        // Z₃₆₄ ≅ Z₄ × Z₇ × Z₁₃
        assert_eq!(COPRIME_ARC % 4, 3, "143 mod 4 = 3");
        assert_eq!(COPRIME_ARC % 7, 3, "143 mod 7 = 3");
        assert_eq!(COPRIME_ARC % 13, 0, "143 mod 13 = 0");
    }

    #[test]
    fn test_crt_z756_dual_circle() {
        // Z₇₅₆ ≅ Z₂₇ × Z₂₈
        assert_eq!(COPRIME_ARC % 27, 8, "143 mod 27 = 8 (branch number B(Mθ))");
        assert_eq!(COPRIME_ARC % 28, 3, "143 mod 28 = 3 (Rep C maximum)");
    }

    #[test]
    fn test_half_circle_relationship() {
        // 182 − 143 = 39 = 3 × 13 = 3 radians
        assert_eq!(182u32 - COPRIME_ARC, 39);
        assert_eq!(39u32, 3 * 13);
    }

    #[test]
    fn test_sum_with_half_circle() {
        // 182 + 143 = 325 = 25 × 13 = 25 radians
        assert_eq!(182u32 + COPRIME_ARC, 325);
        assert_eq!(325u32, 25 * 13);
    }

    #[test]
    fn test_euler_totient_gap() {
        // φ(364) − φ(143) = 144 − 120 = 24 = T₈
        assert_eq!(euler_totient(364), 144);
        assert_eq!(euler_totient(143), 120);
        assert_eq!(TOTIENT_GAP, 24);
        assert_eq!(euler_totient(364) - euler_totient(143), TOTIENT_GAP);
    }

    #[test]
    fn test_euclidean_ladder_remainders() {
        // All remainders are multiples of 13
        let mut a = 364u32;
        let mut b = 143u32;
        while b != 0 {
            let r = a % b;
            if r != 0 {
                assert_eq!(r % 13, 0,
                    "Euclidean remainder {} must be a multiple of 13", r);
            }
            a = b;
            b = r;
        }
        // Final GCD is 13
        assert_eq!(a, 13, "gcd(364, 143) = 13 (the radian)");
    }

    #[test]
    fn test_continued_fraction_convergents() {
        // 364/143 = [2; 1, 1, 5]
        // Convergents: 2/1, 3/1, 5/2, 28/11
        let cf = CONTINUED_FRACTION;
        assert_eq!(cf, [2, 1, 1, 5]);

        // Verify final convergent = 28/11
        // Build convergents from CF: h[-1]=1, h[0]=cf[0], h[k]=cf[k]*h[k-1]+h[k-2]
        let (mut h_prev, mut h_curr) = (1u32, cf[0]);
        let (mut k_prev, mut k_curr) = (0u32, 1u32);
        for i in 1..cf.len() {
            let h_next = cf[i] * h_curr + h_prev;
            let k_next = cf[i] * k_curr + k_prev;
            h_prev = h_curr;
            h_curr = h_next;
            k_prev = k_curr;
            k_curr = k_next;
        }
        assert_eq!(h_curr, 28, "Final convergent numerator = 28 (Z₂₈ order)");
        assert_eq!(k_curr, 11, "Final convergent denominator = 11 (Z₃₆₄ generator)");
    }

    #[test]
    fn test_thirteen_self_inverse_mod_28() {
        // 13 × 13 = 169 = 6 × 28 + 1
        assert_eq!((13u32 * 13) % 28, 1, "13 is self-inverse mod 28");
    }

    #[test]
    fn test_rejected_root_decomposition() {
        // 650 = 364 + 2 × 143 (full circle + 2 coprime arcs)
        assert_eq!(364u32 + 2 * COPRIME_ARC, 650);
        // 650 − 143 = 507 = 3 × 13² = 39 × 13
        assert_eq!(650u32 - COPRIME_ARC, 507);
        assert_eq!(507u32, 3 * 13 * 13);
    }
}
