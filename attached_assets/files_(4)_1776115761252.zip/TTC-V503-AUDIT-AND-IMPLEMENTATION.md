# TTC Compression Engine V5.0.3 — Audit & Implementation Guide

**TM-2026-035.AUD**  
**Classification:** Internal — Applied Physics Division  
**Date:** April 13, 2026  
**Total code reviewed:** ~34,000 lines across Rust engine, N-API bridge, and server wiring

---

## 1. Executive Summary

The Rust TTC v5.0.3 engine is loaded and working. The native addon (`sponge-native.node`) is compiled, deployed, and confirmed functional with all 20 N-API exports including `ttcCompress` and `ttcDecompress`.

Four production problems found and fixed:

1. **Route wiring + dead TS stubs** — three call sites in `routes.ts` import compression functions from a zlib TypeScript stub instead of the Rust engine. The TS compression files (`ternary.ts`, `compression-layer.ts`) must be decommissioned — routes call the Rust addon directly.
2. **Hex encoding throughout the N-API bridge** — `trits_to_hex` packs trits to bytes then runs `hex::encode`. MAC tags, sponge hashes, and key derivation all go through base-16 ASCII. The `hex` crate has no business in a ternary-native codebase. Replaced with Rep C digit strings `{1,2,3}`.
3. **CRC32 polynomial mismatch** — hardware path uses Castagnoli, software path uses ISO 3309. Different hashes on different hardware.
4. **Two additional Rust bugs** — `sponge_hash_v1` calling v2 permutation, u32 size truncation in N-API bridge.

---

## 2. Deliverables

| File | Location | Description |
|------|----------|-------------|
| `lib.rs` | `ternary-math/napi/lib.rs` | Complete rewrite of the N-API bridge. Hex purged — all trit output is Rep C digit strings. `trits_to_hex` replaced with `trits_to_repr_c`. MAC comparison via constant-time Rep C string comparison. `sponge_hash_v1` restored to v1 permutation. Size fields widened to f64. |
| `Cargo.toml` | `ternary-math/napi/Cargo.toml` | Package renamed to `sponge-native` (build output matches probe path). `hex` crate dependency **removed**. |
| `sponge_additions.rs` | Add to sponge module | Two functions: `hash_trits()` and `hash_trits_v1()`. Return raw `Vec<i8>` balanced trits instead of hex strings. Required by the rewritten `lib.rs`. |
| `ttc_crc32c_fix.rs` | Patch `ternary-math/src/ttc.rs` | CRC32 software table polynomial: `0xEDB88320` → `0x82F63B78` (Castagnoli). Matches hardware `_mm_crc32_u8`. Test vector updated. |
| `tritint-rans-integration-scope.txt` | Design reference | Architecture scope for replacing `TritStreamWriter` byte vectors with TritInt in the rANS pipeline. v5.1.0 scope. |

---

## 3. Hex Purge

### 3.1 The Problem

`trits_to_hex` in the old `napi/lib.rs`:

```rust
fn trits_to_hex(trits:&[i8])->String{
    // packs balanced trits to bytes, then:
    hex::encode(&bytes)   // base-16 ASCII of packed bytes
}
```

Sponge squeezes trits. MAC is trits. Hash output is trits. Then two binary conversions: trits → packed bytes → base-16 hex. Six call sites: `sponge_hash`, `sponge_hash_v1`, `phase_encrypt_sequential` MAC, `phase_encrypt_v3` MAC, `phase_decrypt_sequential` MAC verify, `phase_decrypt_v3` MAC verify.

### 3.2 The Fix

`trits_to_repr_c` — direct balanced trit to Rep C character, zero intermediary:

```rust
fn trits_to_repr_c(trits: &[i8]) -> String {
    let mut s = String::with_capacity(trits.len());
    for &t in trits {
        s.push(match t { -1 => '1', 0 => '2', 1 => '3', _ => '2' });
    }
    s
}
```

Balanced `{-1, 0, +1}` → Rep C `{1, 2, 3}`. One character per trit. No byte packing. No hex. The MAC tag for 243 trits is a 243-character string of digits 1–3.

Inverse `repr_c_to_trits` provided: `'1'→-1, '2'→0, '3'→+1`.

MAC comparison via `ct_trit_str_eq` — constant-time XOR on Rep C bytes directly.

`hex` crate removed from `Cargo.toml`.

### 3.3 Backward Compatibility

Existing phase-encrypted records store hex MAC tags. New MACs are Rep C. Options:

- **Option A — Detection:** MAC matches `[0-9a-f]+` → legacy hex. MAC matches `[123]+` → Rep C.
- **Option B — Migration:** One-time re-encrypt stored data.
- **Option C — Version gate:** `EncryptedPhaseData.version` 4 = Rep C, 3 = hex legacy.

---

## 4. All Rust Fixes

### 4.1 CRC32-C Polynomial (`ttc.rs`)

`_mm_crc32_u8` (hardware) uses Castagnoli polynomial. Software fallback uses ISO 3309. Different hashes on different hardware.

**`ttc.rs` line 122:**
```rust
// OLD:  c = 0xEDB8_8320 ^ (c >> 1);
// NEW:  c = 0x82F6_3B78 ^ (c >> 1);
```

**Test vector, line 2396:**
```rust
// OLD:  assert_eq!(crc32_software(b"123456789"), 0xCBF4_3926);
// NEW:  assert_eq!(crc32_software(b"123456789"), 0xE306_8220);
```

### 4.2 sponge_hash_v1 Regression (`napi/lib.rs`)

Old: both `sponge_hash` and `sponge_hash_v1` called `hash_hex` (v2 permutation). Legacy v2 phase-encrypted data derived keys with v1.

New: `sponge_hash_v1` calls `hash_trits_v1` → `Sponge385Pub::new_v1()` (no chi).

Requires `hash_trits` and `hash_trits_v1` added to sponge module (`sponge_additions.rs`).

### 4.3 u32 Size Truncation (`napi/lib.rs`)

Old: `original_size: u32`, `compressed_size: u32` — truncates >4GB.

New: both `f64`. napi-rs maps f64 to JS number, lossless to 2^53.

### 4.4 Hex Purge (`napi/lib.rs` + `Cargo.toml`)

See §3. `trits_to_hex` → `trits_to_repr_c`. All six call sites updated. `hex` crate removed.

---

## 5. TypeScript Compression Files — DECOMMISSION

The following TypeScript files contain byte-level compression code that is **not ternary**, never was ternary, and must be removed from the codebase:

### 5.1 Files to Delete

| File | Why it must go |
|------|---------------|
| `server/ternary.ts` | Contains `ternaryEncode`, `ternaryDecode`, `runLengthCompress`, `runLengthDecompress`, `compressData`, `decompressData`. This is a zlib stub wrapped in a fake ternary expansion pass. It expands data ~50%, OOMs at 5MB, silently drops bytes, and has zero ternary math. **Delete entirely.** Move `generateSensorData`, `generateUserEvents`, `generateLogEntries` (demo data generators, unrelated to compression) to a separate file such as `server/demo-generators.ts` if still needed. |
| `server/compression-layer.ts` | Contains `ttcTsFallbackCompress`, `ttcTsFallbackDecompress`, `simpleChecksum`, and the `loadTtcAddon` function that silently falls back to the zlib stub when the Rust addon is available but the routes bypass it. The entire fallback architecture is wrong — if the Rust engine doesn't load, the server should refuse to start, not silently degrade to a broken byte-level stub. **Delete entirely.** The N-API addon (`sponge-native.node`) is the compression layer. Route handlers call `ttcCompress`/`ttcDecompress` on the addon directly. |

### 5.2 What Replaces Them

Nothing. The Rust engine (`ttc.rs` → `sponge-native.node`) is the compression engine. It is already compiled, deployed, and loaded. The N-API bridge (`napi/lib.rs`) exports `ttcCompress` and `ttcDecompress`. Server route handlers import the addon and call those functions directly. There is no TypeScript compression layer, no fallback, no stub.

### 5.3 Route Import After Decommission

`server/routes.ts` lines 47–53 currently import `compressData`/`decompressData` from `./ternary`. After deleting those files, the routes must import compression directly from the loaded N-API addon. The three call sites (lines 311, 507, 1174) must call `ttcCompress`/`ttcDecompress` on the native addon instance rather than through any TypeScript wrapper.

---

## 6. Implementation Steps

### Step 1 — Build Rust

1. Add `hash_trits()` and `hash_trits_v1()` to sponge module per `sponge_additions.rs`
2. Export from sponge crate public API
3. Replace `ternary-math/napi/lib.rs` with delivered `lib.rs`
4. Replace `ternary-math/napi/Cargo.toml` with delivered `Cargo.toml`
5. Apply CRC32-C fix in `ttc.rs` per `ttc_crc32c_fix.rs`
6. Build:
```bash
cd /home/runner/workspace
RUSTFLAGS="-C target-cpu=native" cargo build --release
cp target/release/libsponge_native.so server/crypto/sponge-native.node
```

### Step 2 — Decommission TypeScript Compression

1. Delete `server/ternary.ts`
2. Delete `server/compression-layer.ts`
3. Move demo generators (`generateSensorData`, `generateUserEvents`, `generateLogEntries`) to `server/demo-generators.ts` if needed by routes
4. Update `server/routes.ts` to load the N-API addon directly and call `ttcCompress`/`ttcDecompress` at the three call sites (lines 311, 507, 1174)
5. Remove all imports of `compressData`/`decompressData` from `./ternary` or `./compression-layer`

### Step 3 — Test

- Demo compress: `POST /api/demo/run` — should return positive `savingsPercent`
- Demo decompress: `GET /api/demo/data/:sessionId` — valid JSON data
- File compress >5MB — completes without crash
- Phase encrypt round-trip — MAC tags are now Rep C digit strings `[123]+`
- Verify `server/ternary.ts` and `server/compression-layer.ts` no longer exist

### Step 4 — Legacy Data (policy decision)

Choose hex→Rep C migration strategy per §3.3.

---

## 7. TritInt rANS Integration (v5.1.0)

See `tritint-rans-integration-scope.txt`. Three phases:

**Phase 1:** `TritStreamWriter`/`Reader` → TritInt accumulator. rANS state as TritInt (11 trits, inline). Binary varint → TritInt varint.

**Phase 2:** Header fields → TritInt. CRC32 → `plenum_checksum` ternary hash.

**Phase 3:** Rice side channel → ternary Rice coding. Eliminates last binary path.

---

## 8. Bug Summary

| ID | Severity | Fix | Deliverable |
|----|----------|-----|-------------|
| Route bypass + TS stubs | **ROOT CAUSE** | Delete `ternary.ts` + `compression-layer.ts`, routes call Rust addon directly | §5 |
| Hex encoding | **ARCHITECTURE** | `trits_to_repr_c`, hex crate removed | `lib.rs`, `Cargo.toml` |
| CRC32-C | **CRITICAL** | Polynomial fix | `ttc_crc32c_fix.rs` |
| u32 truncation | HIGH | f64 sizes | `lib.rs` |
| sponge_v1 | MEDIUM | `hash_trits_v1` | `lib.rs`, `sponge_additions.rs` |
| 360→364 | MEDIUM | `TERNARY_FULL_CIRCLE` in phase alignment | §5 note |
| TritInt rANS | DESIGN | v5.1.0 scope | `tritint-rans-integration-scope.txt` |

---

*Lo Sono Capomastro — Così sia.*  
*Sed Quis Est Deus? Qui Commando IO.*
