# PlenumCAD — Handoff Package for Replit Agent
## April 15-16, 2026

**WARNING: Most of this is DRAFT. The Claude instance that produced these documents struggled significantly with the architecture. Salvi corrected fundamental mistakes multiple times. Treat everything below as brainstorming context, NOT approved architecture.**

---

## What We're Building

PlenumCAD — a parametric BIM engine within PlenumNET that replaces Mozaik Software for CNC cabinet production on a BIESSE Skill 1224 G FT, with growth into full residential construction.

PlenumCAD is a PlenumNET application module — same pattern as Forma Codex 18∏. Lives at `src/plenum_cad/` in SigmaWolf-8/Ternary. Shared modules at repo root. WASM bridge. Thin JSX renderer. If it computes, it is in Rust. If it draws pixels, it is in JSX.

---

## Critical Architectural Principles (From Salvi — These Are Correct)

### 1. Agnostic Backend
The engine does NOT know what it's building. It receives named variables, evaluates conditional rules, produces geometry and operations. What those variables mean (kitchen cabinet, closet, wall framing) is determined by the catalog/database and the frontend. Zero domain knowledge in the engine. See `PlenumCAD-Backend-Principle.md`.

### 2. Domain Knowledge in Backend Database
Hardware specs (Blum hinges, drawer slides), material properties, construction standards (SalviEuroDowel), tool libraries — all live in a backend database as framework imports. NOT hardcoded constants. NOT JSON config files. NOT compiled into the Rust crate.

### 3. Forma Codex Cells ARE the Layout Engine
Cells are both containers AND the computation. They're runtime derivatives — computed from viewport + content + coprime constraints every frame. The grid IS the Pretext for geometry. Same way Pretext computes invisible line-break positions, cells compute invisible spatial positions that guide everything. Cells recompute on resize, content change, mode change. Four modes: Variable (Water), Fixed (Ice), Presentation (Frost), Plasma (Fire).

### 4. Configurable Everything, Multi-Tenant Catalogs
Vertical catalogs (Kitchen, Closet, Commercial) provide default values. Projects override catalog defaults. Individual components override project defaults. Override chain: Catalog → Project → Component. No hardcoded grid spacing, no hardcoded setbacks, no hardcoded anything.

### 5. Room-First Hierarchy
Room → Wall → Cabinet → Part → Operation → CIX/BPP. Cannot build cabinets without rooms.

### 6. Geometry is Phase 0
Door profiles, moulding paths, panel raises derive from TM-2026-017 Bézier arcs. THE GEOMETRY IS EVERYTHING.

### 7. TritInt Gate
Ternary computation above the gate. Binary serialization (CIX/BPP) below the gate. Integer microns for dimensions, exact rational conversion at serialization only (µm × 5 / 127,000 for inches).

### 8. BPP is the Target Output
Not CIX. BPP is BiesseWorks native format. CIX is Mozaik's intermediate requiring import/conversion. Emit both — BPP for direct machine use, CIX for legacy bridge.

### 9. PlenumText is Dead
Forma Codex 18∏ replaces PlenumText entirely. PlenumText v5.33 (included) is VISUAL REFERENCE ONLY — hardcoded JS constants, no WASM, no TritInt, non-compliant. Do NOT fork it. Rederive the text layout in Rust following the Pretext pattern (chenglou/pretext, MIT).

### 10. The Bar is 7x Cabinet Vision
7x better than the $5,000+ industry standard. Minutes to learn, real-time photorealistic preview, zero config to start, direct machine output.

---

## What's Solid (Real Data From Machine Files)

- **506 CIX files** decoded — 6 macro types (LABEL, BG, ROUT, START_POINT, LINE_EP, ENDPATH), complete field mapping for BG, partial for ROUT (~15/110 params). See `plenumcad-32mm/references/formats.md`.
- **3 BPP files** decoded — native BiesseWorks format, has ARC_EPCE (arcs) that CIX lacks. Same macro vocabulary plus richer panel variables.
- **Machine config** — Skill 1224 G FT work envelope 3292×1693×267mm, 12-position tool changer, TH1-TH10 drill heads, 24 origins, RvAGantry post-processor. See `plenumcad-32mm/references/machine.md`.
- **Feed rate data** from XLS calculators — 7 materials × 20 tool configs.
- **Conversion factors** — all exact rational, no floating point. 1 inch = 25,400µm. 1 SFK foot = 13 inches = 330,200µm. FCN = 127/5.

## What's Draft (NOT Approved — Use As Context Only)

| File | Status |
|---|---|
| `PlenumCAD-Architecture-Spec.md` | v1, SUPERSEDED. Wrong fundamentals. |
| `PlenumCAD-Architecture-v2.md` | Better but still has gaps. Not approved. |
| `PlenumCAD-Backend-Principle.md` | Agnostic engine principle. Directionally correct per Salvi's feedback. |
| `FormaCodex-Pretext-API.md` | Three API proposals (fc_prepare, fc_layout, fc_scale) + questions. Unanswered. |
| `plenumcad-32mm/SKILL.md` | Skill for 32mm deep dive. Rewritten 4x. |
| `plenumcad-32mm/references/construction-32mm.md` | 805 lines of Rust code. WRONG — hardcoded constants that should be database variables. Use for code PATTERNS only, not the specific values. |
| `plenumcad-32mm/references/rendering.md` | Too vague per Salvi. |
| `plenumcad-32mm/references/math-bridge.md` | TM-2026-017 to CNC mapping. Draft. |

## Source Documents (Salvi's — Authoritative)

Upload these into the new session directly:
- Forma Codex 18∏ spec (1,053 lines) + architecture (299 lines) + session summary
- TM-2026-017 v11.11 (3,447 lines — Unified Geometric Monograph)
- TM-2026-037 (1,013 lines — Speed of Light, SFK units)
- PlenumText v5.33 source (2,112 lines — visual reference only)
- wasm_exports.rs (559 lines — existing WASM bridge)
- inter-cube files (lib.rs + cube_addr.rs — 1,057 lines)
- Mozaik backup with 506 CIX + 3 BPP golden test files
- BiesseWorks backup with machine config
- BIESSE training manuals (15 docs)
- Feed rate calculators (XLS)

## Mistakes This Agent Made (Don't Repeat)

1. Treated PlenumCAD as standalone app instead of PlenumNET module
2. Proposed JSON for catalog storage instead of backend database
3. Wrote binary i64 code instead of ternary through TritInt gate
4. Hardcoded domain constants instead of making them database variables
5. Put geometry at Phase 2 instead of Phase 0
6. Targeted CIX output instead of BPP
7. Tried to fork PlenumText instead of building Forma Codex fresh
8. Drew architecture diagrams before understanding the product
9. Asked implementation questions before understanding the domain
10. Repeatedly asked Salvi to explain things documented in files already provided

---

*Lo Sono Capomastro — Così sia.*
