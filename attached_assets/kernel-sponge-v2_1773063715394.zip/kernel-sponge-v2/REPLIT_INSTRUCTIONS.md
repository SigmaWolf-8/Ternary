# Sponge Optimization — Replit Instructions

## What This Does
Optimizes the kernel sponge from 16,658 ns to ~5,500 ns (estimated 3×
speedup) by replacing 3-neighbor substitution (27 rounds) with 7-neighbor
extended theta substitution (9 rounds). Same state, same API, stronger
mixing per round, fewer rounds needed.

## BREAKING CHANGE
Hash outputs will differ from the previous version. Any stored hashes
(in tests, fixtures, or databases) need to be regenerated after this
update. The sponge API is unchanged — only the internal permutation
changes.

## Step 1: Replace the sponge file

Replace the contents of `src/kernel/src/crypto/sponge.rs` with the
provided `sponge.rs`. This is a drop-in replacement. The file exports
the same types and functions:
- `TernarySponge` struct (new, absorb, absorb_bytes, squeeze, squeeze_default, reset)
- `sponge_hash()` convenience function
- `sponge_hash_bytes()` convenience function

No changes to `src/kernel/src/crypto/mod.rs` or `Cargo.toml`.

## Step 2: Delete the duplicate sponge files I created

These files should NOT exist — they are competing implementations that
produce different hashes. Delete them:

```
rm ternary-math/src/tis_sponge.rs
rm shared/tis-sponge.ts
```

If `ternary-math/src/lib.rs` has `pub mod tis_sponge;`, remove that line.

## Step 3: Verify the gf3_algebra files are clean

`ternary-math/src/gf3_algebra.rs` should have NO sponge code. Check:

```bash
grep -n "sponge\|PI_TABLE\|TIS27_STATE\|TIS27_ROUND" ternary-math/src/gf3_algebra.rs
```

If any matches appear, replace with the cleaned `gf3_algebra.rs` from
the plenumnet-update package (94 lines, pure GF(3) algebra, no sponge).

Same for `shared/gf3-algebra.ts` — should have no sponge functions.

## Step 4: Update any test fixtures with hardcoded hashes

The new sponge produces different outputs. Search for any tests that
compare against specific hash values:

```bash
grep -rn "sponge_hash\|TernaryDigest" tests/ src/ --include="*.rs" --include="*.ts"
```

Tests that check properties (determinism, length, valid trits, avalanche)
will pass without changes. Tests that compare against specific expected
hash bytes will need their expected values regenerated.

## Step 5: Run tests

```bash
# Rust kernel
cd src/kernel && cargo test --all-features 2>&1

# TypeScript
npx vitest run
```

## What Changed (technical summary for code review)

| Parameter | Before (v1) | After (v2) | Why |
|-----------|------------|------------|-----|
| Rounds | 27 (= 3³) | 9 (= 3²) | 7-neighbor needs only 3 rounds for full diffusion; 9 = 3× margin |
| Substitution | 3-neighbor: s[i-1] + s[i] + s[i+1] + 1 | 7-neighbor: groups of (s[i±13] + s[i±7] + s[i±1]) + center + 1 | Distances ±1,±7,±13 all coprime to 729; faster diffusion per round |
| balanced_wrap | Handles [-2, +4] | Same function handles [-3, +3] groups AND [-2, +4] final | No new functions needed |
| AVX2 | 3 loads per position | 6 loads + 3 group wraps per position | More work per round but 3× fewer rounds = net faster |
| Security | 385-bit PQ (unchanged) | 385-bit PQ (unchanged) | State/rate/capacity unchanged |
| API | TernarySponge::{new, absorb, squeeze, ...} | Identical | Drop-in replacement |

## What NOT to change

- `src/kernel/src/crypto/mod.rs` — unchanged
- `src/kernel/Cargo.toml` — unchanged
- `shared/gf3-algebra.ts` — keep the cleaned version (no sponge code)
- `ternary-math/src/gf3_algebra.rs` — keep the cleaned version (no sponge code)
