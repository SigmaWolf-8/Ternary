/*
 * THREE-WAY BENCHMARK: Kernel Sponge vs TIS-27/81 vs Industry
 * Copyright (c) 2025-2026 Capomastro Holdings Ltd.
 *
 * 1. KERNEL: 729-trit state, balanced {-1,0,+1}, 27 rounds, π=376i+1
 * 2. TIS-27: 54-trit state, unsigned {0,1,2}, 4 rounds, 7-neighbor theta
 * 3. TIS-81: 243-trit state, unsigned {0,1,2}, 4 rounds, 7-neighbor theta
 * 4. Industry: SHA-256, SHA3-256 (OpenSSL)
 *
 * gcc -O2 -march=native -mavx2 -o three_way three_way.c -lcrypto
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <immintrin.h>
#include <openssl/sha.h>
#include <openssl/evp.h>

static inline double now_ns(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec*1e9+ts.tv_nsec;}
volatile uint64_t bsink=0;

/* ══════════════════════════════════════════════════════════════
 * KERNEL SPONGE: 729-trit, balanced ternary, 27 rounds
 * Exact C port of src/kernel/src/crypto/sponge.rs
 * ══════════════════════════════════════════════════════════════ */

#define KS 729
#define KR 243
#define KROUNDS 27
#define KLANES 27

static inline int8_t balanced_wrap(int8_t s) {
    if (s >= 2) return s - 3;
    if (s <= -2) return s + 3;
    return s;
}

static inline int8_t trit_add(int8_t a, int8_t b) {
    int8_t s = a + b;
    if (s > 1) return s - 3;
    if (s < -1) return s + 3;
    return s;
}

/* Precomputed at init */
static uint16_t K_PERM[KS];
static int8_t K_RC[KROUNDS][KLANES];

static void kernel_init(void) {
    for (int i = 0; i < KS; i++) K_PERM[i] = (i * 376 + 1) % KS;
    for (int r = 0; r < KROUNDS; r++)
        for (int l = 0; l < KLANES; l++)
            K_RC[r][l] = (int8_t)((r*7 + l*13 + 3) % 3) - 1;
}

static void kernel_permutation(int8_t state[KS]) {
    int8_t buf[KS];
    for (int round = 0; round < KROUNDS; round++) {
        /* Substitution: balanced_wrap(left + center + right + 1) */
        buf[0] = balanced_wrap(state[KS-1] + state[0] + state[1] + 1);
        for (int i = 1; i < KS-1; i++)
            buf[i] = balanced_wrap(state[i-1] + state[i] + state[i+1] + 1);
        buf[KS-1] = balanced_wrap(state[KS-2] + state[KS-1] + state[0] + 1);

        /* Diffusion: π(i) = (376·i + 1) mod 729 */
        for (int i = 0; i < KS; i++) state[K_PERM[i]] = buf[i];

        /* Round constants */
        for (int l = 0; l < KLANES; l++)
            state[l * KLANES] = balanced_wrap(state[l * KLANES] + K_RC[round][l]);
    }
}

static void kernel_hash(const int8_t *input, int inlen, int8_t *output, int outlen) {
    int8_t state[KS]; memset(state, 0, KS);
    int off = 0;
    while (off < inlen) {
        int block = inlen - off; if (block > KR) block = KR;
        for (int i = 0; i < block; i++) state[i] = trit_add(state[i], input[off+i]);
        kernel_permutation(state);
        off += KR;
    }
    /* Padding */
    if (off == 0 || off != inlen) {
        /* Already absorbed partial, add pad */
    }
    int got = 0;
    while (got < outlen) {
        int take = outlen - got; if (take > KR) take = KR;
        memcpy(output + got, state, take);
        got += take;
        if (got < outlen) kernel_permutation(state);
    }
}

/* ══════════════════════════════════════════════════════════════
 * KERNEL SPONGE AVX2: same algorithm, SIMD substitution
 * ══════════════════════════════════════════════════════════════ */

static void kernel_permutation_avx2(int8_t state[KS]) {
    int8_t ext[KS+2];
    int8_t buf[KS];

    __m256i v_one = _mm256_set1_epi8(1);
    __m256i v_hi = _mm256_set1_epi8(1);
    __m256i v_lo = _mm256_set1_epi8(-1);
    __m256i v_three = _mm256_set1_epi8(3);

    for (int round = 0; round < KROUNDS; round++) {
        ext[0] = state[KS-1];
        memcpy(ext+1, state, KS);
        ext[KS+1] = state[0];

        int i = 0;
        while (i + 32 <= KS) {
            __m256i left = _mm256_loadu_si256((__m256i*)(ext+i));
            __m256i center = _mm256_loadu_si256((__m256i*)(ext+i+1));
            __m256i right = _mm256_loadu_si256((__m256i*)(ext+i+2));
            __m256i sum = _mm256_add_epi8(_mm256_add_epi8(_mm256_add_epi8(left,center),right),v_one);
            __m256i gt1 = _mm256_cmpgt_epi8(sum, v_hi);
            __m256i lt_neg = _mm256_cmpgt_epi8(v_lo, sum);
            __m256i result = _mm256_blendv_epi8(sum, _mm256_sub_epi8(sum,v_three), gt1);
            result = _mm256_blendv_epi8(result, _mm256_add_epi8(sum,v_three), lt_neg);
            _mm256_storeu_si256((__m256i*)(buf+i), result);
            i += 32;
        }
        while (i < KS) {
            buf[i] = balanced_wrap(ext[i] + ext[i+1] + ext[i+2] + 1);
            i++;
        }
        for (int i = 0; i < KS; i++) state[K_PERM[i]] = buf[i];
        for (int l = 0; l < KLANES; l++)
            state[l*KLANES] = balanced_wrap(state[l*KLANES] + K_RC[round][l]);
    }
}

static void kernel_hash_avx2(const int8_t *input, int inlen, int8_t *output, int outlen) {
    int8_t state[KS]; memset(state, 0, KS);
    int off = 0;
    while (off < inlen) {
        int block = inlen - off; if (block > KR) block = KR;
        for (int i = 0; i < block; i++) state[i] = trit_add(state[i], input[off+i]);
        kernel_permutation_avx2(state);
        off += KR;
    }
    int got = 0;
    while (got < outlen) {
        int take = outlen - got; if (take > KR) take = KR;
        memcpy(output + got, state, take);
        got += take;
        if (got < outlen) kernel_permutation_avx2(state);
    }
}

/* ══════════════════════════════════════════════════════════════
 * TIS-27: 54-trit, unsigned GF(3), 4 rounds, 7-neighbor theta
 * ══════════════════════════════════════════════════════════════ */

#define T27W 54
#define T27R 27
#define T27PAD 64

static const uint8_t T27_PI[54]={
    0,13,26,39,52,11,24,37,50,9,22,35,48,7,20,33,46,5,
    18,31,44,3,16,29,42,1,14,27,40,53,12,25,38,51,10,23,
    36,49,8,21,34,47,6,19,32,45,4,17,30,43,2,15,28,41};
static const uint8_t T27_RC[27]={0,0,1,1,2,1,1,1,0,2,0,2,1,0,0,1,1,2,1,1,1,0,2,0,2,1,0};
static uint8_t T27_RCS[4][32] __attribute__((aligned(16)));

static inline __m128i smod3(__m128i v){
    __m128i three=_mm_set1_epi8(3),two=_mm_set1_epi8(2);
    __m128i m=_mm_cmpgt_epi8(v,two);v=_mm_sub_epi8(v,_mm_and_si128(m,three));
    m=_mm_cmpgt_epi8(v,two);v=_mm_sub_epi8(v,_mm_and_si128(m,three));
    return v;}

static void tis27_init(void){
    memset(T27_RCS,0,sizeof(T27_RCS));
    for(int r=0;r<4;r++)for(int i=0;i<27;i++){int x=i+r;T27_RCS[r][i]=T27_RC[x>=27?x-27:x];}
}

__attribute__((hot,noinline))
static void tis27_hash(const uint8_t in[27],uint8_t out[27]){
    uint8_t __attribute__((aligned(16))) s[T27PAD],L13[T27PAD],L7[T27PAD],L1[T27PAD],R1[T27PAD],R7[T27PAD],R13[T27PAD],t[T27PAD],p[T27PAD];
    memset(s,0,T27PAD);memcpy(s,in,T27R);
    for(int r=0;r<4;r++){
        memcpy(L13,s+13,41);memcpy(L13+41,s,13);memset(L13+T27W,0,T27PAD-T27W);
        memcpy(L7,s+7,47);memcpy(L7+47,s,7);memset(L7+T27W,0,T27PAD-T27W);
        memcpy(L1,s+1,53);memcpy(L1+53,s,1);memset(L1+T27W,0,T27PAD-T27W);
        memcpy(R1,s+53,1);memcpy(R1+1,s,53);memset(R1+T27W,0,T27PAD-T27W);
        memcpy(R7,s+47,7);memcpy(R7+7,s,47);memset(R7+T27W,0,T27PAD-T27W);
        memcpy(R13,s+41,13);memcpy(R13+13,s,41);memset(R13+T27W,0,T27PAD-T27W);
        for(int i=0;i<T27PAD;i+=16){
            __m128i lg=smod3(_mm_add_epi8(_mm_add_epi8(_mm_load_si128((__m128i*)(R13+i)),_mm_load_si128((__m128i*)(R7+i))),_mm_load_si128((__m128i*)(R1+i))));
            __m128i rg=smod3(_mm_add_epi8(_mm_add_epi8(_mm_load_si128((__m128i*)(L1+i)),_mm_load_si128((__m128i*)(L7+i))),_mm_load_si128((__m128i*)(L13+i))));
            _mm_store_si128((__m128i*)(t+i),smod3(_mm_add_epi8(_mm_add_epi8(lg,_mm_load_si128((__m128i*)(s+i))),rg)));
        }
        memset(p,0,T27PAD);for(int i=0;i<T27W;i++)p[i]=t[T27_PI[i]];
        __m128i s0=_mm_load_si128((__m128i*)p);_mm_store_si128((__m128i*)p,smod3(_mm_add_epi8(s0,_mm_load_si128((__m128i*)T27_RCS[r]))));
        __m128i s1=_mm_load_si128((__m128i*)(p+16));_mm_store_si128((__m128i*)(p+16),smod3(_mm_add_epi8(s1,_mm_load_si128((__m128i*)(T27_RCS[r]+16)))));
        memcpy(s,p,T27W);memset(s+T27W,0,T27PAD-T27W);
    }
    memcpy(out,s,T27R);
}

/* ══════════════════════════════════════════════════════════════
 * TIS-81: 243-trit, unsigned GF(3), 4 rounds, 7-neighbor theta
 * ══════════════════════════════════════════════════════════════ */

#define T81W 243
#define T81R 81
#define T81PAD 256

static inline uint8_t umod3(uint8_t n){if(n>=3)n-=3;if(n>=3)n-=3;return n;}
static inline uint8_t uga(uint8_t a,uint8_t b){uint8_t s=a+b;return s>=3?s-3:s;}

__attribute__((hot,noinline))
static void tis81_hash(const uint8_t *in81, uint8_t *out81){
    uint8_t __attribute__((aligned(16))) s[T81PAD],L13[T81PAD],L7[T81PAD],L1[T81PAD],R1[T81PAD],R7[T81PAD],R13[T81PAD],t[T81PAD],p[T81PAD];
    memset(s,0,T81PAD);memcpy(s,in81,T81R);
    static uint16_t pi81[243]; static int pi_init=0;
    if(!pi_init){for(int i=0;i<243;i++)pi81[i]=(i*13)%243;pi_init=1;}
    static uint8_t rcs81[4][256]; static int rc_init=0;
    if(!rc_init){memset(rcs81,0,sizeof(rcs81));for(int r=0;r<4;r++)for(int i=0;i<81;i++){int x=i+r;while(x>=27)x-=27;rcs81[r][i]=(uint8_t[]){0,0,1,1,2,1,1,1,0,2,0,2,1,0,0,1,1,2,1,1,1,0,2,0,2,1,0}[x];}rc_init=1;}

    for(int r=0;r<4;r++){
        memcpy(L13,s+13,230);memcpy(L13+230,s,13);memset(L13+T81W,0,T81PAD-T81W);
        memcpy(L7,s+7,236);memcpy(L7+236,s,7);memset(L7+T81W,0,T81PAD-T81W);
        memcpy(L1,s+1,242);memcpy(L1+242,s,1);memset(L1+T81W,0,T81PAD-T81W);
        memcpy(R1,s+242,1);memcpy(R1+1,s,242);memset(R1+T81W,0,T81PAD-T81W);
        memcpy(R7,s+236,7);memcpy(R7+7,s,236);memset(R7+T81W,0,T81PAD-T81W);
        memcpy(R13,s+230,13);memcpy(R13+13,s,230);memset(R13+T81W,0,T81PAD-T81W);
        for(int i=0;i<T81PAD;i+=16){
            __m128i lg=smod3(_mm_add_epi8(_mm_add_epi8(_mm_load_si128((__m128i*)(R13+i)),_mm_load_si128((__m128i*)(R7+i))),_mm_load_si128((__m128i*)(R1+i))));
            __m128i rg=smod3(_mm_add_epi8(_mm_add_epi8(_mm_load_si128((__m128i*)(L1+i)),_mm_load_si128((__m128i*)(L7+i))),_mm_load_si128((__m128i*)(L13+i))));
            _mm_store_si128((__m128i*)(t+i),smod3(_mm_add_epi8(_mm_add_epi8(lg,_mm_load_si128((__m128i*)(s+i))),rg)));
        }
        memset(p,0,T81PAD);for(int i=0;i<T81W;i++)p[i]=t[pi81[i]];
        for(int i=0;i<96;i+=16){
            __m128i sv=_mm_load_si128((__m128i*)(p+i));
            __m128i rv=_mm_loadu_si128((__m128i*)(rcs81[r]+i));
            _mm_store_si128((__m128i*)(p+i),smod3(_mm_add_epi8(sv,rv)));
        }
        memcpy(s,p,T81W);memset(s+T81W,0,T81PAD-T81W);
    }
    memcpy(out81,s,T81R);
}

/* ══════════════════════════════════════════════════════════════ */

#define ITERS 1000000

int main(void) {
    kernel_init();
    tis27_init();

    /* Test inputs */
    int8_t kin[243]; for(int i=0;i<243;i++) kin[i]=(i%3)-1;
    uint8_t tin27[27]; for(int i=0;i<27;i++) tin27[i]=i%3;
    uint8_t tin81[81]; for(int i=0;i<81;i++) tin81[i]=i%3;
    uint8_t raw27[27]; for(int i=0;i<27;i++) raw27[i]=(i*7+3)&0xFF;

    int8_t kout[243]; uint8_t tout27[27]; uint8_t tout81[81]; uint8_t sha_out[32];

    /* Warmup */
    for(int w=0;w<ITERS/10;w++){
        kernel_hash(kin,243,kout,243); kernel_hash_avx2(kin,243,kout,243);
        tis27_hash(tin27,tout27); tis81_hash(tin81,tout81);
        SHA256(raw27,27,sha_out);
        bsink+=kout[0]+tout27[0]+tout81[0]+sha_out[0];
    }

    double s,e,ns;

    printf("╔═══════════════════════════════════════════════════════════════════════════╗\n");
    printf("║  THREE-WAY SPONGE BENCHMARK — %d iterations each                  ║\n",ITERS);
    printf("║  Capomastro Holdings Ltd. — Applied Physics Division                     ║\n");
    printf("╠═══════════════════════════════════════════════════════════════════════════╣\n");
    printf("║                                                                          ║\n");
    printf("║  A. KERNEL SPONGE: 729 trits, balanced {-1,0,+1}, 27 rounds             ║\n");
    printf("║     State: 3⁶=729 | Rate: 3⁵=243 | Cap: 486 (770 bits)                 ║\n");
    printf("║     Permutation: π(i)=(376i+1) mod 729 | Sbox: balanced_wrap(a+b+c+1)   ║\n");
    printf("║                                                                          ║\n");
    printf("║  B. TIS-27: 54 trits, unsigned {0,1,2}, 4 rounds, 7-neighbor theta      ║\n");
    printf("║     State: 54 | Rate: 27 | Cap: 27 (43 bits)                            ║\n");
    printf("║     Permutation: (i×13) mod 54 | Theta: ±1,±7,±13 neighbors             ║\n");
    printf("║                                                                          ║\n");
    printf("║  C. TIS-81: 243 trits, unsigned {0,1,2}, 4 rounds, 7-neighbor theta     ║\n");
    printf("║     State: 243 | Rate: 81 | Cap: 162 (257 bits)                         ║\n");
    printf("║     Permutation: (i×13) mod 243 | Theta: ±1,±7,±13 neighbors            ║\n");
    printf("║                                                                          ║\n");
    printf("╠═══════════════════════════════════════════════════════════════════════════╣\n");
    printf("║  IMPLEMENTATION           │ INPUT  │  TIME (ns) │  THROUGHPUT │ SECURITY ║\n");
    printf("╠═══════════════════════════════════════════════════════════════════════════╣\n");

    s=now_ns();for(int i=0;i<ITERS;i++){kernel_hash(kin,243,kout,243);bsink+=kout[0];}e=now_ns();ns=(e-s)/ITERS;
    printf("║  Kernel scalar (27r)       │ 243 tr │ %8.0f   │ %6.0fK/s   │ 385 bit  ║\n",ns,1e6/ns);
    double k_scalar=ns;

    s=now_ns();for(int i=0;i<ITERS;i++){kernel_hash_avx2(kin,243,kout,243);bsink+=kout[0];}e=now_ns();ns=(e-s)/ITERS;
    printf("║  Kernel AVX2 (27r)         │ 243 tr │ %8.0f   │ %6.0fK/s   │ 385 bit  ║\n",ns,1e6/ns);
    double k_avx2=ns;

    s=now_ns();for(int i=0;i<ITERS;i++){tis27_hash(tin27,tout27);bsink+=tout27[0];}e=now_ns();ns=(e-s)/ITERS;
    printf("║  TIS-27 SSE2 (4r, 7-nbr)  │  27 tr │ %8.0f   │ %6.0fK/s   │  21 bit  ║\n",ns,1e6/ns);
    double t27=ns;

    s=now_ns();for(int i=0;i<ITERS;i++){tis81_hash(tin81,tout81);bsink+=tout81[0];}e=now_ns();ns=(e-s)/ITERS;
    printf("║  TIS-81 SSE2 (4r, 7-nbr)  │  81 tr │ %8.0f   │ %6.0fK/s   │ 128 bit  ║\n",ns,1e6/ns);
    double t81=ns;

    s=now_ns();for(int i=0;i<ITERS;i++){SHA256(raw27,27,sha_out);bsink+=sha_out[0];}e=now_ns();ns=(e-s)/ITERS;
    printf("║  SHA-256 (OpenSSL)         │  27 B  │ %8.0f   │ %6.0fK/s   │ 128 bit  ║\n",ns,1e6/ns);
    double sha=ns;

    uint8_t sha3_out[32]; unsigned int sha3_len;
    s=now_ns();for(int i=0;i<ITERS;i++){
        EVP_MD_CTX*c=EVP_MD_CTX_new();EVP_DigestInit_ex(c,EVP_sha3_256(),NULL);
        EVP_DigestUpdate(c,raw27,27);EVP_DigestFinal_ex(c,sha3_out,&sha3_len);EVP_MD_CTX_free(c);bsink+=sha3_out[0];}e=now_ns();ns=(e-s)/ITERS;
    printf("║  SHA3-256 (OpenSSL)        │  27 B  │ %8.0f   │ %6.0fK/s   │ 128 bit  ║\n",ns,1e6/ns);
    double sha3=ns;

    printf("╠═══════════════════════════════════════════════════════════════════════════╣\n");
    printf("║  ANALYSIS                                                                ║\n");
    printf("╠═══════════════════════════════════════════════════════════════════════════╣\n");
    printf("║                                                                          ║\n");
    printf("║  Kernel vs SHA-256:        %.1fx %s                                  ║\n",
        k_avx2<sha?sha/k_avx2:k_avx2/sha, k_avx2<sha?"FASTER":"slower");
    printf("║  Kernel vs SHA3-256:       %.1fx %s                                  ║\n",
        k_avx2<sha3?sha3/k_avx2:k_avx2/sha3, k_avx2<sha3?"FASTER":"slower");
    printf("║  TIS-27 vs SHA-256:        %.1fx %s                                  ║\n",
        t27<sha?sha/t27:t27/sha, t27<sha?"FASTER":"slower");
    printf("║  TIS-81 vs SHA3-256:       %.1fx %s                                  ║\n",
        t81<sha3?sha3/t81:t81/sha3, t81<sha3?"FASTER":"slower");
    printf("║  Kernel vs TIS-27:         %.1fx %s (different security!)            ║\n",
        k_avx2<t27?t27/k_avx2:k_avx2/t27, k_avx2<t27?"FASTER":"slower");
    printf("║  Kernel vs TIS-81:         %.1fx %s                                  ║\n",
        k_avx2<t81?t81/k_avx2:k_avx2/t81, k_avx2<t81?"FASTER":"slower");
    printf("║  Kernel scalar→AVX2:       %.1fx speedup                                 ║\n",k_scalar/k_avx2);
    printf("║                                                                          ║\n");
    printf("║  POST-QUANTUM SECURITY:                                                  ║\n");
    printf("║    Kernel:  486 capacity trits = 770 bits → 385 bits under Grover  ✓     ║\n");
    printf("║    TIS-81:  162 capacity trits = 257 bits → 128 bits under Grover  ✓     ║\n");
    printf("║    TIS-27:   27 capacity trits =  43 bits →  21 bits under Grover  ✗     ║\n");
    printf("║    SHA-256:  128 bits classical → 128 bits (no PQ proof)           ✗     ║\n");
    printf("║    SHA3-256: 256 capacity bits  → 128 bits under Grover            ✓     ║\n");
    printf("║                                                                          ║\n");
    printf("╚═══════════════════════════════════════════════════════════════════════════╝\n");

    return 0;
}
