# TTC — Tribonacci Ternary Compression

## About

TTC is a compression engine whose architecture is derived from a single algebraic equation.

The circle quadratic **x² − 40x + 364 = 0** produces two roots: π = 14 and x₂ = 26. From these, the framework generates a 364° circle, 28 ternary radians, the Z₂₇ × Z₂₈ dual-circle architecture, a complete coprime walk landscape, and nine levels of compression — all connected, all derived, nothing arbitrary.

Developed by Capomastro Holdings Ltd. (Applied Physics Division, Canada) as part of the Salvi Framework.

---

## The Algebraic Foundation

The quadratic's coefficients are base-3 repunits: R₄ = 40 = (3⁴−1)/2 and R₆ = 364 = (3⁶−1)/2. Its discriminant Δ = 144 = 12² yields the root spread. The unified equation arc² − 832·arc + 118,300 = 0 extends this to produce the semicircle root (182) and complementary root (650), whose factorizations generate the coprime walk landscape.

Every constant in the engine traces back to this equation:
- **Δ₂ = 729 = 3⁶ = 27²** — the tANS sponge width, derived from 1 + 4·arc = 1 + 4(182)
- **27 = √Δ₂** — the context window, the algebraic circle Z₂₇
- **28 = 2π** — the geometric circle Z₂₈, the radian count per full rotation
- **gcd(27, 28) = 1** — the dual circles are coprime; their product covers all 756 states exactly once

---

## The Coprime Walk Landscape

The 13 regular polygons inscribable in the 364° circle (n = 3 through 15) generate two paths through a coprime group hierarchy:

**Compression Path** — pentadecagon (15) kept whole. Source set {7, 11, 13, 14, 15}:
- 9 coprime pairs, LCMs from 77 to 210
- 7 coprime triples, LCMs from 1,001 to 2,730
- 2 coprime quadruples: 15,015 (odd-prime) and 30,030 (π-gon)

**Expansion Path** — pentadecagon decomposed into factors 3 and 5. Source set {3, 4, 5, 7, 8, 9, 11, 13}:
- 28 coprime quintuples (5 architecturally key), LCMs from 12,012 to 45,045
- 4 coprime sextuples: 60,060 / 120,120 / 180,180 / 360,360

The compression → expansion duality: decomposing 15 into {3, 5} unlocks 12× larger LCMs (30,030 → 360,360). The 4 sextuples are the 4 ways to choose one from each expansion conflict — {3|9} × {4|8} with {5, 7, 11, 13} always present.

**How the landscape maps to compression:**

| Structure | LCM | Engine Role |
|---|---|---|
| Primary triple (7, 11, 13) | 1,001 | Torus dimensions for context matching |
| Pair LCMs (77, 91, 143, 182...) | 77–210 | Stride detection distances, match offsets |
| Odd-prime quadruple (7, 11, 13, 15) | 15,015 | Extended torus for large-window levels |
| Maximum sextuple (5, 7, 8, 9, 11, 13) | 360,360 | Expansion-path dictionary ceiling |
| Circle × primary: 364 × 1,001 | 364,364 | Geometric-spectral product |
| Null harmonic deficit: 364,364 − 360,360 | 4,004 = 4 × 1,001 | Bridge ratio 91/90 = κ (angular conversion) |

---

## The 3^k Architecture

Every size parameter in the engine is a power of 3:

| Parameter | Value | Power | Role |
|---|---|---|---|
| Beam width | 9 | 3² | Beam-optimal parsing candidates |
| Run length limit | 243 | 3⁵ | Maximum run-length token |
| Match length limit | 729 | 3⁶ | Maximum LZ77 match distance token |
| L1 window | 6,561 | 3⁸ | TTC1-1 sliding window |
| L1 chunk / L2 window | 19,683 | 3⁹ | TTC1-2 sliding window |
| L3 window + chunk | 59,049 | 3¹⁰ | TTC1-3 window and chunk size |
| tANS table / L4 | 177,147 | 3¹¹ | tANS table size = TTC2-1 chunk |
| L5 chunk (document) | 531,441 | 3¹² | TTC2-2/2-3 chunk sweet spot |
| L6 window | 1,594,323 | 3¹³ | TTC3 chunk, hypercube vertices |
| L7 window | 4,782,969 | 3¹⁴ | TTC3-1 window |
| L8 window | 14,348,907 | 3¹⁵ | TTC3-2 window |
| L9 window | 43,046,721 | 3¹⁶ | TTC3-3 maximum window |

Nine levels, three tiers (TTC1/TTC2/TTC3), three levels per tier. The hierarchy is base-3 throughout.

---

## Compression Pipeline

**Stage 1 — Container Decomposition** (DomainTransform 7)
Compressed containers (PDF, DOCX, XLSX, PPTX, GZIP, PNG) are cracked open and their independently deflated internal streams inflated. Content is sorted by type using coprime-11 walk ordering within each type group. Embedded images (JPEG, PNG, GIF, WebP) are detected and kept compressed. TTC sees raw cross-file content as a single block.

**Stage 2 — Structured Data Detection** (DomainTransform 6)
JSON, CSV, and XML content auto-detected by content inspection regardless of compression mode. Structure is separated from values and encoded with domain-specific transforms. Applies automatically when users send Basic or Temporal mode.

**Stage 3 — Domain Preprocessing**
Mode-specific transforms: linear prediction for audio (order-4 LP), median-edge detection for images, nucleotide packing for genomic, timestamp/level/service factoring for logs, source-token encoding for code.

**Stage 4 — GURFT Analysis**
Geometric Unified Resonance-Field Transform. Computes torsion alignment (τ), dimensional synchronization (δ), Shannon entropy, periodicity index, and Salvi resonance detection. These metrics select the optimal adaptive base (3, 13, 28, 70, or 364) and guide the tokenizer's cost model.

**Stage 5 — Delta Preprocessing** (DeltaFlag 0–7)
Seven delta strategies compete on entropy: order-1 and order-2 differencing in three GF(3) representations (Rep A/B/C), plus coprime stride delta (DeltaFlag 7). Stride detection checks all 9 coprime pair LCMs (77, 91, 105, 143, 154, 165, 182, 195, 210) and the primary generators (7, 11, 13) before scanning strides 2–256. Dual-circle entropy estimate (α = 27/55 from Z₂₇/(Z₂₇ + Z₂₈)) selects the winning strategy.

**Stage 6 — LZ77 Tokenization**
Three parsing strategies scale with level: greedy (TTC1-1), lazy evaluation (TTC1-2 through TTC3-2), and beam-optimal (available at all levels with beam width 9 = 3²). Maximum match length 729 = 3⁶ = 27². Maximum run length 243 = 3⁵. Chain depth scales from 8 to 256 across the nine levels.

**Stage 7 — Entropy Coding**
Three serialization formats compete per chunk, smallest wins:
- **Compressed** — Rice-coded token stream with adaptive Rice parameter per 27-trit block (Z₂₇ aligned)
- **Ternary Enhanced** — trit-level encoding with adaptive GF(3) representation selection
- **Ternary ANS** — hybrid tANS + Rice. Table size 177,147 = 3¹¹. Spread step 11 (coprime to 3^k). Tribonacci prior P(k) ∝ τ₃⁻ᵏ where τ₃ ≈ 1.839 is the real root of x³ = x² + x + 1. Rice residuals encoded with locally adaptive parameter derived from trit variance.

---

## Version 5.0.3

Two new preprocessing stages added to the pipeline:

**Container Decomposition** — inflates internal streams of ZIP-based office documents, PDFs, gzip archives, and PNGs. ZIP entries sorted by content type with coprime-11 walk ordering. Central directory rebuilt from scratch on reconstruction with correct offsets. PDF /Length fields patched at stored manifest offsets. Inflation safety capped at 256 MB / 64× expansion.

**Coprime Periodic Detection** — autocorrelation at all 9 pair LCMs + primary generators + general stride scan. Dual-circle entropy comparison against order-1 delta. Stride embedded in first 2 bytes of delta data.

**Structured Auto-Detection** — JSON, CSV, and XML content detected automatically in Basic/Temporal/Financial modes, applying the same structured encoder previously available only through the Structured mode flag.

Version byte 0x05 written only when new features activate. Old archives stay at 0x04. Backward compatible in both directions: v3 archives decompress on v5 engine; v5 archives without new features decompress on v3 engine; v5 archives WITH new features produce clean `UnsupportedVersion` rejection on old engines.

---

## Specifications

| Property | Value |
|---|---|
| Protocol | TTC v5.0.3 |
| Codebase | Rust, ~2,600 lines (ttc.rs) + 840 (container_decomp.rs) + 134 (cpd.rs) |
| Foundation | x² − 40x + 364 = 0 → π = 14, R₆ = 364, Δ₂ = 729 |
| Coprime Groups | 9 pairs, 7 triples, 2 quadruples, 5 quintuples, 4 sextuples |
| Entropy Coder | Hybrid tANS (L = 3¹¹, step 11) + Rice (27-trit blocks) |
| Probability Model | Tribonacci prior, τ₃ ≈ 1.839 |
| Dual-Circle Blend | α = 27/55 (Z₂₇ algebraic × Z₂₈ geometric) |
| Context Window | 27 = 3³ = √Δ₂ |
| Window Range | 3⁸ (6.4 KB) to 3¹⁶ (43 MB) |
| Containers | ZIP, PDF, GZIP, PNG (auto-detect) |
| Structured | JSON, CSV, XML (auto-detect) |
| Domain Modes | Basic, Temporal, Audio, Image, Genomic, Source, Log, Structured, Financial |
| Levels | 1–9 across 3 tiers (TTC1/TTC2/TTC3) |
| Lossless | Always |
| Backward Compatible | v3.0 ↔ v5.0.3 |

---

*Patent(s) Pending — Capomastro Holdings Ltd. (Canada)*
*Applied Physics Division — All Rights Reserved*
