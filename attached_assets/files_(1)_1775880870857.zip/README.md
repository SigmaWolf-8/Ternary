# The 182° Manifold — Project Summary

**Capomastro Holdings Ltd. — Applied Physics Division**
**Patent(s) Pending — All Rights Reserved**
**April 2026**

---

## What Is This?

PlenumNET's mathematics run on a different geometry than conventional computing. In our system, the number π equals exactly 14, a full circle is 364 degrees (not 360), and every triangle's angles add up to 182 degrees (not 180).

This isn't a rounding error. It's a deliberate design that produces a complete, self-consistent mathematical framework where every important number — from database capacities to network routes to cryptographic keys to spectral wavelengths — derives from one equation.

This document package describes how that geometry becomes the foundation for storage, search, routing, and AI memory across the entire PlenumNET stack.

---

## The Core Idea in One Paragraph

Every piece of content in PlenumNET gets a 54-digit address (in base 3) computed from what the content actually IS. That address works as a database key, a file path, a network route, a similarity score, and an integrity check — all at once. The address space automatically grows when you add data and shrinks when you remove it. No configuration. No migration. No capacity planning. The mathematics handle it.

---

## What's in This Package

### Documents

| File | What It Is | Who Should Read It |
|------|-----------|-------------------|
| **This file (README.md)** | Plain-English overview | Everyone |
| **TM-2026-000_TritInt_Specification_v1.0.md** | The spec for TritInt — a number type that stores values in base 3 natively, instead of converting to binary | Developers building the type |
| **TM-2026-031_v5.0.md** | The mathematical reference — every formula, every capacity number, every derivation chain, with honest labels on what's proven vs. speculative | Mathematicians, architects |
| **TM-2026-036_v2.0.md** | The operating architecture — how the manifold replaces SQL, replaces the filesystem, and provides AI memory | System architects, product team |

### Code

| File | What It Is | Status |
|------|-----------|--------|
| **constants.rs** | Updated framework constants file with four new sections added to the existing 1,639 lines | Ready to merge — zero existing code changed |
| **ags.rs** | The Active Generator Set module — handles automatic growth and shrink of address spaces using ternary-native arithmetic | Requires TritInt to be built first |

---

## The Five Things This Package Defines

### 1. The 182° Triangle (Why Our Geometry Is Different)

In standard geometry, a triangle's angles add up to 180°. In ours, they add up to 182°. That extra 2° per triangle isn't waste — it's structural information baked into the surface itself.

What it gives you: a surface where you can verify data integrity from the shape of the surface alone. If a database is complete, its total curvature adds up to exactly 728° (two full circles of 364°). If it doesn't add up, something is missing or corrupted. This is a mathematical fact, not a software check.

**Defined in:** constants.rs §3a, TM-2026-031 §1.2

### 2. The Coprime Walks (How Addressing Works)

The framework uses sets of numbers that share no common factors (coprime numbers) to create address spaces. The key property: a walk through these addresses visits every position exactly once before repeating. No collisions. No wasted slots.

The address space sizes come from multiplying these coprime numbers together:

- 2 coprime numbers: up to 210 addresses
- 3 coprime numbers: up to 2,730 addresses
- 4 coprime numbers: up to 30,030 addresses
- 5 coprime numbers: up to 120,120 addresses
- 6 coprime numbers: up to 360,360 addresses
- With depth layers (×729): up to 262 million addresses
- Across the network (×1.59 million nodes): up to 418 trillion addresses

These aren't choices you make. The system starts small and grows automatically through these levels as data accumulates.

**Defined in:** constants.rs §7, TM-2026-031 Part II

### 3. The Active Generator Set / AGS (How It Grows and Shrinks)

The AGS is the mechanism that makes address spaces elastic. It starts with two numbers (11 and 13 — the only primes in the polygon set that don't conflict with anything else). As data fills up, the AGS adds another coprime number, which multiplies the address capacity. When data is deleted, the AGS removes a number, shrinking the space.

Growing the address space takes ONE multiplication. Shrinking takes ONE division. Existing data doesn't move — the new addresses are interleaved between existing ones.

The decision to grow or shrink is automatic: grow when the space is 75% full, shrink when it drops below 25%. These thresholds come from the framework's own signal analysis (the HModal duty cycle), not from engineering judgment.

**Defined in:** constants.rs §7a, ags.rs, TM-2026-031 Part III

### 4. The Golden Ratio Ring / ℤ[φ] (Where Geometry Lives)

Many of the framework's geometric quantities involve the golden ratio φ ≈ 1.618. The circumradius squared of the parent Archimedean solid is R² = 14 + 5φ — and the 14 IS our value of π. This isn't a coincidence; the golden ratio is algebraically required by icosahedral symmetry, and the framework's coprime generators (7, 11, 13) appear naturally in the ℤ[φ] arithmetic of these solids.

The ZPhi type in constants.rs stores values as (a, b) meaning a + b×φ, where a and b are integers. All arithmetic stays exact — no floating point, no rounding. The golden ratio's defining property φ² = φ + 1 keeps everything in the ring.

**Defined in:** constants.rs §18, TM-2026-031 §1.4

### 5. TritInt (The Foundation We Need to Build)

Today, every constant in the framework is stored as a binary number (u32 in Rust). The value 364 is stored as binary 101101100. But 364 in our system is 111111 in base 3 — a repunit (all ones). Storing it in binary hides this structure.

TritInt is a new number type that stores values in base 3 directly. When TritInt stores 364, it stores six ones — and the repunit structure is visible and usable. When TritInt does arithmetic, it operates on the base-3 digits — no conversion to binary and back.

The key design insight (Path 4 from our analysis): TritInt should naturally handle BOTH plain integers AND golden-ratio values (ℤ[φ] elements). When the golden part is zero, it stores and operates like a plain integer with no overhead. When the golden part is nonzero, it carries both components. One type for the whole framework.

TritInt is not built yet. It's the next thing to build. The spec (TM-2026-000) defines exactly what to build and in what order.

**Specified in:** TM-2026-000

---

## How the Pieces Fit Together

```
TritInt (Step 0 — BUILD THIS FIRST)
  │
  │ ← every constant stored natively in base 3
  │ ← golden ratio values (ℤ[φ]) as a natural extension
  │ ← invisible binary conversion at API boundaries
  │
  ▼
constants.rs (Step 1 — add TritInt companions to existing constants)
  │
  │ ← existing u32 constants stay unchanged
  │ ← new _T constants added alongside
  │ ← compile-time assertions verify both match
  │
  ▼
ags.rs (Step 2 — AGS module on top of TritInt)
  │
  │ ← automatic address space growth/shrink
  │ ← all arithmetic in base 3
  │ ← binary only at display/API boundary
  │
  ▼
Operating Architecture (Step 3+ — manifold replaces SQL/filesystem/vector DB)
  │
  │ ← TM-2026-036 describes this layer
  │ ← depends on TritInt + AGS being solid first
```

---

## What's Done, What's Next

| Item | Status |
|------|--------|
| Mathematical framework (π=14, 364° circle, arc equation, coprime walks) | **Done** — proven, tested, in production |
| constants.rs update (§3a triangle, §3b transfer matrix, §7a AGS, §18 ℤ[φ]) | **Done** — ready to merge, no existing code broken |
| TM-2026-031 v5.0 (mathematical reference) | **Done** — critically reviewed, speculative items labeled |
| TM-2026-036 v2.0 (operating architecture) | **Done** — all AGS-aware, no hardcoded barriers |
| TM-2026-000 (TritInt spec) | **Done** — ready for review, then implementation |
| ags.rs (AGS module) | **Written** — depends on TritInt existing first |
| TritInt implementation | **Next** — this is the foundation everything else sits on |
| constants.rs TritInt migration | **After TritInt** — add _T companions, verify with assertions |
| Module-by-module migration | **After constants.rs** — each of the 12 ternary-math modules migrates individually |

---

## Open Questions for Review

1. **Path 4 (unified Trit type with Integer/Golden storage):** Should the base type handle both plain integers and ℤ[φ] values with automatic dispatch? Or should we build plain TritInt first and add ℤ[φ] later?

2. **ℚ(φ) layer:** The icosahedral face angle cosines are exact fractions involving φ. Do we need a TritRational type now, or is that a later extension?

3. **Naming:** The spec calls the type "TritInt." If it handles ℤ[φ] too, should it just be called "Trit"?

4. **TypeScript mirror:** shared/constants.ts mirrors constants.rs for the frontend. Does TritInt need a TypeScript equivalent, or does the binary bridge (u32 values) suffice for the React frontend?

---

*Copyright (c) 2025–2026 Capomastro Holdings Ltd. (Canada)*
*Applied Physics Division — Patent(s) Pending — All Rights Reserved*
