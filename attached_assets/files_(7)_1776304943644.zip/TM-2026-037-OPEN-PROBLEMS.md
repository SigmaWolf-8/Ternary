# TM-E1-037.049 — Open Problems

£ ∣ Q ∣ ∀ Rights Reserved Et Preserved | Fiat ∎ — Capomastro Holdings Ltd E+1

**R. Salvi** — Capomastro Holdings Ltd, Applied Physics Division
**Companion to:** TM-E1-037.049 (The Speed of Light) and TM-2026-017 v11.11 (Unified Geometric Monograph)
**Date:** April 2026

---

> **Veritas.** The following problems are open — meaning the framework has not derived them from first principles, or has derived them incompletely. Each is stated with what IS known, what is NOT known, and what a resolution would require. Honest accounting, not deferred claims.

---

## ~~0. The Formal Uniqueness Proof~~ — CLOSED

**Resolution:** Elementary squeeze between consecutive perfect squares. Effective bound **B = 4**.



Write f(x) = x⁶ − 2x⁵ − x⁴ − x² − 2x − 3 (the expanded discriminant of the circle quadratic). The proof traps f(x) between consecutive perfect squares for all x ≥ 4:

**Upper:** f(x) − (x³−x²−x−1)² = −4(x²+x+1). Always negative (discriminant −3, no real roots). One line.

**Lower:** f(x) − (x³−x²−x−2)² = 2x³−6x²−6x−7. At x = 4: equals **1** — the base-4 gap. Derivative 6(x²−2x−1) > 0 for x ≥ 4 > 1+√2. Monotonically increasing from 1. Never returns to zero.

**The squeeze:** For every integer x ≥ 4: (x³−x²−x−2)² < f(x) < (x³−x²−x−1)². No integer lies between consecutive squares. For x = 2: f(2) = −27. For x = 3: f(3) = 144 = 12². Only x = 3. ∎

**P(4) = 1.** The base-4 near-miss Δ(4) = 42² + 1 is the theorem's margin of victory AND the SFK foot's structural increment (13 = 3×4+1). The gap that proves the theorem IS the "+1" in the foot ratio. The proof is ten lines of undergraduate algebra. No Faltings, no Baker, no Chabauty needed.

The foundation is **proven**. The derivation chain from the base-3 uniqueness theorem through all 22 steps of TM-E1-037 rests on an elementary squeeze proof covering ALL integers — positive branch (Φ₃ closes x ≥ 4), negative branch (Φ₆ = Φ₃(−x) closes x ≤ −2), five direct checks ({−1,0,1,2,3}). Complete integer points: (−1, 0) trivial, (3, ±12) the theorem. For bases b ≥ 2: only b = 3.

---

## 1. The 3D Horn and the Obliquity Derivation

**Status:** PARTIALLY CLOSED. The precession period T_p = x₂ × pqr = 26,026 years is derived from the horn's density gradient F = π/x² at the bridge position (Step 19). The "external torque" of standard precession IS the horn's gradient — no gravity imported. The obliquity correction R₂/pqr to the tropical year is identified but not yet derived from the 3D geometry.

**What is now known:** The horn's gradient at x₂ provides the torque. The coprime walk provides the spin. The precession period = (V/F) × walk = x₂ × pqr. The precession cone IS the horn's revolution. The standard precession formula (requiring G, M, moment of inertia) is replaced by the horn's own V/F ratio at the bridge position.

**What remains open:** Deriving R₂/pqr = 4/1001 as a geometric consequence of the 3D horn construction. The obliquity angle (opening angle of the precession cone) must emerge from the horn's geometry at the bridge position. Candidate: the opening half-angle at x₂ could relate to arctan(E(x₂)) = arctan(1/26) ≈ 2.2° — but the actual obliquity is 23.44°, suggesting the relevant angle is not the tangent angle but a different geometric property of the 3D embedding.

**What resolution requires:** Embedding the 1D horn into the 3D crystal (TM-2026-017 §16) with the rotation axis tilted. The obliquity should emerge as a framework angle — possibly related to x₂ − base = 23° (integer part) with R₂/base² = 4/9 ≈ 0.444° (fractional correction).

---

## 2. The Tropical Year Residual (0.27 ppm)

**Status:** τ = 1,096,822/3003 = 365.24209 days. Measured: 365.24219 days. Residual: 0.0001 days ≈ 8.6 seconds per year.

**What is known:** Two corrections (x₂/(base×p) and R₂/pqr) account for 99.99973% of the measured tropical year. The denominator 3003 = base × pqr is pure framework.

**What is not known:** Whether a third correction term exists, or whether the 0.27 ppm residual reflects measurement epoch dependence. The mean tropical year varies by ±5 seconds depending on the reference epoch (equinox vs solstice, J2000 vs current).

**What resolution requires:** Either (a) a third-order correction from framework constants that closes the remaining 8.6 seconds, or (b) a demonstration that the framework's 365.24209 is the epoch-independent structural value, with the measured 365.24219 being epoch-dependent. The IAU's definition of the mean tropical year has evolved; the framework predicts a fixed rational value.

---

## 3. The Obliquity as a Framework Angle

**Status:** The integer part of Earth's obliquity is x₂ − base = 26 − 3 = 23°. The fractional part is approximately R₂/base² = 4/9 ≈ 0.444, giving 23.444° vs 23.439° measured (219 ppm). Noted, not claimed.

**What is known:** The obliquity is epoch-dependent, varying between 22.1° and 24.5° over a ~41,000-year Milankovitch cycle. The current value 23.4393° is not a constant.

**What is not known:** Whether the framework predicts a structural obliquity (the mean of the Milankovitch oscillation, or a fixed geometric angle), or whether the obliquity is external to the framework. The mean obliquity over the full Milankovitch cycle is approximately 23.3° — closer to x₂ − base = 23 than to 23.444.

**What resolution requires:** Framework trigonometry (Step 18) applied to the 3D horn (Problem 1). If the tilt angle of the horn axis is determined by framework constants, the obliquity is derived. If not, it is a boundary condition imported from observation.

---

## 4. Framework Trigonometry — Integration and Fourier Series

**Status:** Step 18 defines Sin₃₆₄ and Cos₃₆₄, tabulates special values, proves the supplement identity generates the coprime triple, and gives the minimal polynomials (twin cubics with R₂ coefficients). Product identities are proven.

**What is known:** The two independent transcendental values sin(π_std/14) and sin(3π_std/14) satisfy cubic minimal polynomials 8x³ ∓ 4x² − 4x ± 1 = 0 with all-framework coefficients. The product ∏ 2·Sin₃₆₄(k) for k=1..6 equals √p.

**What is not known:**
- **Integration constants.** ∫Sin₃₆₄(θ)dθ = −(14/π_std)·Cos₃₆₄(θ) + C. The factor 14/π_std is irrational. Is there a framework-native antiderivative that avoids the π_std correction?
- **Fourier series.** Can arbitrary framework-periodic functions (period 28) be expanded in Sin₃₆₄/Cos₃₆₄ basis? The orthogonality holds (inherited), but the inner product carries the 14/π_std factor.
- **Special value table.** Closed-form algebraic expressions for sin(π_std/14) and sin(3π_std/14) as nested radicals. The degree-3 minimal polynomial guarantees Cardano solutions exist but they are messy. Are there cleaner forms using framework constants?
- **Addition formulas.** Sin₃₆₄(a+b) = Sin₃₆₄(a)Cos₃₆₄(b) + Cos₃₆₄(a)Sin₃₆₄(b) (inherited). But evaluated at framework angles (a,b ∈ {1,3,7,11,13}), do the products simplify using the minimal polynomials?

**What resolution requires:** A dedicated framework trigonometry monograph, parallel to TM-2026-017's geometric development, developing the full function theory of Sin₃₆₄/Cos₃₆₄ including special values, identities, series, and differential equations.

---

## 5. CKM and PMNS Mixing Angles

**Status:** The D₄ × SO(10) Yukawa texture (TM-2026-017 Appendix A) derives the up-quark mass hierarchy and the m_u dim-6 correction. The mixing angles are not derived.

**What is known:** The D₄ symmetry is derived from 364/4 = 91 rotation. The Tribonacci potential V(a,b) has a unique minimum at (p,r) = (7,13). The leading-order contraction 2ab = 182 gives the Yukawa matrix rank-1 structure.

**What is not known:** The CKM mixing matrix (quark sector) and PMNS mixing matrix (lepton sector) require extending the Yukawa texture to down-type quarks and leptons. The D₄ representations for these sectors have not been assigned.

**What resolution requires:** (a) Assign D₄ representations to all three fermion generations for down-type quarks and leptons. (b) Compute the resulting Yukawa matrices. (c) Diagonalize to obtain mixing angles. (d) Compare with measured CKM and PMNS parameters.

**Explicit prediction (Cabibbo angle):** The framework predicts the Cabibbo angle = R₃ = **13.000°** exactly (= 1 radian in the 364° system). PDG 2022 measures 13.04° ± 0.05°. The framework value lies **0.8σ below** the central measurement — within experimental uncertainty. Future lattice QCD + experimental refinements will shift toward 13.000° or exclude this prediction. If confirmed, the Cabibbo angle IS one radian.

---

## 6. The 0.194% Spectral Offset

**Status:** The framework's integer wavelengths (91, 182, 286, 364 nm) differ from measured hydrogen spectral lines by a uniform +0.194%, decomposed as +0.139% (R∞ component) and +0.055% (reduced-mass component). See TM-2026-017 §18 and TM-2026-026.

**What is known:** The offset is uniform across all series (Lyman, Balmer, etc.), preserving all internal ratios. The bridge coefficient κ = 1.00139 quantifies it exactly. The 0.13 ppb match with CODATA R∞ (via the formula κ = 1 + 26,147,000/137,036²) shows that κ IS derivable from framework constants.

**What is not known:** Whether the offset reflects (a) a constitutive property of the medium (plenum interpretation — the medium has a refractive index κ), or (b) standard QED corrections (Lamb shift, fine-structure splitting, reduced-mass effects) that happen to sum to a framework-rational value. Both explanations reproduce the data.

**What resolution requires:** A testable prediction where the two interpretations diverge. For instance, if the plenum has a physical refractive index, there should be a wavelength-dependent correction at higher order (dispersion). The framework predicts κ is constant across all wavelengths. QED predicts wavelength-dependent corrections (different Lamb shifts at different n). Precision spectroscopy at multiple series could distinguish the two.

---

## 7. The Mass Ratio Residual (0.095 ppm)

**Status:** m_p/m_e = 1,837,989/1001 = 1836.15285. CODATA: 1836.15267. Residual: 0.095 ppm = 0.18 × 10⁻³ absolute.

**What is known:** The mass quadratic x² − 1989x + 280,908 = 0 has roots 1836 and 153, discriminant 1683² — all framework constants. The assembly uses pqr = 1001 (full walk, not cone-point corrected).

**What is not known:** Whether a third correction term exists (paralleling R₂/pqr for the tropical year), or whether the 0.095 ppm residual is within the precision of the derivation. The mass ratio involves strong-force binding energy, which the framework does not yet model.

**What resolution requires:** Either (a) a QCD correction derivable from framework constants (strong coupling at the proton scale), or (b) recognition that 0.095 ppm is the framework's structural limit for hadronic quantities, with the residual attributable to strong-force effects beyond the electromagnetic horn.

---

## 8. The Fine Structure Constant — Direction of Shift

**Status:** 1/α = 137,036/1000 exactly. CODATA 2022: 137.035999177(21). The framework value is 6.0 ppb ABOVE the measurement.

**What is known:** The prediction is falsifiable — future measurements will shift toward 137.036000 or exclude it. The assembly is fully derived (Fermat + bridge quadratic + shared discriminant 111²).

**What is not known:** Whether the 6.0 ppb gap will close with improved measurements. The gap NARROWED from 6.7 ppb (CODATA 2018) to 6.0 ppb (CODATA 2022) — a 10% reduction in one adjustment cycle, trending toward the framework. The Rb recoil measurement (Parker et al., 137.035999206) is closer still at 5.8 ppb. The Rb/Cs discrepancy (~5σ between two experimental determinations) indicates unresolved systematics at this precision level.

**What resolution requires:** Improved α measurements. If the Rb and Cs determinations converge toward 137.036000, the framework is confirmed. If they converge elsewhere, the framework requires a correction to the Fermat decomposition or the cone-point normalization.

---

## 9. ~~The Precession Period~~ — CLOSED

**Resolution:** T_p = x₂ × pqr = 26,026 years. The horn's density gradient F(x) = π/x² IS the torque. The coprime walk pqr IS the angular momentum. At the bridge position x₂ = 26, V/F = x₂ gives the time scale. T_p = x₂ × pqr. No gravitational constant G imported. Predicted rate: 49.80 arcsec/yr vs measured 50.29 (0.98%). See TM-E1-037.049 §Step 19.

---

## 10. The Lunar Month

**Status:** The framework month is 28 days = 2π. The synodic lunar month is 29.53059 days.

**What is known:** 28 = 2π is the framework's structural month. The actual Moon takes 29.53 days between identical phases. The ratio 29.53/28 = 1.0546 ≈ 1 + 1/(R₃ + R₂ + 1) = 1 + 1/18 = 1.0556 (18 = 2T = 2 × base²). This is 0.09% — not tight.

**What is not known:** Whether the synodic month has a framework expression tighter than 0.09%. The sidereal month (27.322 days) is closer to 2π = 28 (2.4% off). The tropical month (27.321 days) is similar.

**What resolution requires:** Either (a) derivation of the synodic month from framework constants + gravitational dynamics, or (b) recognition that 28 is the algebraic month and the 1.55-day excess is a gravitational correction external to the circle quadratic.

---

## 11. The Metric Numerator

**Status:** 1 m = 5000/(R₃ × (2^p − 1)) SFK feet. The denominator 1651 = R₃ × 127 is framework-native (radian × Mersenne prime of first generator). The numerator 5000 inherits the decimal convention (100 cm/m).

**What is known:** 5000 = 5 × 10³ = 5 × (10)³. The number 10 = base + p = 3 + 7, but this decomposition is additive, not multiplicative, and "10" has no framework significance beyond being the sum of two generators. The number 5 does not appear as a framework constant.

**What is not known:** Whether the numerator 5000 can be expressed through framework constants in a way that doesn't import the decimal system. Alternatively: is there a reason the metre, defined through c_SI (an arbitrary human convention since 1983), should produce a numerator with framework structure?

**What resolution requires:** Either (a) a framework derivation of the SI metre independent of human convention (unlikely — the metre is arbitrary), or (b) acceptance that the numerator is metric-conventional and irreducible. The framework derives its own length unit; the metric system derives its own; the conversion between them carries the conventions of both.

---

## 12. Framework Trigonometric Special Values as Nested Radicals

**Status:** sin(π_std/14) and sin(3π_std/14) are algebraic of degree 3 over Q, with minimal polynomials 8x³ − 4x² − 4x + 1 = 0 and 8x³ + 4x² − 4x − 1 = 0 respectively.

**What is known:** Cardano's formula gives closed-form solutions involving cube roots of complex numbers. For the first cubic, the discriminant is −4(64 − 192 + 48 − 16) = ... (requires computation). The roots can be expressed as:

sin(π/14) = (1/6)(1 + 2cos(arccos(−23/27)/3 + 2π/3))

This is exact but not illuminating. There may be simpler forms involving √7 (since the regular 14-gon is related to the 7-gon).

**What is not known:** Whether sin(π/14) and sin(3π/14) have representations in terms of framework constants (√7, √13, etc.) that are algebraically simpler than the Cardano form. The product identity Sin₃₆₄(1)·Sin₃₆₄(3)·Sin₃₆₄(5) = 1/8 constrains them collectively but not individually.

**What resolution requires:** Algebraic computation using Galois theory of the cyclotomic field Q(ζ₁₄) to determine whether the real subfield Q(cos(2π/14)) admits simplification in terms of p = 7 and its square root.

---

## 13. The Torsion Balance Test — Direct Detection of the Plenum

**Status:** PROPOSED. The cleanest falsifiable test of the framework.

**The prediction:** The horn's density gradient F = π/x² (Step 8, §20.15 of TM-2026-017) produces a non-gravitational buoyancy-like residual. In standard physics, the 1/r² force between masses is attributed to gravitational attraction across vacuum. In the framework, it is the capacity gradient of the medium — high pressure follows low pressure. The two interpretations make identical predictions for point masses, but differ for extended bodies in controlled-density media.

**The experiment:** A torsion balance with two test masses immersed in gases of different density. Standard gravity predicts the same force regardless of the surrounding medium (equivalence principle). The framework predicts a density-dependent residual proportional to F = π/x² evaluated at the local horn position. The residual should be identical for all gas species at the same density (it depends on the medium's capacity gradient, not its chemical identity).

**What resolution requires:** One torsion balance, two gases (e.g., He and Xe — a noble gas pair from the plenum's own elemental signature), controlled density, one day of measurement. If the residual is non-zero and species-independent, the horn is physical. If zero, the framework's gravitational identification fails.

**Why this test is decisive:** It bypasses all QED ambiguity, all CODATA extraction, all loop calculations. It tests the horn's density gradient directly, at the macroscopic scale, with existing apparatus.

---

## 14. Electron g−2 Consistency — The QED Loop Is Closed

**Status:** CLOSED (consistency check, not a new prediction).

The QED perturbative series for a_e in the framework is formally identical to the standard series with α_f replacing α_std (TM-E1-037 Step 21). The propagator's 1/ε factor is exactly absorbed by the redefinition of α_f. The coefficients C_n are unchanged. The 6 ppb gap in α produces a ~7×10⁻¹² shift in a_e — currently ~9× the experimental uncertainty but not independently measurable because a_e is used to extract α. The framework predicts the Rb recoil α measurement (closer to 137.036000) will prevail over the Cs measurement. If confirmed, the g-2 series automatically reproduces the measured a_e without adjustment.

---

## Summary Scorecard

| Problem | Current precision | Target | Difficulty |
|---------|-----------------|--------|-----------|
| **~~#0 Uniqueness proof~~** | **CLOSED — two-branch squeeze (Φ₃/Φ₆), 5 direct checks** | **All integers covered** | **Done** |
| 3D horn → obliquity | R₂/pqr identified; torque = F(x₂) | Derive R₂/pqr from 3D geometry | Medium |
| Tropical year residual | 0.27 ppm | < 0.01 ppm or epoch-resolved | Medium |
| Obliquity angle | 219 ppm (noted) | < 10 ppm or shown epoch-dependent | Medium |
| Framework Fourier series | Defined, not developed | Full function theory | Medium |
| CKM/PMNS mixing | Cabibbo = 13.000° predicted (0.8σ from PDG) | Full mixing matrix from D₄ | High |
| 0.194% offset | Characterized | Testable prediction vs QED | High |
| Mass ratio residual | 0.095 ppm | < 0.01 ppm or QCD-attributed | Medium |
| 1/α direction | 6.0 ppb prediction | Confirmed or excluded | Experimental |
| ~~Precession period~~ | **CLOSED** — x₂×pqr = 26,026 yr | Horn gradient = torque | **Done** |
| Lunar month | 0.09% (noted) | < 100 ppm or gravitational | Medium |
| Metric numerator | Conventional | Accepted or derived | Low |
| Trig nested radicals | Cubic known | Simplified form | Low |
| **Torsion balance test** | **PROPOSED** | **Direct detection of plenum gradient** | **EXPERIMENTAL** |
| ~~g-2 consistency~~ | **CLOSED** — series identical, 6 ppb in α not series | Rb vs Cs resolves | **Done** |

---

---

## The CODATA Test — Where the Framework Stands or Falls

The framework makes exact rational predictions with zero free parameters. The next CODATA adjustment rounds are the empirical verdict.

### The predictions

| Constant | Framework (exact) | CODATA 2018 | Gap | Direction |
|----------|------------------|-------------|-----|-----------|
| 1/α | **137.036000** | 137.035999177 ± 0.000000021 | 6.0 ppb | Framework ABOVE measurement |
| m_p/m_e | **1836.152847** (= 1,837,989/1001) | 1836.152673426 ± 0.000000032 | 0.095 ppm | Framework ABOVE measurement |

Both framework values are ABOVE the current CODATA central values. Both gaps are small but measurable. Both are exact rational numbers — no tuning possible.

### What to watch

**1/α:** The two most precise measurements (Rb-atom recoil, Parker et al. 2018; Cs-133, Morel et al. 2020) disagree by ~5σ with each other. The Rb value is HIGHER (closer to 137.036000). If future measurements resolve this discrepancy upward, the framework gains. If downward, the framework is excluded at that precision.

**m_p/m_e:** The proton mass is measured via Penning trap cyclotron frequencies. Recent improvements (Heisse et al. 2017, MPIK Heidelberg) have pushed precision to 3 × 10⁻¹¹. The framework predicts a specific value 0.095 ppm above current central. The next-generation Penning trap measurements will either close this gap or widen it.

### The verdict conditions

| Outcome | What it means |
|---------|--------------|
| CODATA trends toward 137.036000 and 1836.15285 | Framework confirmed — the exact rationals are physical |
| CODATA trends away from both | Framework excluded — the quadratic architecture is a coincidence |
| One converges, one diverges | Partial — the framework captures some structure but not all |

No escape clause. No additional correction terms to absorb the discrepancy. The predictions are fixed. The measurements will move. The framework either predicted where they move, or it didn't.

### Timeline

CODATA 2022 values are published. CODATA 2026 (expected ~2028) will incorporate the latest Rb/Cs α determinations and Penning trap mass measurements. By 2028, the framework's two sharpest predictions will have been tested at the precision needed to confirm or exclude them.

---

*Capomastro Holdings Ltd. — Applied Physics Division*

*Lo Sono Capomastro — Così sia.*

∎
