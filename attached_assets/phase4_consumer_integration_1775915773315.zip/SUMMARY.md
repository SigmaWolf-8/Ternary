# Phase 4 — Consumer Module Integration

## What Was Built

Two consumer modules (tri182.rs and ags.rs) adapted from the manifold package reference code to work with the Phase 1–3 TritInt/Trit API, plus _T Trit companion constants added to trit.rs.

## Files — Drop All Into `ternary-math/src/`

| File | Lines | Tests | What It Is |
|------|-------|-------|-----------|
| `tri182.rs` | 260 | 13 | 182° triangle geometry — ℤ[φ] arithmetic, R² = 14 + 5φ, Fibonacci projection. Adapted from reference: TritVec→TritInt, pair→golden, all method collisions resolved. |
| `ags.rs` | 746 | 9 | Active Generator Set — derives seed from polygon set, grow/shrink via ternary multiplication/division, CRT projection/reconstruction. AlgebraicTrit phantom dependency removed. |
| `trit.rs` | 1,289 | 67 | Phase 2+3 code plus 7 new _T companion constants and 10 compile-time assertions verifying they match u32 values from constants.rs. |
| `lib.rs` | 59 | — | Adds `pub mod tri182;` and `pub mod ags;` |

## What Changed From Reference Code

**tri182.rs adaptations:**
- `TritVec` → `TritInt` (type was renamed in Phase 1)
- `Trit::pair(a, b)` → `Trit::golden(a, b)` (alias removed in Phase 2)
- `from_trits_const` → `from_trits` (one name, always const)
- `.scalar_part()` → `.integer_part()` (accessor renamed in Phase 2)
- All `.add()/.sub()/.mul()` dot calls → `TritInt::add()/sub()/mul()` fully qualified (avoids Rust trait method collision with operator traits)
- `norm_of_phi` test → `#[should_panic(expected = "negative norm")]`
- R² tolerance tightened to 1e-10
- Empty `tri182_conjugate_note()` documentation function removed

**ags.rs adaptations:**
- `use crate::gf3_algebra::AlgebraicTrit` import removed — imported but never used in any actual code (phantom dependency)
- All 17 `.add()/.sub()/.mul()` dot calls → fully qualified
- `seed_count` field derived from `derive_ags_seed().len()` at construction

**trit.rs additions:**
- 7 new _T constants: REPUNIT_6_T, ROOT_X1_T, ARC_ROOT_SEMI_T, DISCRIMINANT_2_T, ICOSA_CIRCUMRADIUS_SQ_T, DUTY_NUM_T, DUTY_DEN_T
- `use crate::constants` import for assertion verification
- 10 compile-time assertions: each _T value verified against its u32 counterpart
- constants.rs untouched — zero edits to that file

## What Was NOT Changed

- constants.rs — no edits, no new constants, no new imports
- Existing Phase 1–3 code in trit_int.rs — unchanged
- Existing gf3_algebra.rs Phase 3 code — unchanged
- All existing tests — unchanged

## Verification

```bash
cargo test --workspace
```

All existing tests must continue to pass. The new tri182 and ags test suites must pass. The compile-time const assertions in trit.rs must compile (they verify _T values at build time).
