// Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
// Patent(s) Pending — All Rights Reserved — Applied Physics Division
//
// TM-2026-030 v2: Coprime Periodic Transform Engine
// ternary-math/src/cpd.rs
//
// Integrates into TTC as ChunkMode::CptAns (4) and ChunkMode::CptLz77Ans (5).
// No new user-facing API. Existing ttc_compress / ttc_decompress use CPT
// automatically when it produces smaller output than LZ77 modes.
//
// Geometric basis (constants.rs §4 squared circle ties):
//   UNIT_CIRCLE_AREA     = π = 14 = 2 × COPRIME_TRIPLES[0][0]
//   RADIAN_CIRCLE_AREA   = 182 = COPRIME_PAIR_LCMS[6] = SQUARED_SIDE_SQ_RADIAN
//   The CPT moduli are polygon central-angle periods whose composites
//   are geometric-area strides. The transform decomposes the signal
//   into polygon-frequency components.

//! # CPT — Coprime Periodic Transform
//!
//! Additive ANOVA on T(m₁,...,mₖ) using pairwise-coprime moduli selected
//! from the canonical arrays in `ternary_math::constants`. Marginal means
//! (u8) + residual (i16). Lossless. See TM-2026-030 v2 for full spec.
//!
//! ## Probe algorithm
//!
//! 1. Compute autocorrelation at 10 member strides {3,4,5,7,8,9,11,13,14,15}
//! 2. Score each of 18 canonical groups (7 triples + 2 quads + 5 quints + 4 sexts)
//!    by minimum AC across members
//! 3. Select group with best (score / header_cost), subject to CCP bridge budget
//! 4. Coprimality guaranteed by compile-time assertions — zero runtime gcd checks

use crate::constants::{
    COPRIME_PAIRS, COPRIME_PAIR_LCMS,
    COPRIME_TRIPLES, COPRIME_TRIPLE_LCMS,
    COPRIME_QUADRUPLES, COPRIME_QUADRUPLE_LCMS,
    COPRIME_QUINTUPLES, COPRIME_QUINTUPLE_LCMS,
    COPRIME_SEXTUPLES, COPRIME_SEXTUPLE_LCMS,
    DEFICIT_RATE_DEN,
};

// ═══════════════════════════════════════════════════════════════
// §1  PROBE — selects decomposition group from canonical arrays
// ═══════════════════════════════════════════════════════════════

/// CPT analysis result. Stored in Phase1Result.
#[derive(Debug, Clone)]
pub struct CpdAnalysis {
    /// Moduli from a canonical array group, sorted ascending.
    /// Empty = CPT not attempted.
    pub moduli: Vec<u32>,
    /// Header cost: 2 + Σ moduli.
    pub header_bytes: usize,
    /// Source group (for diagnostics / logging).
    pub group_source: GroupSource,
}

/// Identifies which canonical array the selected group came from.
#[derive(Debug, Clone, Copy)]
pub enum GroupSource {
    None,
    Triple(usize),
    Quadruple(usize),
    Quintuple(usize),
    Sextuple(usize),
    Detected(u32),
}

/// The 10 distinct member values across all canonical coprime groups.
const MEMBER_STRIDES: [u32; 10] = [3, 4, 5, 7, 8, 9, 11, 13, 14, 15];

/// Minimum autocorrelation for canonical groups.
const AC_FLOOR: f64 = 0.15;

/// Minimum autocorrelation for non-canonical small periods.
const AC_STRONG: f64 = 0.40;

/// Byte-match autocorrelation at lag m. O(N).
fn autocorrelation(data: &[u8], m: usize) -> f64 {
    if m == 0 || m >= data.len() { return 0.0; }
    let mut hits = 0u64;
    for i in m..data.len() { hits += (data[i] == data[i - m]) as u64; }
    hits as f64 / (data.len() - m) as f64
}

/// Score a candidate group: minimum AC across its members.
///
/// Rationale: CPT captures structure at ALL member strides simultaneously.
/// If any member has low AC, its marginal is near-flat, contributing nothing.
/// The weakest link limits the compression benefit.
fn group_score(members: &[u32], ac_table: &[(u32, f64)]) -> f64 {
    let mut min_ac = f64::MAX;
    for &m in members {
        let ac = ac_table.iter()
            .find(|&&(s, _)| s == m)
            .map(|&(_, a)| a)
            .unwrap_or(0.0);
        if ac < min_ac { min_ac = ac; }
    }
    if min_ac == f64::MAX { 0.0 } else { min_ac }
}

/// Header cost for a group: 1 (factor count) + 1 (grand mean) + Σ moduli.
fn hdr(members: &[u32]) -> usize {
    2 + members.iter().map(|&m| m as usize).sum::<usize>()
}

/// Probe a chunk for coprime-periodic structure.
///
/// Budget = chunk.len() / DEFICIT_RATE_DEN (integer floor division).
/// Selects from the 18 canonical groups in COPRIME_TRIPLES through
/// COPRIME_SEXTUPLES. Coprimality is compile-time verified.
pub fn probe(chunk: &[u8]) -> CpdAnalysis {
    let none = CpdAnalysis { moduli: vec![], header_bytes: 0, group_source: GroupSource::None };

    if chunk.len() < DEFICIT_RATE_DEN as usize {
        return none;
    }

    let sample = &chunk[..chunk.len().min(4096)];
    let budget = chunk.len() / DEFICIT_RATE_DEN as usize; // floor division

    // ── AC at each member stride (10 tests) ──
    let ac_table: Vec<(u32, f64)> = MEMBER_STRIDES.iter()
        .filter(|&&m| (m as usize) < sample.len())
        .map(|&m| (m, autocorrelation(sample, m as usize)))
        .collect();

    // ── Score every canonical group ──

    struct Candidate {
        moduli: Vec<u32>,
        header: usize,
        score: f64,
        source: GroupSource,
    }

    let mut candidates: Vec<Candidate> = Vec::with_capacity(18);

    // Triples (7)
    for (i, triple) in COPRIME_TRIPLES.iter().enumerate() {
        let h = hdr(triple);
        if h > budget { continue; }
        let s = group_score(triple, &ac_table);
        if s >= AC_FLOOR {
            candidates.push(Candidate { moduli: triple.to_vec(), header: h, score: s, source: GroupSource::Triple(i) });
        }
    }

    // Quadruples (2)
    for (i, quad) in COPRIME_QUADRUPLES.iter().enumerate() {
        let h = hdr(quad);
        if h > budget { continue; }
        let s = group_score(quad, &ac_table);
        if s >= AC_FLOOR {
            candidates.push(Candidate { moduli: quad.to_vec(), header: h, score: s, source: GroupSource::Quadruple(i) });
        }
    }

    // Quintuples (5)
    for (i, quint) in COPRIME_QUINTUPLES.iter().enumerate() {
        let h = hdr(quint);
        if h > budget { continue; }
        let s = group_score(quint, &ac_table);
        if s >= AC_FLOOR {
            candidates.push(Candidate { moduli: quint.to_vec(), header: h, score: s, source: GroupSource::Quintuple(i) });
        }
    }

    // Sextuples (4)
    for (i, sext) in COPRIME_SEXTUPLES.iter().enumerate() {
        let h = hdr(sext);
        if h > budget { continue; }
        let s = group_score(sext, &ac_table);
        if s >= AC_FLOOR {
            candidates.push(Candidate { moduli: sext.to_vec(), header: h, score: s, source: GroupSource::Sextuple(i) });
        }
    }

    // ── Non-canonical small periods (AC > 0.40) ──
    for p in (2u32..=128).filter(|p| !MEMBER_STRIDES.contains(p)) {
        if (p as usize) >= sample.len() { break; }
        let ac = autocorrelation(sample, p as usize);
        if ac > AC_STRONG {
            if let Some(factors) = factorize_to_members(p) {
                let h = hdr(&factors);
                if h <= budget {
                    candidates.push(Candidate { moduli: factors, header: h, score: ac, source: GroupSource::Detected(p) });
                }
            }
        }
    }

    // ── Select best: max(score / header_cost) ──
    if let Some(best) = candidates.iter().max_by(|a, b| {
        let ra = a.score / a.header as f64;
        let rb = b.score / b.header as f64;
        ra.partial_cmp(&rb).unwrap_or(std::cmp::Ordering::Equal)
    }) {
        let mut moduli = best.moduli.clone();
        moduli.sort();
        return CpdAnalysis { moduli, header_bytes: best.header, group_source: best.source };
    }

    // ── Fallback: speculative primary triple ──
    if budget >= 33 {
        return CpdAnalysis { moduli: vec![7, 11, 13], header_bytes: 33, group_source: GroupSource::Triple(0) };
    }

    none
}

/// Factor a detected period into two coprime members.
/// Only two-factor splits are attempted; three-factor would require
/// a separate pass and is left for future enhancement.
/// Output is sorted ascending.
fn factorize_to_members(p: u32) -> Option<Vec<u32>> {
    for &a in &MEMBER_STRIDES {
        if p > a && p % a == 0 {
            let b = p / a;
            if b > 1 && gcd(a, b) == 1 && b <= 128 {
                let mut factors = vec![a, b];
                factors.sort();
                return Some(factors);
            }
        }
    }
    None
}

fn gcd(mut a: u32, mut b: u32) -> u32 {
    while b != 0 { let t = b; b = a % b; a = t; } a
}

// ═══════════════════════════════════════════════════════════════
// §2  FORWARD TRANSFORM
// ═══════════════════════════════════════════════════════════════

/// Compute marginal means from u8 data. Each value rounded to nearest u8.
fn compute_marginals(data: &[u8], moduli: &[u32], gm: u8) -> Vec<Vec<u8>> {
    moduli.iter().map(|&m| {
        let mu = m as usize;
        let mut sums = vec![0u64; mu];
        let mut counts = vec![0u32; mu];
        for (i, &b) in data.iter().enumerate() {
            sums[i % mu] += b as u64;
            counts[i % mu] += 1;
        }
        (0..mu).map(|j| {
            if counts[j] > 0 { (sums[j] as f64 / counts[j] as f64).round().clamp(0.0, 255.0) as u8 }
            else { gm }
        }).collect()
    }).collect()
}

/// Grand mean: round(Σd[i] / N), clamped to u8.
fn grand_mean(data: &[u8]) -> u8 {
    let sum: u64 = data.iter().map(|&b| b as u64).sum();
    (sum as f64 / data.len().max(1) as f64).round().clamp(0.0, 255.0) as u8
}

/// Integer prediction from u8 marginals and u8 grand mean.
/// d̂ = Σⱼ μⱼ[i mod mⱼ] − (k−1)·μ, clamped to [0, 255].
/// All arithmetic is i32 → clamp → i16. Bit-exact on encoder and decoder.
#[inline]
fn predict(i: usize, moduli: &[u32], marginals: &[Vec<u8>], k: usize, gm: u8) -> i16 {
    let mut p: i32 = 0;
    for (j, &m) in moduli.iter().enumerate() {
        p += marginals[j][i % m as usize] as i32;
    }
    p -= (k as i32 - 1) * gm as i32;
    p.clamp(0, 255) as i16
}

/// Mode 4 (CptAns): CPT transform + zigzag-varint residual.
/// Returns complete chunk payload (4-byte size + 1-byte mode + CPT data).
///
/// Residual r[i] = d[i] − pred[i] ∈ [-255, 255]. Lossless.
pub fn encode_chunk(data: &[u8], moduli: &[u32]) -> Vec<u8> {
    let n = data.len();
    let k = moduli.len();
    let gm = grand_mean(data);
    let marginals = compute_marginals(data, moduli, gm);

    let header_sz = 4 + 1 + 1 + k + 1 + marginals.iter().map(|m| m.len()).sum::<usize>();
    let mut out = Vec::with_capacity(header_sz + n * 2);

    // Chunk envelope
    out.extend_from_slice(&(n as u32).to_be_bytes());
    out.push(0x04); // CptAns

    // CPT header
    out.push(k as u8);
    for &m in moduli { out.push(m as u8); }
    out.push(gm);
    for mg in &marginals { out.extend_from_slice(mg); }

    // Residual: zigzag varint (lossless, handles full [-255, 255] range)
    for (i, &b) in data.iter().enumerate() {
        let pred = predict(i, moduli, &marginals, k, gm);
        let r = b as i16 - pred;
        let zz = ((r << 1) ^ (r >> 15)) as u16;
        encode_varint_u16(&mut out, zz);
    }
    out
}

/// Mode 5 (CptLz77Ans): CPT header + residual bytes for LZ77.
///
/// Returns `(cpd_header, residual_bytes, fits_u8)`.
///
/// `fits_u8` is true iff ALL residuals are in [-128, 127].
/// **Caller MUST check fits_u8.** If false, do NOT produce a Mode 5
/// candidate — use Mode 4 instead. This is the overflow guard
/// (TM-2026-030 v2 §6.2, review issue #6).
pub fn encode_for_lz77(data: &[u8], moduli: &[u32]) -> (Vec<u8>, Vec<u8>, bool) {
    let n = data.len();
    let k = moduli.len();
    let gm = grand_mean(data);
    let marginals = compute_marginals(data, moduli, gm);

    // CPT header (shared with decode path)
    let mut hdr = Vec::with_capacity(1 + k + 1 + marginals.iter().map(|m| m.len()).sum::<usize>());
    hdr.push(k as u8);
    for &m in moduli { hdr.push(m as u8); }
    hdr.push(gm);
    for mg in &marginals { hdr.extend_from_slice(mg); }

    // Residual as u8 (r + 128) + overflow detection
    let mut res = Vec::with_capacity(n);
    let mut fits = true;
    for (i, &b) in data.iter().enumerate() {
        let pred = predict(i, moduli, &marginals, k, gm);
        let r = b as i16 - pred;
        if r < -128 || r > 127 { fits = false; }
        res.push((r + 128).clamp(0, 255) as u8);
    }

    (hdr, res, fits)
}

// ═══════════════════════════════════════════════════════════════
// §3  INVERSE TRANSFORM
// ═══════════════════════════════════════════════════════════════

/// Parse CPT header from byte slice.
/// Returns (moduli, marginals, grand_mean, bytes_consumed).
fn parse_header(data: &[u8]) -> Result<(Vec<u32>, Vec<Vec<u8>>, u8, usize), String> {
    if data.is_empty() { return Err("CPT payload empty".into()); }
    let mut p = 0;
    let k = data[p] as usize; p += 1;
    if k == 0 || p + k >= data.len() { return Err(format!("CPT: invalid factor count {}", k)); }
    let moduli: Vec<u32> = data[p..p + k].iter().map(|&b| b as u32).collect(); p += k;
    if p >= data.len() { return Err("CPT: truncated at grand mean".into()); }
    let gm = data[p]; p += 1;
    let mut marginals: Vec<Vec<u8>> = Vec::with_capacity(k);
    for &m in &moduli {
        let m = m as usize;
        if p + m > data.len() { return Err(format!("CPT: truncated at marginal len {}", m)); }
        marginals.push(data[p..p + m].to_vec()); p += m;
    }
    Ok((moduli, marginals, gm, p))
}

/// Decode Mode 4 (CptAns). Input = payload after the 5-byte chunk envelope.
pub fn decode_chunk(payload: &[u8], original_size: usize) -> Result<Vec<u8>, String> {
    let (moduli, marginals, gm, mut pos) = parse_header(payload)?;
    let k = moduli.len();
    let mut out = Vec::with_capacity(original_size);

    for i in 0..original_size {
        let (zz, br) = if pos < payload.len() { decode_varint_u16(&payload[pos..]) } else { (0, 0) };
        pos += br;
        let r = ((zz >> 1) as i16) ^ -((zz & 1) as i16);
        let pred = predict(i, &moduli, &marginals, k, gm);
        out.push((pred + r).clamp(0, 255) as u8);
    }
    Ok(out)
}

/// Decode Mode 5 (CptLz77Ans). Reconstruct from CPT header + LZ77-decoded residual.
/// Residual bytes are (r + 128) as u8. Decoder subtracts 128.
pub fn decode_from_residual(cpd_header: &[u8], residual: &[u8]) -> Result<Vec<u8>, String> {
    let (moduli, marginals, gm, _) = parse_header(cpd_header)?;
    let k = moduli.len();
    let mut out = Vec::with_capacity(residual.len());

    for (i, &rb) in residual.iter().enumerate() {
        let r = rb as i16 - 128;
        let pred = predict(i, &moduli, &marginals, k, gm);
        out.push((pred + r).clamp(0, 255) as u8);
    }
    Ok(out)
}

// ═══════════════════════════════════════════════════════════════
// §4  VARINT (base-128, LSB-first, per TM-2026-030 v2 §7.1)
// ═══════════════════════════════════════════════════════════════

#[inline]
fn encode_varint_u16(out: &mut Vec<u8>, mut v: u16) {
    loop {
        let mut b = (v & 0x7F) as u8;
        v >>= 7;
        if v > 0 { b |= 0x80; }
        out.push(b);
        if v == 0 { break; }
    }
}

#[inline]
fn decode_varint_u16(data: &[u8]) -> (u16, usize) {
    let (mut r, mut s) = (0u16, 0u32);
    for (i, &b) in data.iter().enumerate() {
        r |= ((b & 0x7F) as u16) << s;
        s += 7;
        if b & 0x80 == 0 || s >= 16 { return (r, i + 1); }
    }
    (r, data.len())
}

// ═══════════════════════════════════════════════════════════════
// §5  WIRING INTO ttc.rs — five patches, each ≤ 10 lines
// ═══════════════════════════════════════════════════════════════

/*
PATCH 1 — ChunkMode enum
    CptAns = 4,
    CptLz77Ans = 5,
    from_u8: 4 => Ok(Self::CptAns), 5 => Ok(Self::CptLz77Ans),

PATCH 2 — Phase1Result
    Add field: cpd: cpd::CpdAnalysis,
    In phase1_analyze(): let cpd_analysis = cpd::probe(chunk);

PATCH 3 — phase2_compress (add CPT candidates to existing list)
    if !p1.cpd.moduli.is_empty() {
        candidates.push((ChunkMode::CptAns, cpd::encode_chunk(chunk, &p1.cpd.moduli)));
        let (hdr, res, fits) = cpd::encode_for_lz77(chunk, &p1.cpd.moduli);
        if fits {
            let res_tokens = tokenize_chunk(&res, 0, cfg, ChunkMode::TernaryAns);
            let res_ser = serialize_tans(&res_tokens, cfg.window_size);
            let mut combined = Vec::with_capacity(4+1+2+hdr.len()+res_ser.len());
            combined.extend_from_slice(&(chunk.len() as u32).to_be_bytes());
            combined.push(0x05);
            combined.extend_from_slice(&(hdr.len() as u16).to_be_bytes());
            combined.extend_from_slice(&hdr);
            combined.extend_from_slice(&res_ser);
            candidates.push((ChunkMode::CptLz77Ans, combined));
        }
    }

PATCH 4 — Decompression dispatch
    ChunkMode::CptAns => cpd::decode_chunk(cp, orig_size)
        .map_err(|e| TtcError::DecompressionError(e))?,
    ChunkMode::CptLz77Ans => {
        let hl = u16::from_be_bytes([cp[0], cp[1]]) as usize;
        let hdr = &cp[2..2+hl];
        let lz = &cp[2+hl..];
        let toks = deserialize_tans(lz, ws)?;
        let res = decompress_tokens(&toks, &[]);
        cpd::decode_from_residual(hdr, &res)
            .map_err(|e| TtcError::DecompressionError(e))?
    },

PATCH 5 — No version bump. Modes 4/5 coexist with 0-3 in the same container.
*/

// ═══════════════════════════════════════════════════════════════
// §6  TESTS
// ═══════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use crate::constants::*;

    // ── Mode 4 round-trip ──

    #[test] fn rt_constant() {
        let d = vec![42u8; 2048];
        let p = encode_chunk(&d, &[7, 11, 13]);
        assert_eq!(d, decode_chunk(&p[5..], d.len()).unwrap());
    }

    #[test] fn rt_ramp() {
        let d: Vec<u8> = (0..4096).map(|i| (i % 256) as u8).collect();
        let p = encode_chunk(&d, &[7, 11, 13]);
        assert_eq!(d, decode_chunk(&p[5..], d.len()).unwrap());
    }

    #[test] fn rt_periodic_stride_11() {
        let pat: Vec<u8> = (0..11).map(|i| (i * 23 + 7) as u8).collect();
        let d: Vec<u8> = pat.iter().cycle().take(2200).cloned().collect();
        let p = encode_chunk(&d, &[7, 11, 13]);
        assert_eq!(d, decode_chunk(&p[5..], d.len()).unwrap());
    }

    #[test] fn rt_two_factors() {
        let d: Vec<u8> = (0..1540).map(|i| ((i * 3 + i / 7 * 5) % 256) as u8).collect();
        let p = encode_chunk(&d, &[7, 11]);
        assert_eq!(d, decode_chunk(&p[5..], d.len()).unwrap());
    }

    #[test] fn rt_sextuple() {
        let d: Vec<u8> = (0..8192).map(|i| (i % 256) as u8).collect();
        let p = encode_chunk(&d, &[5, 7, 8, 9, 11, 13]);
        assert_eq!(d, decode_chunk(&p[5..], d.len()).unwrap());
    }

    // ── Mode 5 round-trip + overflow guard ──

    #[test] fn rt_lz77_cascade() {
        let d: Vec<u8> = (0..2048).map(|i| ((i * 7 + 13) % 256) as u8).collect();
        let (hdr, res, fits) = encode_for_lz77(&d, &[7, 11, 13]);
        if fits {
            assert_eq!(d, decode_from_residual(&hdr, &res).unwrap());
        }
        // Mode 4 always works regardless of fits
        let p = encode_chunk(&d, &[7, 11, 13]);
        assert_eq!(d, decode_chunk(&p[5..], d.len()).unwrap());
    }

    #[test] fn mode5_overflow_detected() {
        // Extreme: mod-7 spikes produce large residuals
        let mut d = vec![0u8; 1024];
        for i in 0..1024 { d[i] = if i % 7 == 0 { 255 } else { 0 }; }
        let (_, _, fits) = encode_for_lz77(&d, &[7, 11, 13]);
        // Whether fits is true or false depends on prediction quality.
        // Either way, Mode 4 must round-trip:
        let p = encode_chunk(&d, &[7, 11, 13]);
        assert_eq!(d, decode_chunk(&p[5..], d.len()).unwrap());
    }

    // ── Worked example (TM-2026-030 v2 §9) ──

    #[test] fn worked_example() {
        let d: Vec<u8> = vec![10, 20, 30, 10, 20, 30, 10, 20];
        let moduli = vec![2u32, 3];
        let gm = grand_mean(&d);
        assert_eq!(gm, 19);

        let marginals = compute_marginals(&d, &moduli, gm);
        assert_eq!(marginals[0], vec![18, 20]);
        assert_eq!(marginals[1], vec![10, 20, 30]);

        let expected_pred: [i16; 8] = [9, 21, 29, 11, 19, 31, 9, 21];
        for (i, &ep) in expected_pred.iter().enumerate() {
            assert_eq!(predict(i, &moduli, &marginals, 2, gm), ep, "pred[{}]", i);
        }

        let expected_r: [i16; 8] = [1, -1, 1, -1, 1, -1, 1, -1];
        for (i, &er) in expected_r.iter().enumerate() {
            let pred = predict(i, &moduli, &marginals, 2, gm);
            assert_eq!(d[i] as i16 - pred, er, "r[{}]", i);
        }

        let payload = encode_chunk(&d, &moduli);
        assert_eq!(d, decode_chunk(&payload[5..], d.len()).unwrap());
    }

    // ── Probe: canonical array selection ──

    #[test] fn probe_selects_canonical_group() {
        let mut d = vec![0u8; 5000];
        for i in 0..5000 { d[i] = (i % 7 * 30) as u8; }
        let a = probe(&d);
        assert!(!a.moduli.is_empty());
        assert!(a.moduli.contains(&7), "Should contain modulus 7");
    }

    #[test] fn probe_selects_triple_for_structured_data() {
        let mut d = vec![128u8; 5000];
        for i in 0..5000 {
            d[i] = (128i16 + (i % 7) as i16 * 10 + (i % 11) as i16 * 5 + (i % 13) as i16 * 3)
                .clamp(0, 255) as u8;
        }
        let a = probe(&d);
        assert!(a.moduli.len() >= 3, "Should select at least a triple");
    }

    #[test] fn probe_tiny_returns_empty() {
        let a = probe(b"Hi!");
        assert!(a.moduli.is_empty(), "Tiny input must return empty moduli");
    }

    #[test] fn probe_small_chunk_returns_empty() {
        // 500-byte chunk: budget = 500/91 = 5. No group fits (smallest header = 20).
        let d: Vec<u8> = (0..500).map(|i| (i % 7 * 30) as u8).collect();
        let a = probe(&d);
        assert!(a.moduli.is_empty(), "500-byte chunk: no group should fit within budget 5");
    }

    #[test] fn probe_respects_budget() {
        for &sz in &[1000usize, 3000, 5000, 10000, 50000] {
            let d: Vec<u8> = (0..sz).map(|i| (i % 7 * 30) as u8).collect();
            let a = probe(&d);
            if !a.moduli.is_empty() {
                let budget = sz / DEFICIT_RATE_DEN as usize;
                assert!(a.header_bytes <= budget,
                    "Header {} exceeds budget {} at size {}", a.header_bytes, budget, sz);
            }
        }
    }

    // ── CCP bridge overhead bound ──

    #[test] fn ccp_bound() {
        let max = 1.0 / DEFICIT_RATE_DEN as f64;
        for &sz in &[200usize, 1_000, 10_000, 100_000] {
            let d: Vec<u8> = (0..sz).map(|i| ((i * 7 + 3) % 256) as u8).collect();
            let a = probe(&d);
            if !a.moduli.is_empty() {
                let rate = a.header_bytes as f64 / sz as f64;
                assert!(rate <= max, "Overhead {:.6} > 1/91 at size {}", rate, sz);
            }
        }
    }

    // ── Entropy reduction ──

    #[test] fn entropy_drops_on_periodic_data() {
        let pat: Vec<u8> = (0..13).map(|i| (i * 19 + 42) as u8).collect();
        let d: Vec<u8> = pat.iter().cycle().take(2600).cloned().collect();
        let h_in = h(&d);
        let (_, res, _) = encode_for_lz77(&d, &[7, 11, 13]);
        let h_res = h(&res);
        assert!(h_res < h_in, "Entropy must drop: {:.2} ≥ {:.2}", h_res, h_in);
    }

    fn h(data: &[u8]) -> f64 {
        let mut c = [0u64; 256];
        for &b in data { c[b as usize] += 1; }
        let n = data.len() as f64;
        c.iter().filter(|&&v| v > 0).map(|&v| { let p = v as f64 / n; -p * p.log2() }).sum()
    }

    // ── Squared circle ties ──

    #[test] fn squared_circle_ties() {
        assert_eq!(UNIT_CIRCLE_AREA, 2 * COPRIME_TRIPLES[0][0]);
        assert_eq!(RADIAN_CIRCLE_AREA, COPRIME_PAIR_LCMS[6]);
        assert_eq!(SQUARED_SIDE_SQ_RADIAN, COPRIME_PAIR_LCMS[6]);
        assert_eq!(RADIAN_CIRCLE_AREA, ARC_ROOT_SEMI);
    }

    // ── Group scoring semantics ──

    #[test] fn score_minimum_semantics() {
        let ac = vec![(7u32, 0.5), (11, 0.0), (13, 0.8)];
        assert_eq!(group_score(&[7, 11, 13], &ac), 0.0);
    }

    #[test] fn score_strong_triple() {
        let ac = vec![(7u32, 0.6), (11, 0.5), (13, 0.7)];
        let s = group_score(&[7, 11, 13], &ac);
        assert!((s - 0.5).abs() < 1e-10);
    }

    // ── factorize_to_members sorts output ──

    #[test] fn factorize_output_sorted() {
        if let Some(factors) = factorize_to_members(77) {
            assert_eq!(factors, factors.iter().copied().collect::<Vec<_>>());
            let mut sorted = factors.clone();
            sorted.sort();
            assert_eq!(factors, sorted, "Output must be sorted");
        }
    }
}
