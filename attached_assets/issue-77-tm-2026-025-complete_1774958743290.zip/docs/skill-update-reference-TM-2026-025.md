# Repo Guide Skill Update — TM-2026-025 v3

## Add to §15.1 as new §15.2

### 15.2 The (11, 13) Coprime Polygon Pair — TM-2026-025

The hendecagon (11) and tridecagon (13) inscribed in the 364° circle form a named structural element. Combined arc = 143° = 11 ternary radians.

**Generator Duality (Theorem 1.1):** 13 generates Z₂₈, 11 generates Z₃₆₄. 13 does NOT generate Z₃₆₄ (since 13 | 364). Verified in `generator_theorem_harness.rs`.

**CRT of 143:** Z₃₆₄ → (3, 3, 0). Z₇₅₆ → (8, 3) = (branch number, Rep C max).

**Combined vertices:** 23 = 11+13−1 = 11⁻¹ mod 28 = chi-optimal exponent = 143−φ(143).

**Inclusion-exclusion (Theorem 4.1):** For n=p×q distinct primes, n−φ(n)=p+q−1. So COMBINED_VERTICES = COPRIME_ARC − φ(COPRIME_ARC).

**Interleave:** [1,1,1,1,1,2,1,1,1,1,1] — palindromic, 11 entries, sum=12.

**PlenumColor harmonic system (§6.1–§6.3):** All five harmonic identifiers in `color.rs` derive from the (11, 13) pair:

| Harmonic | Value | Derivation | CRT Z₇₅₆ |
|----------|-------|------------|-----------|
| ARC_RED | 182 | 14 × 13 = πR₃ | (20, 14) |
| ARC_BLUE | 240 | 2 × φ(143) = 3⁵ − 3 | (T₈, 2⁴) |
| ARC_COPRIME | 286 | 2 × 143 = 2 × 11 × 13 | (16, 6) |
| √Δ_arc | 468 | RED + COPRIME = 36 × 13 | (9, 20) |
| ARC_GREEN | 650 | FULL_CIRCLE + COPRIME | (2, 6) |

**2× scaling pattern:** 2×143=286 (ARC_COPRIME), 2×φ(143)=240 (ARC_BLUE), 2×23=46 (gap between them).

Source: `shared/constants.ts` → `PLATFORM.COPRIME_POLYGON_PAIR`, `shared/agent-generators.ts` → `DUAL_GENERATOR_PAIR`, `src/kernel/src/distributor/coprime_polygon_pair.rs`, `src/kernel/src/browser/color.rs` → `ARC_COPRIME`, `ARC_SQRT_DISCRIMINANT`

---

## Add to §20 (Key Mathematical Identities)

```
11 × 13 = 143                    (coprime polygon arc = 11 ternary radians)
143 mod 27 = 8                   (branch number B(Mθ))
143 mod 28 = 3                   (Rep C maximum)
143 − φ(143) = 23               (combined vertices = non-units of Z₁₄₃)
240 = 2 × φ(143) = 3⁵ − 3       (ARC_BLUE; CRT Z₇₅₆ = (T₈, 2⁴))
286 = 2 × 143                   (ARC_COPRIME = Plenum Square gap)
286 − 240 = 46 = 2 × 23         (2× scaling of combined vertices)
468 = 182 + 286 = 36 × 13       (√Δ_arc = 36 radians)
650 = 364 + 286                  (ARC_GREEN = circle + coprime)
φ(364) − φ(143) = 24 = T₈       (totient gap = 240 mod 27)
11 × 6 − 13 × 5 = 1             (Bézout identity; 6 = φ(7) = 240 mod 13)
364/143 = [2; 1, 1, 5] → 28/11  (CF → Z₂₈/Z₃₆₄)
```
