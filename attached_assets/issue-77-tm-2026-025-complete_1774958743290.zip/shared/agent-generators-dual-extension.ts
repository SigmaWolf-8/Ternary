/**
 * Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
 * Patent(s) Pending — All Rights Reserved — Applied Physics Division
 *
 * Dual-Generator (11, 13) Extension — APPEND to shared/agent-generators.ts
 * Reference: TM-2026-025 v3
 */

/**
 * Z₃₆₄ canonical generator. gcd(11, 364) = 1.
 * 13 does NOT generate Z₃₆₄ (period = 28).
 * Formally verified: generator_theorem_harness.rs.
 */
export const Z364_CANONICAL_GENERATOR = 11;

/**
 * The (11, 13) dual-generator pair for Z₂₈ scheduling.
 *
 * Generator Duality: 13 → Z₂₈ (radian cycle), 11 → Z₃₆₄ (full circle).
 * Both are Z₂₈ generators (φ(28) = 12).
 * Inverses: 13⁻¹ = 13 (self-inverse), 11⁻¹ = 23.
 * Product: 11 × 13 = 143 = 11 ternary radians.
 * CRT(143) in Z₂₇ × Z₂₈ = (8, 3): branch number and Rep C max.
 */
export const DUAL_GENERATOR_PAIR = {
  primary: {
    stride: 13,
    role: 'radian_cycle' as const,
    group: 'Z28' as const,
    inverseStride: 13,
    generatesZ364: false,
  },
  secondary: {
    stride: 11,
    role: 'full_circle' as const,
    group: 'Z364' as const,
    inverseStride: 23,
    generatesZ364: true,
  },
  arc: 143,
  combinedVertices: 23,
  eulerTotient: 120,
  interleave: [1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1] as const,
  bezout: [6, -5] as const,
} as const;

/** Stride-11 coprime walk on Z₂₈ (secondary/redundant walk). */
export function getStride11Walk(): number[] {
  return Array.from({ length: 28 }, (_, k) => (11 * k) % 28);
}

/**
 * Dual-generator schedule: stride-13 + stride-11 with interleave handoff.
 * "1" entries = one primary step per secondary step.
 * "2" entry (center) = two primary steps per secondary step.
 */
export function getDualGeneratorSchedule(): {
  primaryWalk: number[];
  secondaryWalk: number[];
  interleave: readonly number[];
  combinedSchedule: Array<{ position: number; source: 'primary' | 'secondary' }>;
} {
  const primaryWalk = Array.from({ length: 28 }, (_, k) => (13 * k) % 28);
  const secondaryWalk = Array.from({ length: 28 }, (_, k) => (11 * k) % 28);
  const combined: Array<{ position: number; source: 'primary' | 'secondary' }> = [];
  const il = DUAL_GENERATOR_PAIR.interleave;
  let pi = 0, si = 0;

  for (let i = 0; i < il.length && si < 28; i++) {
    for (let j = 0; j < il[i] && pi < 28; j++) {
      combined.push({ position: primaryWalk[pi++], source: 'primary' });
    }
    if (si < 28) combined.push({ position: secondaryWalk[si++], source: 'secondary' });
  }
  while (pi < 28) combined.push({ position: primaryWalk[pi++], source: 'primary' });
  while (si < 28) combined.push({ position: secondaryWalk[si++], source: 'secondary' });

  return { primaryWalk, secondaryWalk, interleave: il, combinedSchedule: combined };
}
