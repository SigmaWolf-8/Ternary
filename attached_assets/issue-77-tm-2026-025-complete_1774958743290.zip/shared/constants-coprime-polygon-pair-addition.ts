/**
 * Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
 * Patent(s) Pending — All Rights Reserved — Applied Physics Division
 *
 * COPRIME_POLYGON_PAIR — Addition to PLATFORM object in shared/constants.ts
 * Reference: TM-2026-025 v3 — The (11, 13) Coprime Polygon Pair
 *
 * INSERT this block into the PLATFORM = { ... } object.
 */

  /**
   * (11, 13) Coprime Polygon Pair — TM-2026-025 v3
   *
   * Hendecagon (11) + tridecagon (13) inscribed in the 364° circle.
   * Combined arc = 143° = 11 ternary radians.
   * Generator Duality: 13 → Z₂₈, 11 → Z₃₆₄.
   *
   * PlenumColor harmonic system (all derived from this pair):
   *   ARC_RED   = 182 = 14 × 13 = πR₃
   *   ARC_BLUE  = 240 = 2 × φ(143) = 3⁵ − 3
   *   ARC_COPRIME = 286 = 2 × 143
   *   √Δ_arc    = 468 = ARC_RED + ARC_COPRIME = 36 × 13
   *   ARC_GREEN = 650 = FULL_CIRCLE + ARC_COPRIME
   */
  COPRIME_POLYGON_PAIR: {
    /** Combined arc = 11 × 13 = 143° = 11 ternary radians */
    ARC: 143,
    /** Hendecagon edge count — generates Z₃₆₄ */
    HENDECAGON_EDGES: 11,
    /** Tridecagon edge count — generates Z₂₈ */
    TRIDECAGON_EDGES: 13,
    /** Combined distinct vertices (11 + 13 − 1 shared).
     *  Also: 11⁻¹ mod 28, chi-optimal exponent, 143 − φ(143). */
    COMBINED_VERTICES: 23,
    /** φ(143) = φ(11)×φ(13) = 10×12. ARC_BLUE = 2 × EULER_TOTIENT. */
    EULER_TOTIENT: 120,
    /** Palindromic interleave: 11 entries summing to 12 = 13 − 1 */
    INTERLEAVE: [1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1] as const,
    /** 650 − 364 = 2 × 143. ARC_GREEN − FULL_CIRCLE in PlenumColor. */
    PLENUM_SQUARE_GAP: 286,
    /** √Δ = 468 = 36 × 13 = ARC_RED + PLENUM_SQUARE_GAP */
    SQRT_DISCRIMINANT: 468,
    /** Bézout: 11 × 6 − 13 × 5 = 1. Note: 6 = φ(7). */
    BEZOUT: [6, -5] as const,
    /** CRT in Z₃₆₄ ≅ Z₄ × Z₇ × Z₁₃ */
    CRT_364: [3, 3, 0] as const,
    /** CRT in Z₇₅₆ ≅ Z₂₇ × Z₂₈ */
    CRT_756: [8, 3] as const,
    /** CRT of ARC_BLUE (240) in Z₇₅₆: (T₈, 2⁴) */
    CRT_756_BLUE: [24, 16] as const,
    /** Arc in ternary radians (143 / 13 = 11) */
    TERNARY_RADIANS: 11,
    /** CF: 364/143 = [2; 1, 1, 5], final convergent = 28/11 */
    EUCLIDEAN_CONTINUED_FRACTION: [2, 1, 1, 5] as const,
  },
