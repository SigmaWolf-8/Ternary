// Copyright (c) 2025-2026 Capomastro Holdings Ltd. (Canada)
// Patent(s) Pending — All Rights Reserved — Applied Physics Division
//
// PlenumColor Harmonic Additions — src/kernel/src/browser/color.rs
// Reference: TM-2026-025 v3 §6.1–§6.3
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// UPDATE the header comment (around line 20) to read:
//
//   "Arc-derived Bézier interpolation: the red (182), blue (240),
//    coprime (286), and green (650) harmonic identifiers shape sub-cell
//    interpolation via arc_bezier_control(). All five values
//    {182, 240, 286, 468, 650} derive from the (11, 13) coprime polygon
//    pair and the unified arc equation arc² − 832·arc + 118,300 = 0.
//    See TM-2026-025 v3 for complete derivation."
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// EXISTING constants (already in color.rs — do not duplicate):
//
//   pub const ARC_RED:   u32 = 182;  // = 14 × 13 = πR₃
//   pub const ARC_GREEN: u32 = 650;  // = "rejected" root
//   pub const ARC_BLUE:  u32 = 240;
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ADD these constants alongside the existing ARC_* block:
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/// Coprime polygon harmonic: 286 = 2 × 143 = 2 × 11 × 13.
///
/// The (11, 13) coprime polygon pair's bridge between the Plenum Square roots.
/// ARC_GREEN = FULL_CIRCLE_DEG + ARC_COPRIME  (650 = 364 + 286)
/// ARC_RED   + ARC_COPRIME = √Δ_arc          (182 + 286 = 468)
///
/// Like ARC_RED/BLUE/GREEN, this is a harmonic identifier shaping Bézier
/// control points — not a literal angular measure. TM-2026-025 v3 §6.1.
pub const ARC_COPRIME: u32 = 286;

/// Discriminant root of arc² − 832·arc + 118,300 = 0.
/// √Δ = 468 = 36 × 13 = 36 ternary radians.
/// Roots: (832 ± 468) / 2 = {ARC_RED, ARC_GREEN} = {182, 650}.
pub const ARC_SQRT_DISCRIMINANT: u32 = 468;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// UPDATE the existing ARC_BLUE comment to document its derivation:
//
// CHANGE:
//   pub const ARC_BLUE:  u32 = 240;
// TO:
//   /// ARC_BLUE = 240 = 2 × φ(143) = 2 × φ(11 × 13) = 3⁵ − 3.
//   /// CRT in Z₇₅₆ ≅ Z₂₇ × Z₂₈: (24, 16) = (T₈, 2⁴).
//   /// CRT in Z₃₆₄ ≅ Z₄ × Z₇ × Z₁₃: (0, 2, 6) where 6 = φ(7).
//   /// ARC_COPRIME − ARC_BLUE = 46 = 2 × 23 = 2 × COMBINED_VERTICES.
//   /// TM-2026-025 v3 §6.1.
//   pub const ARC_BLUE:  u32 = 240;
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Tests — add to existing test module in color.rs
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

#[cfg(test)]
mod coprime_harmonic_tests {
    const ARC_RED: u32 = 182;
    const ARC_BLUE: u32 = 240;
    const ARC_GREEN: u32 = 650;
    const FULL_CIRCLE_DEG: u32 = 364;

    use super::{ARC_COPRIME, ARC_SQRT_DISCRIMINANT};

    // ── ARC_COPRIME relationships ─────────────────────────────────

    #[test] fn green_eq_circle_plus_coprime() {
        assert_eq!(FULL_CIRCLE_DEG + ARC_COPRIME, ARC_GREEN, "650 = 364 + 286");
    }
    #[test] fn red_plus_coprime_eq_sqrt_d() {
        assert_eq!(ARC_RED + ARC_COPRIME, ARC_SQRT_DISCRIMINANT, "182 + 286 = 468");
    }
    #[test] fn coprime_eq_double_143() {
        assert_eq!(ARC_COPRIME, 2 * 143, "286 = 2 × 143");
        assert_eq!(ARC_COPRIME, 2 * 11 * 13, "286 = 2 × 11 × 13");
    }

    // ── √Δ relationships ─────────────────────────────────────────

    #[test] fn sqrt_d_is_root_diff() {
        assert_eq!(ARC_GREEN - ARC_RED, ARC_SQRT_DISCRIMINANT, "650 − 182 = 468");
    }
    #[test] fn discriminant_identity() {
        assert_eq!(ARC_SQRT_DISCRIMINANT * ARC_SQRT_DISCRIMINANT, 219024);
        assert_eq!(832u32 * 832 - 4 * 118300, 219024);
    }
    #[test] fn roots_from_formula() {
        assert_eq!((832 - ARC_SQRT_DISCRIMINANT) / 2, ARC_RED);
        assert_eq!((832 + ARC_SQRT_DISCRIMINANT) / 2, ARC_GREEN);
    }
    #[test] fn sqrt_d_in_radians() {
        assert_eq!(ARC_SQRT_DISCRIMINANT, 36 * 13, "468 = 36 ternary radians");
    }

    // ── ARC_BLUE derivation ──────────────────────────────────────

    #[test] fn blue_eq_double_totient() {
        assert_eq!(ARC_BLUE, 2 * 120, "240 = 2 × φ(143)");
    }
    #[test] fn blue_eq_base3_structural() {
        assert_eq!(ARC_BLUE, 243 - 3, "240 = 3⁵ − 3");
        assert_eq!(ARC_BLUE, 3 * (81 - 1), "240 = 3(3⁴ − 1)");
    }
    #[test] fn coprime_minus_blue_eq_double_vertices() {
        assert_eq!(ARC_COPRIME - ARC_BLUE, 2 * 23, "286 − 240 = 46 = 2×23");
    }
    #[test] fn blue_crt_dual_circle() {
        assert_eq!(ARC_BLUE % 27, 24, "240 mod 27 = 24 = T₈");
        assert_eq!(ARC_BLUE % 28, 16, "240 mod 28 = 16 = 2⁴");
    }
    #[test] fn blue_crt_z13() {
        assert_eq!(ARC_BLUE % 13, 6, "240 mod 13 = 6 = φ(7) = Bézout[0]");
    }

    // ── 2× scaling pattern ───────────────────────────────────────

    #[test] fn scaling_pattern() {
        assert_eq!(2 * 143, ARC_COPRIME,            "2 × arc = ARC_COPRIME");
        assert_eq!(2 * 120, ARC_BLUE,                "2 × φ(arc) = ARC_BLUE");
        assert_eq!(2 * 23, ARC_COPRIME - ARC_BLUE,   "2 × vertices = gap");
    }

    // ── Vieta's formulas ─────────────────────────────────────────

    #[test] fn vieta() {
        assert_eq!(ARC_RED + ARC_GREEN, 832, "sum of roots");
        assert_eq!(ARC_RED * ARC_GREEN, 118300, "product of roots");
    }

    // ── System closure ───────────────────────────────────────────

    #[test] fn three_routes_to_green() {
        assert_eq!(FULL_CIRCLE_DEG + ARC_COPRIME, ARC_GREEN);
        assert_eq!(ARC_RED + ARC_SQRT_DISCRIMINANT, ARC_GREEN);
        assert_eq!((832 + ARC_SQRT_DISCRIMINANT) / 2, ARC_GREEN);
    }
    #[test] fn full_circle_double_red() {
        assert_eq!(FULL_CIRCLE_DEG, 2 * ARC_RED, "364 = 2 × 182");
    }
}
