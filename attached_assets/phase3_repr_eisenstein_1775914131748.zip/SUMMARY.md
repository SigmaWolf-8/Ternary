# Phase 3 — Representation Interop and Eisenstein Arithmetic

## What Was Built

Three files updated to add the four-representation conversion layer, Eisenstein multiplication/norm at GF(3) level, and div_repunit/mod_pow.

## Files

| File | Destination | Lines | Tests | What Changed |
|------|------------|-------|-------|-------------|
| `gf3_algebra.rs` | `ternary-math/src/gf3_algebra.rs` | 430 | 23 | Complete replacement. Original code preserved verbatim. Added: AlgebraicTrit enum, all 12 conversion paths (A↔B, A↔C, A↔D, B↔C, B↔D, C↔D), From<Gf3>/From<BalancedTrit> bridges, Eisenstein arithmetic methods on AlgebraicTrit, validators, batch conversions. |
| `trit_int.rs` | `ternary-math/src/trit_int.rs` | 2,143 | 71 | User's fixed Phase 1 preserved. Added: to_repr_a/b/c/d (MSB-first output), from_repr_a/b/c/d (MSB-first input), div_repunit (chunk-based), mod_pow (square-and-multiply, NOT constant-time). 20 new tests including 12-path round-trips and forgery rejection. |
| `trit.rs` | `ternary-math/src/trit.rs` | 1,243 | 67 | Phase 2 preserved. Added: mul_eisenstein (GF(3) level, mod-3 arithmetic), norm_eisenstein (computation order (a²+c²)−ac avoids underflow), AlgebraicTrit ↔ Trit bidirectional conversion (forward via From, reverse via to_algebraic_trit() returning Option). 16 new tests. |

## Key Design Decisions

**Eisenstein at GF(3) level:** mul_eisenstein operates on single GF(3) trit values extracted from v[0] and v[2]. Asserts inputs are GF(3)-scale (≤ 2) and have v[1]=0. Uses existing gf3_add/gf3_sub/gf3_mul — subtraction mod 3 never underflows. ω² = 2 + 2ω (since −1 ≡ 2 mod 3).

**norm_eisenstein computation order:** (a² + c²) − ac, NOT a² − ac + c². This avoids unsigned intermediate underflow since a² + c² ≥ ac for all non-negative a, c.

**AlgebraicTrit reverse mapping:** Returns Option — Some for unit elements (zero, one, ω), None for everything else. Non-unit Trit values have no single AlgebraicTrit representation.

**div_repunit:** Uses chunk-based approach exploiting 3ⁿ ≡ 1 (mod R_n). Sums n-trit chunks for remainder, computes quotient from exact division. Tests verify against general div_mod for R₁ through R₆.

**mod_pow:** NOT constant-time. Explicit caveat in doc comment: must not be used for cryptographic operations.

**Rep C forgery rejection:** from_repr_c panics on zero digits. This is the internal trust boundary. try_from_repr_c (returning Result for untrusted wire input) is deferred to Phase 5.

## Test Verification Points

- All 12 representation round-trip paths on framework constants (0, 1, 14, 182, 364, 729)
- ω² = 2 + 2ω (the GF(3) defining relation) 
- ω³ = 1 (cube root property in Eisenstein ring)
- Exhaustive 81-pair Eisenstein multiplication (3⁴ = all (a₁,c₁)×(a₂,c₂) combinations)
- Norm multiplicativity: N(a·b) = N(a)·N(b) mod 3
- AlgebraicTrit ↔ Trit round-trip for all three unit elements
- AlgebraicTrit ↔ Gf3 and AlgebraicTrit ↔ BalancedTrit round-trips
- Rep C zero-digit forgery rejection (#[should_panic])
- Eisenstein operations on non-GF(3)-scale values (#[should_panic])
- Eisenstein operations with non-zero φ-component (#[should_panic])
- Fermat's little theorem via mod_pow: 2¹² ≡ 1 (mod 13)

## lib.rs

Included with `pub mod trit;` added (from Phase 2). If your lib.rs already has this line, the included version is identical to yours plus that one line.
