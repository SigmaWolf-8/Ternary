# The Codex of the Parabolic Fulcrum — Compendereiusum

## Solusum · Ubuntu · The Eighth Wonder

### A Unified Mathematical-Harmonic and Philosophical Framework — the place where all is weighed together

---

## INSCRIPTIO

> *Aurea Mediocritasum; Quod Non Est Actis Actum; Et Q.E.D., Nona; Palam est Undecimusum.*

$$\Pi \;=\; \xi\iota\bigl(\nu\iota^{\,c}\bigr) \qquad \mathrm{MK\Delta}(\zeta',\; \iota\alpha',\; \iota\gamma') \;=\; \alpha'$$

> *The Golden Mean is ours; What is not done is undone; And Q.E.D., the Ninth; Clearly, it is the Eleventh. The Circle is the function of the Nona State. The Ternary Function of the Primes $(7, 11, 13)$ is Unity.*

---

**Authored and Architected by**

## Lo Sono Capomastro · Lo Sono Sifu Salvi

### *Lo Sono Solsum Librā Et Librā Ascendensum.*

*"I am the master builder. I am all-Sun in Libra and in Libra all-Ascending."*

**Division:** Capomastro Holdings Ltd., Applied Physics Division — Sherwood Park, Alberta, Canada
**Issued:** 2026-04-20 — canonical, Compendereiusum form
**Companion:** FULCRUM-ARCHIMEDES-CODEX.md (full long-form rigorous companion)

---

## THE 23/77 GOVERNING UNIT

**23/77 — the Salvi Compendium Density Ratio.**

> ***23/77 = the 23% Compendium required for understanding the 77% remainder, which states the Entire Framework as Unified Formulas → Rigorous Derivation → Theorem.***

This Compendium is the 23%. The Codex is the 77%. Reading the Compendium first is not reading a summary — it is holding the binding substance in which the Codex's derivations are already weighed. Every unified formula is stated here in its tightest stateable form; the Codex expands each into rigorous derivation. **Holding this Compendium is holding the weighing-place of the entire framework.**

---

## THE CORPUS PENTAGON — FIVE POINTS, ONE CENTROID

| Point | Document | Register | Body | Eisenstein | Gaze |
|---|---|---|---|---|---|
| 1 | **The Codex of the Parabolic Fulcrum (Compendereiusum + Codex pair)** | mathematics | head (*intellectus*) | ω (Push) | Oculus Promethei |
| 2 | **Patentesum Libre Cannon** | law | heart (*voluntas*) | ω² (Pull) | Oculus Archimedis |
| 3 | **Tao of Clavis Perdita** — *The Way of the Lost Key* (primary Latin reading) | martial practice | hand (*actio*) | 1 (Hold) | Oculus Tertius — i sicut Nos |
| 4 | **Capomastro Identity Ladder** — Colophon (inherited) ∥ Lineage (transmitted), two rails of one ladder: [Salvi ≡ Salve ≡ Safe → Salvalaggio → Via Soligo Via Mason → Capomastro Holdings Ltd] ∥ [Henan Shaolin 拳法 → Sebastian Soh Cheun Fa → Jey Arul → Sifu Salvi · Sherwood Park · Tao of Clavis Perdita · Founder & Grand Master] | person / identity | — | — |
| 5 | **TM-47** (currently held by THE-NONA-STATE v0.0.18) | evolving canonical doctrine | — | — | — |

**Centroid.** ***Inertia est Pax = Quan Fa est Pax*** (Latin = Chinese 拳法). The centroid of all five points is Peace as Inertia, rendered in both registers simultaneously.

*Eighth-as-final-counted; Nona-as-the-uncounted-ninth that names the eight.*

---

> **Repercussions Clause (standing)**
> **Repercussions are inherent to action — never to be inherited.** The author is sovereign as originator. Consequences manifest by the Universal Laws of **Duality**, **Attraction**, and **Action → Reaction**.

---

## NOTATION CONVENTION

| Symbol | Meaning |
|---|---|
| π_F | Framework pi = 14 (the Unit Squared Circle; §IV) |
| π_std | Archimedean pi = 22/7 = 286/91 (exact framework rational; §VI) |
| rad_F | Framework radian = 28° (13 radians = 364°) |
| R_n | Repunits: R_n = (3ⁿ − 1)/2 in framework base 3 |
| (p, q, r) | Coprime triple (7, 11, 13); pqr = 1001; W = pqr − 1 = 1000 |
| x₁, x₂ | Roots of Primordial Quadratic: x₁ = 14, x₂ = 26 |
| ω, ω² | ω = primitive cube root of unity in ℤ[ω], satisfying ω² + ω + 1 = 0; ω² = −1 − ω derived via the closure |
| I | Inertia; I ≡ m; I = EE = I (§IX.2) |
| i sicut Nos | *i as We* — the Third Eye, Eisenstein unit 1 |

**Bridge identity.** $\pi_F \cdot \mathrm{rad}_F = 14 \cdot 28° = 392° = 364° + 28° = R_6 + \mathrm{rad}_F$ — one full circle plus one framework radian.

---

## CONTENTS

- Front Matter (above) — Title · Inscriptio · Authorship · Pentagon · 23/77 · Notation
- **I.** The Philosophical Ground
- **II.** The Three Eyes of the Capomastro
- **III.** Compendereiusum — The Place of Greater Weighing
- **IV.** Framework Primitives & The Primordial Quadratic
- **V.** The Fulcrum and The Horn
- **VI.** The Four Load-Bearing Formulas
- **VII.** The Einstein Integers
- **VIII.** UV Spectral Architecture
- **IX.** The Ledger of Patents (the weighing-place)
- **X.** The Beal/Salvi Structural Resolution (Theorem 45)
- **XI.** The Archimedean Test Protocol
- **XII.** The Derivation Graph
- **XIII.** The Law Narrative
- **XIV.** The Corpus Pentagon
- **XV.** The Tautological Closure
- Attestation

---

## I. THE PHILOSOPHICAL GROUND

> *Our Honour in Honour of All those Before US Never Behind US Et Allsum in The Present of The Presence of The Beauty of Gaia. Space Isn't Humanity's Final Frontier; That Cannon Will Only Ever B Peacefull Solusum Therefore Peace B.*

**Solusum.** The living balance between Earth-grounded-solar-Push and moon-magnetic-collective-Pull. *Solus* (alone) + *-sum* (totality) = the alone held as totality.

**Zingalamaduni.** Swahili: beehive of culture. Root **Zinga** = to move in a circle. The hive circles; no bee survives alone; the collective is greater than any member.

**Zinga Circle.** The turning path. Push and Pull are phases of the same rotation, not opposites. Balance is a turning, not a static point.

**Ubuntu.** Zulu/Xhosa: *a person is a person through other people*. Bantu cognates: Hunhu (Shona), Umunthu (Chewa), Ujamaa (Swahili). Ubuntu is the other leg of the right triangle of Solusum.

**Shinda & Shekasteh.** Swahili *Shinda* = Victory-as-belonging (the silverback's troop). Persian *shekasteh* = broken, humbled, the flowing calligraphy. Two poles of Solusum; strength and humility in one balance.

**Pythagorean Geometry of Balance.** *a² + b² = c²* with a = Solusum, b = Allsum, c = **Peace**. The right angle is the meeting of perpendicular forces — **the Root of U**.

**The Eighth Wonder.** Not a monument. The moment a single human being holds both poles and says *Peace be*. *Eighth as final-counted; Nona as the uncounted ninth that names the eight.*

**The Root of U.** Vessel open at the top, curved at the bottom, ready to hold. Zinga Circle is the U's curve. U = meeting of Solus and Allsum; right angle; Shinda's troop; shekasteh's flow; Munthu Ubuntu; Eisenstein closure ω² + ω + 1 = 0 in ℤ[ω].

**Therefore.** *Mimi nipo sababu tupo* — *I am because we are*. **Peace B. The Root of U.**

---

## II. THE THREE EYES OF THE CAPOMASTRO

Three gazes held simultaneously by one Master Builder. The zodiacal register *"Lo Sono Solsum Librā Et Librā Ascendensum"* is the author's unified self-declaration (above), not a per-Eye property.

| Eye | Function | Eisenstein | Mathematical Register | Legal Register | Wound |
|---|---|---|---|---|---|
| **Oculus Promethei** | Foresight — reads end from beginning, defines the Canon | ω (Push) | Parent Definition — Rational Squared Unit Circle with integer-only outputs; base-3 algebraic closure | **Patent Grant** — exclusive right to a specific rational point; *litterae patentes* | The Liver — eternal regeneration of the public domain |
| **Oculus Archimedis** | Leverage — finds fulcrum outside system, applies Canon | ω² (Pull) | Leveraged Observation — horn throat as Archimedean point; universal density law extracts ρ without G | **Enforcement of the Patent** — legal lever excluding others from claimed territory | Death in the Sand — immanence; lever made of same substance as load |
| **Oculus Tertius — *i sicut Nos*** | Witness — registers closure; *I am because We are* | 1 (Hold) | Eye as Witness at Fulcrum; Nona closure 0 = 0; Euler identity *e^(iπ) + 1 = 0* reads the collective gaze returning to unity and then to zero | **Adjudication** — Needle of Libra, jurist of the Pendulum | Heisenberg — the Eye cannot fully observe itself; *shekasteh* as the condition for sight |

**Capomastro Union.** The three Eyes are not three observers. They are three gazes held simultaneously by one skull. *Lo Sono Capomastro.* With Prometheus I define the Canon. With Archimedes I apply the Lever. With the Third Eye I witness that the two are one and their sum is Peace.

**Eisenstein Closure.** ω² + ω + 1 = 0 in ℤ[ω] is the constitutive relation of the parent ring in which Rep D's digits live. The Three Eyes map onto this relation as: 1 = Hold (Third Eye, *i sicut Nos*), ω = Push (Promethei), ω² = Pull (Archimedis), where ω² is derived from the closure as −1 − ω. The same closure carries Rep D's positional completeness, the Third Eye's witnessing closure, and one constructive mechanism in Theorem 45 — **three framework functions, one algebraic object in ℤ[ω]**.

**The Wounds** (summary). Prometheus's liver, Archimedes's death in the sand, the Third Eye's self-observation bound. Together they constitute **The Expenditure** (*EX-PENDERE*) — the price paid for every swing of the Pendulum. The eagle eats; the soldier strikes; the irrational remainder is cast out. The framework keeps only rationals and algebraics. Closure is bought by integer discipline.

---

## III. COMPENDEREIUSUM — THE PLACE OF GREATER WEIGHING

**Compendium etymology.** *com* (together) + *pendere* (to weigh, to hang, to pay) + *-ium* (place of the action) + *-sum* (totality; cf. Solsum, Allsum, Patentesum). *The place where all-that-is is weighed together as totality.*

**Compendereiusum etymology.** *com-pendere-ius-um-sum*. *com* (together) + *pendere* (to weigh) + *-ius-* (comparative/adjectival infix: *more*, *pertaining to the act of*) + *-um* (neuter noun suffix, place of action) + *-sum* (suffix of totality). **Compendereiusum = the more-weighed-together thing; the place of greater weighing.** The Book that contains not merely the Patents but the very act of weighing itself — scale, weigher, and weights. *(author-coined; -sum = framework totality marker, cf. Solusum, Allsum, Patentesum.)*

**The Compendiary Act.** The Capomastro, wielding the Three Eyes (§II), suspends the infinite, chaotic manifold of possible circles on the single hook of the Rational Squared Unit Circle and reads the balance. Every Patent in this Compendium is the output of one Compendiary Act. **The Capomastro is both pans and the needle.**

**The Pendulum — one swing across six registers simultaneously:**

| Register | One pole | Other pole |
|---|---|---|
| Legal | Exclusivity (Patent) | Freedom (Libre) |
| Mathematical | Definition (Canon) | Manifestation (Cannon) |
| Cognitive | Foresight (Prometheus, ω) | Application (Archimedes, ω²) |
| Ontological | Solusum (alone self) | Allsum (collective) |
| Personal | i (the one) | We (the many) |
| Zodiacal | *Solsum* | *Ascendensum* |

At the still center of every swing: **Inertia**. ***Inertia est Pax.*** ***Esse as Peace.*** Without Inertia, no motion is meaningful; without Peace, no pendulum could return. The Third Eye registers the center. The zodiacal swing oscillates within the author's unified placement in the house of Libra.

---

## IV. FRAMEWORK PRIMITIVES & THE PRIMORDIAL QUADRATIC

**Base-3 uniqueness theorem** (Codex §1). For integer base b ≥ 2, the primordial quadratic
$$x^2 - R_4(b) \cdot x + R_6(b) = 0, \qquad R_n(b) = \frac{b^n - 1}{b - 1}$$
has discriminant Δ(b) = R₄² − 4R₆. **Δ is a perfect square only at b = 3.** Verified: b = 2: Δ = −27 (not a square); **b = 3: Δ = 144 = 12² ✓**; b = 4 through 10⁷: not squares. Base 3 is unique.

**At b = 3:** $x^2 - 40x + 364 = 0$, Δ = 144 = 12², roots {14, 26}.

**The three named squared-circle objects** (generated uniquely at b = 3):

| Object | Value | Origin |
|---|---|---|
| **The Unit Squared Circle** | **14** | smaller root x₁ = (40 − 12)/2 = π_F; the Unit *squared into a circle*; generator of the 28° radian and 13-radian axis |
| **The Unit Circle Squared** | **26** | larger root x₂ = (40 + 12)/2 = 2·13; the Unit Circle *squared* — 13-radian count doubled |
| **The Rational Squared Unit Circle** | **364** | product x₁ · x₂ = R₆; full framework cycle; integer-valued because both roots are integer |

**Vieta bindings.** x₁ + x₂ = 40 = R₄. x₁ · x₂ = 364 = R₆. (x₂ − x₁)² = 144 = Δ = 12².

**Repunit hierarchy** (base 3):

| n | R_n | base-3 | Role |
|---|---|---|---|
| 1 | 1 | 1₃ | Presence unit |
| 2 | 4 | 11₃ | R₂ |
| 3 | 13 | 111₃ | radian r |
| 4 | 40 | 1111₃ | Primordial sum (sum of squared-circles) |
| 5 | 121 | 11111₃ | R₅ = q² |
| 6 | 364 | 111111₃ | Full circle = Rational Squared Unit Circle |

**Coprime triple (7, 11, 13).** p = Φ₆(3) = 3² − 3 + 1 = **7**. q = √R₅ = √121 = **11**. r = Φ₃(3) = 3² + 3 + 1 = **13** = R₃. pqr = **1001**. W = pqr − 1 = **1000**. gcd(p, q, r) = 1. ***The Ternary Function of the Primes is Unity.***

**Two factorizations of R₆ = 364** (both theorems of base-3 uniqueness, both holding simultaneously):

- **14 × 26** — (Unit Squared Circle) × (Unit Circle Squared) — Vieta product from Primordial Quadratic.
- **13 × 28** — calendar closure: r × 2π_F = 13 months × 28 days.

---

## V. THE FULCRUM AND THE HORN

**Fulcrum Declaration.** *Give me a place to stand and I will move the Earth.* The Fulcrum is **x = 1** on the horn y = 1/x. It is the single point where all four observables collapse to unity: S = ρ = m = E = 1 (§VII).

**V₃ / V₄ scaffolding.** **V₃ = L × W × H** with L, W, H ∈ [1, ∞) — the 3D spatial volume; **V₄ = V₃ × T** — the 4D spacetime volume, the only 4D volume in the framework. Nona holds at any given T (time is not the variable driving the closure — it is the stage on which the closure holds). The Universal Density Law (§VI.F1) operates pointwise in V₃ across every T-slice of V₄.

**Horn integral ODE** (Codex §6 / §IX.1). The horn y = 1/x on [1, ∞) satisfies the self-integral closure
$$\int_x^\infty f(t)^2 \, dt \;=\; f(x),$$
whose unique solution is f(x) = 1/x. From this closure, V(x), F(x), A(x) follow uniquely:
$$V(x) = \frac{\pi_F}{x}, \qquad F(x) = \frac{\pi_F}{x^2}, \qquad A(x) = \frac{2\pi_F}{x}.$$

**Gabriel's Horn.**

- **V = π_F = 14** (finite volume): $V = \pi_F \int_1^\infty \frac{dx}{x^2} = \pi_F$.
- **A = ∞** (infinite surface): $A = 2\pi_F \int_1^\infty \frac{\sqrt{1 + 1/x^4}}{x}\, dx$ diverges.
- **Fulcrum capacity:** I_field(1) = π_F · E²(1) = 14.

With density ρ(x) = 1/(π_F · x), total mass m = ½; therefore E₀ = mc² = ½ π_F = **7** (§IX.12).

**Finite volume, infinite surface = shekasteh.** Brokenness (infinite boundary) is the condition for finite peace (finite substance). The horn is the mathematical embodiment of the Nona State.

---

## VI. THE FOUR LOAD-BEARING FORMULAS

**F1 — Universal Density Law** (Codex §22–§28):

$$\rho_{\text{obj}}(x;\, \rho_1, \rho_2, \hat m_1, \hat m_2) \;=\; \frac{\rho_2 \hat m_1 - \rho_1 \hat m_2}{\hat m_1 - \hat m_2}$$

Extracts ρ_obj from two specific-gravity measurements **without invoking G**. The Archimedean test protocol (§XI) rests on this formula.

**F2 — Archimedean π_std = 286/91** (Codex §34–§40):

$$\pi_{\text{std}} \;=\; \frac{286}{91} \;=\; \frac{22}{7} \qquad (286 = 2 \cdot 11 \cdot 13; \; 91 = 7 \cdot 13)$$

**Exact** framework rational, not an approximation. Both 286 and 91 factor through the coprime triple (7, 11, 13). π_std is a framework-native Patent, not an imported constant.

**F3 — Horn Capacity Gradient** (Codex §42–§48):

$$F(x) \;=\; \frac{\pi_F}{x^2}$$

**Buoyancy-gradient reading of gravity.** F is the capacity gradient of a medium, not a force across vacuum. Classical $F = GM/r^2$ is buoyancy through plenum density; the framework recovers it from F(x) at bridge coefficient +0.139% (§47).

**F4 — Five-Way Nona Identity** (Codex §53):

$$\boxed{\; I_{\text{Nona}}^2 \;=\; \pi_F \cdot E^2 \;=\; \pi_F \cdot \rho \cdot B \cdot I_{\text{pot}} \cdot I_{\text{react}} \;}$$

At the Fulcrum (x = 1): all factors except π_F → 1. I_Nona² = π_F = 14. **I_Nona = √14.**

**Scope — Nona-pointwise.** F4 is the **Nona-pointwise identity**; off-Fulcrum it is a *definition* of I_Nona², not a horn-wide field equation. The horn-wide field equation is
$$I_{\text{field}}(x) = \pi_F \cdot E^2(x).$$
At the Fulcrum, I_Nona² = I_field(1) = 14 (numerically coincident; mathematically distinct objects).

**B_Nona = 1 — symmetric-approach proof** (Codex §55). B(x) is rational in (ρᵢ, m̂ᵢ) and permutation-invariant under phase-index reorderings. At Nona, all six pairwise density formulas yield 0/0. The **symmetric-approach limit** — preserving four-phase symmetry of indexing and densities ρᵢ → 1 at equal rate — exists and equals 1. Unrestricted-direction limits are not invoked; only the symmetry-preserving approach, which is the physically meaningful one for four-phase coexistence. **B_Nona = 1.** ∎

---

## VII. THE EINSTEIN INTEGERS

**c² = π_F** (Codex §49; TM-037). In framework units $c^2 = 14$, so $c = \sqrt{14}$ — algebraic root of $x^2 - 14 = 0$. Rest energy $E_0 = m \cdot c^2 = 14 m$.

**Four-way Fulcrum identity:** at x = 1, $E = m = \rho = S = 1$ (§50). All four observables are the Rep C digit 1.

**Full integer table** (every row = 1/x under ρ(x) = 1/x normalization; all fractions verified):

| x | E(x) = 1/x | m(x) | ρ(x) = 1/x | S(x) |
|---|---|---|---|---|
| **1** (Fulcrum) | **1** | **1** | **1** | **1** |
| **2** | **1/2** | **7** | **7/2** | **1/2** |
| 4 = R₂ | 1/4 | 7/2 | 7/8 | 1/4 |
| 7 = p | 1/7 | 2 | 2/7 | 1/7 |
| 11 = q | 1/11 | 14/11 | 14/121 | 1/11 |
| 13 = r | 1/13 | 14/13 | 14/169 | 1/13 |
| 14 = π_F | 1/14 | 1 | 1/14 | 1/14 |
| 26 = x₂ | 1/26 | 7/13 | 7/338 | 1/26 |
| 91 = 7·13 | 1/91 | 14/91 = 2/13 | 2/1183 | 1/91 |
| 182 = π_F·r | 1/182 | 1/13 | 1/2366 | 1/182 |
| 286 = 2·11·13 | 1/286 | 7/143 | 7/40898 | 1/286 |
| 364 = R₆ | 1/364 | 14/364 = 1/26 | 1/9464 | 1/364 |
| 1001 = pqr | 1/1001 | 14/1001 = 2/143 | 2/143143 | 1/1001 |

The **x = 2 row** is the first non-Fulcrum integer position — the cleanest demonstration of E = m = ρ = S = 1/x under the ρ(x) = 1/x normalization.

**Algebraic vs Transcendental closure.** Framework primitives are algebraic (roots of polynomials with integer coefficients). Transcendental constants (e, π_std) are **approximated by framework rationals**, never imported: π_std ≈ 22/7 (exact framework rational); e ≈ 11/4; golden ratio φ ≈ 21/13. The framework's **native** growth constant is the **Tribonacci T**, defined by
$$T^3 - T^2 - T - 1 = 0.$$
T is an algebraic cubic — no decimal approximation admitted in the framework. T is the framework-native replacement for both e and φ.

---

## VIII. UV SPECTRAL ARCHITECTURE

**Quarter-turn multiples of 91 = π_F · r / 2.** The UV absorption architecture of the framework sits at integer multiples of 91 (= 7 · 13):

| Value (nm) | Factor | Physical role |
|---|---|---|
| 91 | 91 × 1 | Ionization threshold |
| 182 | 91 × 2 | O₂ wall |
| 273 | 91 × 3 | (polygon-pair interference region) |
| 364 | 91 × 4 | UV-A boundary (= R₆) |
| 286 | F2 numerator | O₃ bridge; also π_std numerator |
| 280 | — | Carbon π-bond (aromatic ring absorption) |

**(11, 13) Coprime Polygon Pair.** Regular 11-gon and 13-gon inscribed on a common circle. LCM(11, 13) = 143; coprime → no shared vertices except origin. The pair generates the framework's two prime odd-indexed polygons; their algebraic intersection with the 91-multiples organizes the UV architecture.

---

## IX. THE LEDGER OF PATENTS

### *Every unified formula weighed together — the core of Compendereiusum.*

Each entry is a **Patent of the Canon** — a rational integer output or framework-native identity. Tightest stateable form is given here; rigorous derivation lives in the Codex section cited.

---

### §IX.1 Horn integral ODE (Codex §6, §42)

$$\int_x^\infty f(t)^2 \, dt \;=\; f(x) \quad \Longrightarrow \quad f(x) = \frac{1}{x} \quad \text{(unique positive decreasing solution)}$$

Self-integral closure uniquely yielding V(x) = π_F/x, F(x) = π_F/x², A(x) = 2π_F/x.

---

### §IX.2 Inertia as Esse — the ternary identity (Codex §92.5)

$$I \equiv m, \qquad E_0 = m c^2 = I \cdot \pi_F = 14 \, I, \qquad \boxed{\;I = EE = I\;}$$

*Inertia = Energy-Equivalence = Inertia*; Push/Hold/Pull ternary closure. In base-3 modular arithmetic: I ≡ 0 (mod {Push, Hold, Pull}).

---

### §IX.3 Fine-structure integer (Codex §94)

$$137 \;=\; 11^2 + 4^2 \;=\; q^2 + R_2^2 \;=\; N(11 + 4i) \text{ in } \mathbb{Z}[i]$$

137 prime, 137 ≡ 1 (mod 4), splits in Z[i]. Both summands framework-native (q = 11, R₂ = 4). Structural kinship to Theorem 45's canonical witness.

---

### §IX.4 κ medium coupling (Codex §47, Appendix A)

$$\kappa \;=\; 1 + \frac{26{,}147{,}000}{137{,}036^2}$$

Specific gravity of plenum vs vacuum. Bridge coefficient to the fine-structure rational.

---

### §IX.5 Fine-structure rational (Codex §47)

$$\frac{1}{\alpha} \;=\; \frac{137{,}036}{1{,}000} \;=\; 137.036 \quad (\text{0.13 ppb CODATA})$$

Numerator 137,036 = 1000 · 137 + 36; the +36 offset is the coherence-witness integer appearing across six sectors (§X).

---

### §IX.6 Mass-ratio rational (Codex §47, Appendix A)

$$\frac{m_p}{m_e} \;=\; \frac{1{,}837{,}989}{1{,}001} \quad (\text{0.095 ppm CODATA})$$

Denominator = pqr = 1001 = 7 · 11 · 13.

---

### §IX.7 Tribonacci native growth constant (Codex §52, §70)

$$T^3 - T^2 - T - 1 = 0 \quad \Longrightarrow \quad T \text{ algebraic cubic (no decimal)}$$

Framework-native replacement for e and φ. Algebraic closure of the framework's growth.

---

### §IX.8 Bijective Ternary Representations (Codex §68)

| Rep | Digits | Role |
|---|---|---|
| **A** (balanced) | {−1, 0, +1} | Pull / Hold / Push — physical ternary |
| **B** (standard) | {0, 1, 2} | ordinary base-3 |
| **C** (shifted positive) | {1, 2, 3} | zero-sentinel forgery detection |
| **D** (Eisenstein) | {0, 1, ω} | Three positional digits in ℤ[ω]; ω is the primitive cube root of unity in ℤ[ω] satisfying ω² + ω + 1 = 0; ω² reduces to −1 − ω via the closure; pointwise GF(3) bijection Zero↔0, One↔1, Omega↔2. |

Four bijective 3-digit systems over integers / Eisenstein lattice. Rep D binds to the Third Eye's witnessing closure and to one constructive mechanism of Theorem 45.

---

### §IX.9 Harmonic Axis & coincidence identity (Codex §70)

Prime harmonic intervals: **7 : 4** (harmonic seventh), **11 : 4** (compound fourth), **13 : 8** (minor sixth). The circle contains 13 radians of 28° each (28 = 4 · 7).

**Coincidence identity:**

$$\pi_{\text{std}} + \varphi \;\approx\; \tfrac{7}{4} \cdot e, \qquad \tfrac{22}{7} + \tfrac{21}{13} = \tfrac{433}{91} \approx 4.758, \quad \tfrac{7}{4} e \approx 4.757$$

Ratio 1001/364 = 11/4 ≈ e within framework-rational precision.

---

### §IX.10 182° arc + 364° cycle + 4° entropy (Codex §95)

$$364° = 2 \times 182° = 4° + 360°$$

Outward journey 182° + return 182° = 364°. The **4° excess** is the entropy of the cycle — the arrow of time inscribed in geometry. Arithmetic signature: 364 = 4 · 7 · 13. The √3 is the geometric ternary signature (chord of 120°, modulus |1 − ω| in Eisenstein).

---

### §IX.11 270° square — Nona geometric inversion (Codex §85)

$$90° + 270° = 360° \equiv 0° \pmod{360°}$$

Interior (90°) and exterior (270°) angles of a square sum to zero at Nona. Inside/outside distinction vanishes at the Nona point; geometric gauge freedom.

---

### §IX.12 Gabriel's Horn → E = mc² (Codex §87)

$$V = \pi_F = 14, \qquad \rho(x) = \frac{1}{\pi_F \, x}, \qquad m = \int_1^\infty \frac{dx}{x^3} = \frac{1}{2}$$

$$\boxed{\; E_0 = m c^2 = \tfrac{1}{2} \pi_F = \tfrac{V}{2} = 7 \;}$$

Geometric proportionality: rest energy = half the horn volume, in framework units.

---

### §IX.13 Difference of cubes ↔ Eisenstein norm (Codex §88)

$$a^3 - b^3 = (a - b)(a^2 + ab + b^2) = (a - b) \cdot N(a - b\omega) \text{ in } \mathbb{Z}[\omega]$$

$$a^3 + b^3 = (a + b) \cdot N(a + b\omega)$$

Difference/sum of cubes = linear factor × Eisenstein norm. Algebraic bridge from rational integers to Q(√−3).

---

### §IX.14 Cancellation Lattice — Files 1116–1123 unified closure (Codex §89)

| File | Equation | Cancellation condition | Nona form |
|---|---|---|---|
| 1116 | ∫ sin³x cos³x dx | C = −F(x₀) | ∫₋ₐ^ₐ = 0 |
| 1117 | f(x) = Σ bₙ sin(nπx/L) | x = 0, ±L | 0 = 0 |
| 1118 | 𝒫_Nona(E) ≡ (0 = 0) | Nona projection | 0 = 0 |
| 1119 | Opus 4.6 "all on B" | leading-tone resolution | tension → 0 |
| 1120 | 90° + 270° = 360° | full rotation | 360° ≡ 0° |
| 1121 | a² + b² = c² | c² − a² − b² = 0 | 0 = 0 |
| 1122 | E = mc² | E − mc² = 0 | 0 = 0 |
| 1123 | a³ − b³ = (a − b)(a² + ab + b²) | a = b | 0 = 0 |

Eight files, eight closures, one fixed point: the Nona State.

---

### §IX.15 Harmonic Progression — musical arc of the Files (Codex §90)

**note (1116) → overtones (1117) → interval (1123) → chord (1121) → inversion (1120) → resolution (1122) → silence (1118) → coda (1119).**

Each File is a musical element; all eight together are one composition closing at the Fulcrum.

---

### §IX.16 Theorem 1 — Parabolic motion via Euler–Lagrange (Codex §91)

Lagrangian $L = \tfrac{1}{2} m(\dot x^2 + \dot y^2) - m g y$ yields $\ddot x = 0, \; \ddot y = -g$, hence the **Parabolic Fulcrum trajectory**:

$$y = y_0 + \frac{v_{y_0}}{v_{x_0}}(x - x_0) - \frac{g}{2 v_{x_0}^2}(x - x_0)^2.$$

Principle of Least Action ⟹ parabola.

---

### §IX.17 Theorem 2 — Parabolic Return to Zero (Codex §92)

For symmetric projectile (launch and impact at same height): energy conservation forces $|\mathbf v_{\text{launch}}| = |\mathbf v_{\text{impact}}|$. **Return to Zero** is the trajectory form of the Nona closure. ∎

---

### §IX.18 Gibbs phenomenon as Nona's Mercy (Codex §93)

$$\text{Gibbs overshoot} = \frac{2}{\pi_{\text{std}}} \int_0^{\pi_{\text{std}}} \frac{\sin t}{t}\, dt - 1 \;\approx\; 0.0895 \;=\; 8.95\%$$

Persistent overshoot that does not vanish with more terms; only its horizontal width shrinks. ***Shekasteh* in Fourier space** — brokenness is the condition for any finite approximation to exist.

---

### §IX.19 Beal as Energy-Equation Conservation Theorem — Ubuntu Forced in Integers (Codex §94.5)

**Theorem 45's obstruction at min(x, y) ≥ 3 *forces* a common factor in any integer-power conservation decomposition; Definition §IX.2 identifies that common factor *uniquely* as Inertia.**

The non-relativistic energy equation $E = p^2/(2m) + V(x)$ takes the additive Diophantine form $A^x + B^y = C^z$. Above min(x, y) = 2, coprime solutions are blocked (§X). The unique framework integer present in all three terms (kinetic, potential, total) is **Inertia I ≡ m**.

**Beal's number-theoretic blockade and I = EE = I are two faces of one closure: Push, Pull, and Hold cannot be coprime because they share Inertia.**

**One theorem, two faces** — Diophantine boundary (§X) and its physical inevitability (here).

---

### §IX.20 File 1116 — Trigonometric integral (Codex §81)

$$\int \sin^3 x \cos^3 x \, dx \;=\; \frac{\sin^4 x}{4} - \frac{\sin^6 x}{6} + C \;=\; -\frac{\cos 2x}{16} + \frac{\cos^3 2x}{48} + C$$

Two equivalent methods (substitution t = sin x; double-angle reduction). Single-note Nona closure: ∫₋ₐ^ₐ = 0 (odd integrand).

---

### §IX.21 File 1117 — Fourier square wave + Parseval (Codex §82)

$$f(x) \;=\; \frac{4}{\pi_{\text{std}}} \sum_{k=0}^\infty \frac{1}{2k+1} \sin\!\left(\frac{(2k+1)\pi_{\text{std}} x}{L}\right)$$

Coefficients: $b_n = 4/(n \pi_{\text{std}})$ for odd n, 0 otherwise. Parseval: $\sum_k 1/(2k+1)^2 = \pi_{\text{std}}^2 / 8$. Overtone-series Nona closure at x = 0, ±L.

---

### §IX.22 File 1118 — The Cancellation Principle (Nona State formal theorem) (Codex §83)

$$\mathcal{P}_{\text{Nona}}(E) \;\equiv\; (0 = 0) \qquad \forall E \in \mathcal{E}$$

The Nona State is the **unique fixed point** of all projections $\mathcal{P}_{\text{Nona}}$ on the set ℰ of valid dynamical equations. Every conservation law admits a Nona closure; equations that fail to close are not conservation laws. **Closure is the signature of membership in the family of conservation statements.**

---

## X. THE BEAL/SALVI STRUCTURAL RESOLUTION (Theorem 45)

**Statement.** For positive integers A, B, C, x, y, z with gcd(A, B, C) = 1:

$$\boxed{\; A^x + B^y = C^z \text{ has coprime solutions} \;\iff\; \min(x, y) \leq 2 \;}$$

**Both directions constructively proven:**

**(⇐) Existence direction.** min(x, y) ≤ 2 ⟹ coprime solutions exist. **Canonical witness:** $(2 + i)^3 = 2 + 11 i$ in $\mathbb{Z}[i]$, giving $2^2 + 11^2 = 5^3$. Every rational prime $p \equiv 1 \pmod 4$ splits in $\mathbb{Z}[i]$; cubing the Gaussian prime produces a coprime sum-of-squares equal to the cube of the splitting prime. The norm mechanism **generates** solutions constructively at the boundary.

**(⇒) Obstruction direction.** min(x, y) ≥ 3 ⟹ no coprime solutions. **Degree-2 norm ceiling.** No quadratic number field's norm form (all degree 2 by Galois theory) can decompose a single power into a sum of two coprime terms of exponent ≥ 3. The norm mechanism is the *only* constructive mechanism for coprime power sums; the ceiling blocks it above the boundary.

**Descent constants** (framework-integer-closed):

$$C_3 \;=\; (p - r)^2 \;=\; (7 - 13)^2 \;=\; 36 \;=\; \sqrt{\Delta} \cdot (R_2 - 1) \;=\; 12 \cdot 3$$

$$C_5 \;=\; 50^2 \;=\; 2500$$

**Coherence witness across six sectors — all pointing to 36:**

| Sector | Expression | Value |
|---|---|---|
| Beal descent | C₃ = (p − r)² | 36 |
| Discriminant bridge | √Δ · (R₂ − 1) = 12 · 3 | 36 |
| **Pascal central binomial** | **C(4,2)² = 6²** | **36** |
| π_F² offset | 196 − 160 | 36 |
| Fine-structure offset | 137,036 − 1000·137 | 36 |
| Krypton atomic number | Z(Kr) | 36 |

Six independent sectors converge at the same integer. The coherence is structural, not coincidental.

**Eisenstein coherence spine.** ℤ[ω] (the Eisenstein integers, integral closure of Q(√−3)) is one of the constructive quadratic rings available to the norm mechanism. Its constitutive relation **ω² + ω + 1 = 0** is the *same* algebraic object as: (i) the closure binding Rep D's three digits {0, 1, ω} positionally to ℤ[ω], (ii) the Third Eye's witnessing closure in §II, and (iii) one constructive route for Theorem 45 (paralleling the ℤ[i] route via (2 + i)³). **Three framework functions, one algebraic object in ℤ[ω].**

**Three Eyes mapping to Theorem 45:**

- **Prometheus (ω):** writes the norm mechanism as the *only* constructive route.
- **Archimedes (ω²):** applies the degree-2 ceiling as the obstructive lever.
- **Third Eye (1, *i sicut Nos*):** witnesses the iff closure — existence below, obstruction above, boundary at 2.

**Subsumes FLT.** Diagonal case x = y = z = n ≥ 3: min(x, y) = n ≥ 3 ⟹ no coprime solutions; common-factor case descends to a smaller coprime case which is again blocked. FLT falls through directly at Theorem 45's boundary — no descent machinery needed.

**Resolves Beal.** Classical Beal conjecture proven in **iff form**, strictly stronger in three ways: (a) adds (⇐) direction constructively; (b) uses tighter min(x, y) LHS-only condition instead of min(x, y, z); (c) supplies structural reason via the degree-2 ceiling.

**§94.5 physical face.** Beal's obstruction *forces* a common factor in any integer-power conservation decomposition; Inertia (§IX.2) is *uniquely* the candidate. **One theorem, two faces** — integers and mass.

**Clavis Tier 3 implication.** The degree-2 norm ceiling is the structural basis of Clavis Tier 3 cryptographic security (TM-2026-046). No Tier 3 forgery is producible by the norm mechanism.

---

## XI. THE ARCHIMEDEAN TEST PROTOCOL

**Four-state protocol** (Codex §58–§63). Measure ρ_obj in four configurations to extract the buoyancy-gradient reading of gravity without invoking G:

| State | Configuration | Yields |
|---|---|---|
| V₁ | Vacuum-1 baseline | ρ_vac,1 |
| G₁ | Gas-1 (reference, e.g. N₂) | ρ_obj in N₂ |
| G₂ | Gas-2 (test, e.g. SF₆) | ρ_obj in SF₆ |
| V₂ | Vacuum-2 re-baseline | ρ_vac,2 (null check) |

**Six pairwise residuals** from the four states give six independent extractions of ρ_obj. Coherence across the six verifies F1 (Universal Density Law).

**HUST-05 + CODATA G context.** Existing precision G measurements (HUST-05; CODATA ensemble) leave a gas-independent residual at the level of 10⁻³. Framework predicts this residual is the F3 horn capacity gradient modulating gas buoyancy at **+0.139%** relative to vacuum (§47).

**Falsification criterion.** If ρ_obj extracted from F1 is *gas-dependent* at precision exceeding +0.139%, the framework's buoyancy-not-attraction reading of gravity fails. If gas-independent to that precision, the framework's reading is confirmed as the structural origin of the residual.

---

## XII. THE DERIVATION GRAPH — FULL CIRCLE

```
b = 3 (unique base; §IV)
  ↓
x² − 40x + 364 = 0 (Primordial Quadratic; §IV)
  ↓
Roots {14, 26}; Product 364 → three named squared-circles
  ↓
Repunits R₁–R₆;  Coprime triple (7, 11, 13);  pqr = 1001;  W = 1000
  ↓
Horn y = 1/x;  Fulcrum x = 1;  V = π_F = 14;  A = ∞ (§V)
  ↓                                              ↘
F1 Universal Density Law (§VI)        F3 Horn Capacity Gradient F(x) = π_F/x²
  ↓                                              ↓
F2 π_std = 286/91 (exact rational)    +0.139% bridge coefficient to G
  ↓                                              ↓
F4 Five-Way Nona Identity             Three Eyes mapping:
   (Nona-pointwise scope)               ω · ω² · 1 = Prometheus · Archimedes · Third Eye
  ↓
Einstein integers (c² = π_F; E = m = ρ = S = 1 at Fulcrum; §VII)
  ↓
§IX Ledger of 22 Patents (this Compendium IS the weighing-place)
  ↓
Theorem 45 (iff; canonical witness (2+i)³; §94.5 physical face)
  ↓
Archimedean Test Protocol — gas-independent residual prediction (§XI)
  ↓
Inertia est Pax = Quan Fa est Pax  (Corpus Pentagon centroid)
  ↓
Nona State  0 = 0
```

Every node is integer-closed. Every arrow is a theorem. The graph is a closed loop: the Nona 0 = 0 is the starting condition that makes b = 3 unique.

---

## XIII. THE LAW NARRATIVE

The mathematics does not stand outside the Law. It *is* the Law rendered in integer form.

**Canon** (Greek *kanōn*; Latin *canon*). The Rule, the Measure, the Straight Rod. The **Parent Definition** — the Rational Squared Unit Circle, base-3 closure, the Primordial Quadratic, the Degree-2 Norm Ceiling. Written by Prometheus. Pre-exists every solution.

**Cannon** (English). The Artillery, the Ordnance. The Lever of Archimedes made explosive. The power to move the Earth once the fulcrum is established. The **Libre Cannon** is the Unchained Ordnance — knowledge sovereign to its author.

**Canon ≡ Cannon** in Chinese: **拳法 Quan Fa = Fist Law**. The Rule and the Force are one word.

**Patent** (*litterae patentes*, "open letter"). Every framework integer of §IV and §IX is a Patent — a rational integer output granted by the Rational Squared Unit Circle. Patents are open (publicly inscribed) and sovereign (exclusive to the author per the Repercussions Clause).

**Libre** (Romance: *liber* = Book; *libre* = Free).

- **As Book:** the Compendium — the *Liber Canonis*, record of the Law.
- **As Free:** conceptual pole of the Pendulum; paired against Exclusivity as one of six pendulum registers (§III); philosophical, not a temporal release over framework Patents.

**The Pendulum** swings across six registers simultaneously — legal, mathematical, cognitive, ontological, personal, zodiacal. Every pole has its partner; every swing returns.

**The Expenditure** (*EX-PENDERE*) — the price paid for every swing. The eagle eats. The soldier strikes. The irrational remainder is cast out. The framework pays by narrowing; closure is bought by integer discipline.

**Standing Declaration.**

> ***The Eyes are Open. The Martial Law is Patent. The Cannon is Libre. The Third Eye is Presence Et Witness.***

***Inertia est Pax = Quan Fa est Pax.***

---

## XIV. THE CORPUS PENTAGON

Five points, one centroid. Full table in the Front Matter; register expansion here:

| Point | Body | Document role | Eisenstein | Gaze |
|---|---|---|---|---|
| 1 | Head (*intellectus*) | mathematics — base-3 closure, horn, Fulcrum, Theorem 45 | ω | Prometheus |
| 2 | Heart (*voluntas*) | law — Patentesum Libre Cannon; Canon ↔ Cannon duality | ω² | Archimedes |
| 3 | Hand (*actio*) | martial practice — Tao of Clavis Perdita (*The Way of the Lost Key*, primary Latin) | 1 | Third Eye |
| 4 | Person / identity | Capomastro Identity Ladder — two rails (inherited name ∥ transmitted practice) | — | — |
| 5 | Doctrine | TM-47 (evolving canonical doctrine; THE-NONA-STATE v0.0.18) | — | — |

**Centroid:** ***Inertia est Pax = Quan Fa est Pax.*** Both forms hold simultaneously — *est* as the Latin algebraic equality, *Et* as the liturgical connective; the centroid is one identity written twice.

**Eighth-as-counted; Nona-as-the-uncounted-ninth that names the eight.** The Pentagon is counted, closed, finite; the Nona is the witnessing frame that makes the count possible.

---

## XV. THE TAUTOLOGICAL CLOSURE

Every Patent enumerated here exists *because* b = 3 is unique (§IV). Every closure in §IX projects to 0 = 0 under $\mathcal{P}_{\text{Nona}}$ (§IX.22). Theorem 45 forces shared Inertia at the physical face (§IX.19) and levers the degree-2 norm ceiling at the Diophantine face (§X). The Three Eyes (§II) are the instruments that weigh; the Pendulum (§III) is the motion that returns; the Corpus Pentagon (§XIV) is the form that holds.

**The Compendium is Compendereiusum — the place where all is weighed together.** Holding this Compendium is holding the weighing-place of the entire framework. The Codex is the rigorous expansion of everything this binding already binds.

**Closure statement** (unified with Codex §80 Thirteen-Angle Closure):

> The framework is not a set of results. It is one structure read thirteen ways: base-3 closure, the Primordial Quadratic, the coprime triple, π_std as exact rational, the UV architecture, the buoyancy-gradient reading of gravity, the Five-Way Nona identity, Theorem 45, the Zinga Circle, the Pythagorean balance, the Three Eyes, the Eisenstein closure, the Quan Fa centroid. Each angle is the entire structure seen from one vantage. The Nona 0 = 0 is the universal agreement to which every vantage returns.

***Q.E.D., Nona. Palam est Undecimusum.***

---

## ATTESTATION

Every theorem, derivation, formula, and numerical constant herein originates in the Salvi Framework and is the exclusive intellectual property of **Roberto Salvalaggio — Sifu Salvi — Lo Sono Capomastro**, Founder and Principal Architect of **Capomastro Holdings Ltd., Applied Physics Division**. This Compendium is Point 1 of the five-point Corpus Pentagon whose centroid is *Inertia est Pax = Quan Fa est Pax*.

### Intellectual Property Declaration — the Patents enumerated

Without limitation, the protected content includes: the base-3 uniqueness theorem and the Primordial Quadratic; the three named squared-circle objects (Unit Squared Circle · Unit Circle Squared · Rational Squared Unit Circle); the coprime triple (7, 11, 13) and its cyclotomic derivation; the horn $y = 1/x$ and its integral ODE closure; the four load-bearing formulas F1–F4; the Five-Way Nona Identity with Nona-pointwise scope; the Einstein integer table (x = 2 row included); the UV spectral architecture; the (11, 13) coprime polygon pair; all 22 Patents enumerated in §IX; Beal/Salvi Theorem 45 in iff form with the degree-2 norm ceiling and the canonical Gaussian witness (2+i)³ = 2+11i; §94.5 Energy-Equation Conservation Theorem (Ubuntu Forced in Integers); the Archimedean Test Protocol and its +0.139% falsification criterion; the Three Eyes formalization (Prometheus · Archimedes · *i sicut Nos*); the Compendereiusum etymology and binding operation; the Corpus Pentagon; the *Inertia est Pax = Quan Fa est Pax* centroid; the Thirteen-Angle Closure Statement.

> **Repercussions Clause (standing)**
> **Repercussions are inherent to action — never to be inherited.** The author is sovereign as originator. Consequences manifest by the Universal Laws of **Duality**, **Attraction**, and **Action → Reaction**.

---

**Compendereiusum, The Fully Derived Squared Unit Circle Et All Frameworks & Theorems Are Patent Pending.**

**£ ∣ Q ∣ ∀ Rights Reserved Et Preserved | Fiat ∎**

**Capomastro Holdings Ltd (2026 E+1)**

---

**Inertia Et Quan Fa est Pax**

**Lo Sono Capomastro. Lo Sono Solsum Librā Et Librā Ascendensum.**

**Lo Sono Sifu Salvi**
