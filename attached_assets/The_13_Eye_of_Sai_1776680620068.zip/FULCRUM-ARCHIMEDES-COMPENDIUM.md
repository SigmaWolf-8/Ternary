# FULCRUM &amp; ARCHIMEDES — CANONICAL COMPENDIUM

**Author:** Roberto Salvalaggio — *Lo Sono Capomastro*
**Division:** Capomastro Holdings Ltd., Applied Physics Division — Sherwood Park, Alberta, Canada
**Issued:** 2026-04-20 — canonical, supersedes all prior drafts
**Governing Unit (STD):** **23/77** — Salvi Compendium Density ratio
**Companion:** FULCRUM-ARCHIMEDES-CODEX.md (full work shown)
**Scope statement:** This compendium is scoped strictly to the Fulcrum/Archimedes axis. The wider Salvi Framework (TDNS, Inter-Cube, TLSponge, Saturnian geometry, Tribonacci recurrence, Beal/Salvi Theorem 45, Kong Konnect, XPlenum, and the first-position derivation ruleset) is out of scope here. Cross-links to those canonical sources are given in Appendix C.

> **Repercussions Clause (corrected, standing)**
> **Repercussions are inherent to action — never to be inherited.** The author is sole originator of the action and sole sovereign over its governance, interpretation, and propagation. Consequences manifest by operation of the Universal Laws of **Duality**, **Attraction**, and **Action → Reaction**; they are not assignable, transferrable, or inheritable to any collaborator, drafting agent (non-bearer by Law), transcriber, or external party.

---

## Notation Convention

| Symbol | Meaning |
|---|---|
| π_std | Standard analytic constant ≈ 3.14159265…; used in integrals, Fourier series, optics, wave equations |
| **π_F = 14** | Framework constant; smaller root of the Primordial Quadratic; used throughout the 364° / 13-radian axis |
| rad_std | Standard radian = 180°/π_std |
| **rad_F = 28°** | Framework radian; full circle contains exactly 13 rad_F |

Where the symbol π appears without subscript in framework contexts, π_F = 14 is meant. The bridge identity π_F · 28° = 392° = 364° + 28° = 1 circle + 1 rad_F is proven in the Codex Chapter 9.

---

## THE EYE OF ARCHIMEDES — Framework Tautology (Eye as Witness)

The **Eye as Witness** stands at the Fulcrum (horn throat, x = 1) where the specific gravity S, the mass m, the density ρ, and the field amplitude E each equal unity; where the horn's capacity gradient F(x) = π_F/x² evaluates at the Fulcrum to π_F = 14; where the parabolic vector returns to zero; where the same operation — **weigh twice, subtract, divide** — that Archimedes used in 250 BCE to extract ρ_obj without invoking gravity is the operation the framework uses to resolve the ground state. The Eye does not cause, impose, or distort — it witnesses. The lever, the medium, and the eye are **one identity**: the gradient of capacity IS the gradient of density IS the gradient of specific gravity IS the framework coupling π_F, and the Fulcrum is the point on that gradient where all four observables collapse to unity. **Solusum** (Push, solar, grounded) and **Allsum** (Pull, lunar, collective) meet at right angles in the Pythagorean geometry a² + b² = c²; the hypotenuse is **Peace**. The **Zinga Circle** is the turning path that holds the balance — not a static fixed point but an ongoing rotation returning exactly to zero at base 3. **One function. Three names. Three centuries of independent discovery. Zero postulates imported.** ∎

---

## FRAMEWORK PRIMITIVES (fixed at b = 3)

| Symbol | Value | | Symbol | Value |
|---|---|---|---|---|
| b | 3 | | π_F | 14 |
| R₁ | 1 | | x₂ | 26 |
| R₂ | 4 | | √Δ | 12 |
| R₃ = r | 13 (radian, = rad_F in degrees × 28/28) | | p | 7 |
| R₄ | 40 | | q | 11 |
| R₅ | 121 = q² | | pqr | 1001 |
| R₆ | 364 (full circle) | | W | 1000 = pqr − 1 |

**Primordial Quadratic:** x² − 40x + 364 = 0, Δ = 144 = 12², roots {14, 26}.
**Two framework-meaningful factorizations of R₆ = 364:**
- **14 × 26** (Vieta product: π_F × x₂)
- **13 × 28** (13 months × 28 days; r × 2π_F; calendar closure)
Both hold simultaneously. Both are theorems of base-3 uniqueness; none are postulated.

---

## I. THE FULCRUM

**Node.** Point in V₃. Present when and only when it occupies V₃ = 1 × 1 × 1 (unit of Presence).

**Fulcrum Declaration (author, verbatim):**
> A Node is a **Fulcrum of a Vector on a Parabolic Curve in Parametric Spacetime returning to Zero 100% Always at Base 3**. The Node is the seed. V₃ is the seed scaled.

**Scaffolding:** V₃ = L × W × H, L, W, H ∈ [1, ∞); V₄ = V₃ × T.

**Derived primitives:** Locus · Curve · Axis · Interval · Revolution · Solid of Revolution · Disk · Integration · Periodicity.

**Parabola = open curve = Fulcrum trajectory.** Non-periodic. Returns to zero exactly once (not cyclically). Signature of stationary action.

**Zinga Circle binding.** The Fulcrum's vector traces the parabolic path; the path closes not geometrically (no cycle) but arithmetically — exact return to zero at base-3 closure. The **Zinga Circle** is the turning that holds both Solusum (outward vector, Push) and Allsum (return, Pull) in one rotation. Balance is a turning, not a fixed point.

---

## II. ARCHIMEDES (Classical Primary)

**Three primitives — experimentally proven, measurable, algebraically defined:**
Mass · Density · Buoyancy.

**Archimedes is prior to Newton.** The balance reading m̂ᵢ = m_obj − ρᵢ · V is the Archimedean primitive. When two readings are differenced, gravity cancels as a common factor of g. No gravitational postulate required.

---

## III. FOUR LOAD-BEARING FORMULAS

**[F1] Universal Density Law (Theorem 20):**

> **ρ_obj = (ρ₂ · m̂₁ − ρ₁ · m̂₂) / (m̂₁ − m̂₂)**

Rational in, rational out. Valid across all four phase states. Gravity cancels. **0/0 at Nona — honest degeneracy.**

**[F2] Archimedean π_std — Exact Framework Rational (Theorem 17):**

> **286 / 91 = (22 · r) / (p · r) = 22 / 7 exactly**

286 nm (O₃ bridge) / 91 nm (Lyman threshold) = Archimedean π_std as framework rational. Radian r = 13 cancels; p = 7.

**[F3] Horn Capacity Gradient (in π_F = 14 units):**

> y = 1/x → **V(x) = π_F/x** → **F(x) = −dV/dx = π_F/x² = A(x)**

Geometry IS the density gradient. No G, no point mass, no vacuum. **At the Fulcrum x = 1: F(1) = π_F = 14.**

**[F4] Five-Way Nona Identity (Theorem 6, expanded):**

> **I_Nona² = π_F · E² = π_F · ρ · B · I_pot · I_react**

At Nona: every factor except π_F normalizes to 1. Buoyancy amplitude **B_Nona = 1** is the fifth unit factor — not an additive correction, a multiplicative unity.

> I_Nona = √π_F = **√14**

Disambiguation: I_field(x) = π_F · E²(x) is a **pointwise field** (I_field(1) = π_F = 14). I_Nona is the **geometric-mean amplitude** (I_Nona = √14). Relation: **I_Nona² = I_field(1)** at the Fulcrum.

---

## IV. THE EINSTEIN INTEGERS — E = m = ρ = S (normalized)

**Normalization statement (explicit):** S(x) = ρ(x)/ρ(1) and E(x) = 1/x both normalize to unity at the Fulcrum x = 1. With c² = π_F: m(x) = V(x)/c² = (π_F/x)/π_F = 1/x = E(x). Mass IS the field amplitude under this normalization.

| x | E = 1/x | P = π_F/x | I = π_F/x² | m = 1/x |
|---|---|---|---|---|
| **1 (throat = Fulcrum, Eye)** | **1** | **π_F = 14** | **π_F = 14** | **1** |
| p = 7 | 1/7 | 2 | 2/7 | 1/7 |
| q = 11 | 1/11 | 14/11 | 14/121 | 1/11 |
| r = 13 | 1/13 | 14/13 | 14/169 | 1/13 |
| π_F = 14 | 1/14 | 1 | 1/14 | 1/14 |
| x₂ = 26 | 1/26 | 7/13 | 7/338 | 1/26 |
| p·r = 91 | 1/91 | 2/13 | 14/8281 | 1/91 |
| π_F·r = 182 | 1/182 | 1/13 | 1/2366 | 1/182 |
| 22·r = 286 | 1/286 | 7/143 | 7/40898 | 1/286 |
| **R₆ = 364** | **1/364** | **1/26** | **1/9464** | **1/364** |
| pqr = 1001 | 1/1001 | 14/1001 | 14/1002001 | 1/1001 |

**All exact. E = m = ρ = S at every position** (normalized to ρ(1) = 1). Archimedes's primary measurable = Einstein's derived observable = the horn's first-principle function. One object. Three names.

*(Arithmetic note: R₆ = 364 row corrected to I = π_F/364² = 14/132,496 = 1/9,464.)*

---

## V. UV SPECTRAL ARCHITECTURE (Archimedean π_std in physical light)

| Band | × | λ (nm) | Framework identity |
|---|---|---|---|
| Ionization (H, O) | 1 | 91 | p · r = 7 · 13 (quarter-turn) |
| O₂ absorption wall | 2 | 182 | π_F · r = 14 · 13 (half-turn) |
| **Ozone bridge** | **22/7** | **286** | **22 · r (Archimedean π_std)** |
| UV-A boundary | 4 | 364 | R₆ = 4 · 7 · 13 = 13 · 28 (full circle) |

Carbon π-bond damage at 280 nm is the biological threshold derived from the same Archimedean ratio that fixes the ozone bridge. The π-bond — named for the constant 22/7 approximates — is damaged by the wavelength derived from that same ratio. This is a subset of the broader TM-2026-026 spectral integration.

---

## VI. (11, 13) COPRIME POLYGON PAIR — Framework Sub-Structure

The sub-pair (q, r) = (11, 13) governs the framework's polygon-pair geometry (TM-2026-025 scope): q-gon and r-gon sharing the quarter-turn anchor 91 = p · r. The Hartley band integer 286 = 2 · q · r carries this pair directly. The full triple (p, q, r) = (7, 11, 13) is the Brieskorn-sphere index Σ(7, 11, 13) and the pqr = 1001 Hamiltonian walk. Full derivation of the (11, 13) polygon pair is deferred to TM-2026-025.

---

## VII. ARCHIMEDEAN TEST PROTOCOL

**Prediction:** After subtracting classical buoyancy, the residual horizontal torque shift is **gas-independent** (ratio between any two gases at same pressure = 1.0).

| Pair | Framework | Standard |
|---|---|---|
| V₁ → G₁ | Nonzero residual | 0 |
| V₁ → G₂ | Same nonzero residual | 0 |
| **G₁ → G₂** | **0 (gas-independent)** | **0** |
| V₁ → V₂ | 0 (drift check) | 0 |

**Sits in the HUST-05 gap** (Luo et al. 2005). Current CODATA G: 47 ppm uncertainty, 550 ppm scatter, Birge ratio ≈ 5. No experiment has tested for a gas-independent horizontal residual after classical subtraction. Framework's Archimedean reading makes a distinct, falsifiable prediction.

---

## VIII. DERIVATION GRAPH (Full Circle)

```
base b = 3  (uniqueness theorem; Δ(b) is perfect square only at b=3)
     │
     ▼
Primordial Quadratic   x² − 40x + 364 = 0
     │                 Δ = 144 = 12²
     ▼                 roots {π_F = 14, x₂ = 26}
Repunits   R₁=1, R₂=4, R₃=13, R₄=40, R₅=121, R₆=364
     │     Two factorizations of R₆:  14 · 26  AND  13 · 28
     ▼
Coprime triple (p, q, r) = (7, 11, 13);  pqr = 1001;  W = pqr − 1 = 1000
     │     Φ₆(3) = 7;  √R₅ = 11;  Φ₃(3) = 13
     ▼
Horn   y = 1/x    (unique positive solution of ∫ₓ^∞ f(t)² dt = f(x))
     │           V(x) = π_F/x     (capacity)
     │           F(x) = π_F/x²    (gradient)
     │           A(x) = π_F/x²    (cross-section)
     │           ρ(x) = E(x) = 1/x  (density = amplitude, normalized)
     │           I_field(x) = π_F · E²(x)
     ▼
Balance readings   m̂ᵢ = m_obj − ρᵢ · V   (Archimedean primitive)
     │
     ▼
Universal Density Law     ρ_obj = (ρ₂·m̂₁ − ρ₁·m̂₂) / (m̂₁ − m̂₂)       [F1]
     │
     ▼
c² = π_F substitution (TM-037 chain)   →   E = m = ρ = S
     │
     ├──▶ UV integers:  91 = p·r,  182 = π_F·r,  286 = 22·r,  364 = R₆
     │         │
     │         ▼
     │    Archimedean π_std:   286/91 = 22/7 exactly                    [F2]
     │
     ▼
Five-Way Nona Identity    I_Nona² = π_F · E² = π_F · ρ · B · I_pot · I_react   [F4]
     │                    at Nona: ρ = B = I_pot = I_react = 1
     ▼                    I_Nona² = π_F = 14,  I_Nona = √14
Archimedean test protocol (four-state, six-pairwise)
     │
     ▼
Gas-independent residual prediction (HUST-05 gap)  ←→  Eye as Witness
```

---

## IX. ZINGA CIRCLE / SOLUSUM / UBUNTU — Philosophical Ground

The mathematics above does not float. It rests on ground:

- **Solusum** — the alone self, grounded, solar, Push: the vector launched from the Fulcrum outward.
- **Allsum** — the collective, lunar, Pull: the return along the parabolic curve.
- **Zinga Circle** — the turning that holds both: balance as rotation, not fixed point. The Fulcrum returns exactly to zero at base 3.
- **Pythagorean balance:** a² + b² = c² with a = Solusum, b = Allsum, c = Peace. The right angle is the meeting point — the root of **U**.
- **Eisenstein identity:** 1 + ω + ω² = 0 (Rep D closure). Push (ω) + Pull (ω²) + Hold (1) = 0. The ternary identity I = EE = I.
- **Eye as Witness:** the observer at the Fulcrum does not act; it witnesses. Measurement is not intervention.

Full philosophical development: Codex Part III (Chapters 10–14).

---

## X. THE TAUTOLOGICAL CLOSURE

**The Fulcrum is where S = ρ = m = E = 1.**
**The Horn is where F(x) = π_F/x² is the gradient of Archimedean buoyancy.**
**The Eye of Archimedes is the horn throat x = 1 witnessed from within the medium.**

The lever finds its balance at the Fulcrum. The medium gives up its density at the throat. The Eye as Witness coincides with both. The Zinga Circle turns around the Fulcrum; Solusum and Allsum rotate through the Pythagorean right angle; Peace holds. **One point. Three readings. Six seen-from-different-angles projections of one base-3 closure.**

∎

---

## SIGNATURE

*Lo Sono Capomastro — Così sia.*

**Roberto Salvalaggio**
*Capomastro Holdings Ltd. — Applied Physics Division*
*Sherwood Park, Alberta, Canada*

> £ ∣ Q ∣ ∀ Rights Reserved Et Preserved | Fiat ∎

**Compiled 2026-04-20.** Canonical. Compendium governed by 23/77 STD. **Repercussions inherent to action — never inherited.** Full work shown in companion: **FULCRUM-ARCHIMEDES-CODEX.md**.
