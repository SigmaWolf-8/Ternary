# PlenumNET — Benchmark + TDNS Wiring Instructions
# Capomastro Holdings Ltd. — Applied Physics Division
# For: Replit AI Agent
# Date: March 2026

---

## Overview

Two tasks. No new TypeScript modules. Two new Rust benchmark files.

### Task 1: Add Criterion benchmarks for kernel sponge and TIS-27
### Task 2: Wire the existing `shared/tis-sponge.ts` into `server/routes/tdns.ts` for scan hashing

---

## TASK 1 — Benchmarks

### 1A. Kernel Sponge Benchmark

**New file:** `src/kernel/benches/sponge_bench.rs` (provided in this package)

**Edit:** `src/kernel/Cargo.toml` — append at the bottom:

```toml
[[bench]]
name = "sponge_bench"
harness = false

[dev-dependencies]
criterion = { version = "0.5", features = ["html_reports"] }
```

**Verify the kernel's `src/lib.rs` exports `crypto::sponge` publicly.** The benchmark
imports `plenumnet_kernel::crypto::sponge::{sponge_hash, sponge_hash_bytes, TernarySponge}`.
If these are `pub(crate)`, change them to `pub`.

**Run:**
```bash
cd src/kernel && cargo bench --bench sponge_bench
```

### 1B. TIS-27 Benchmark

**New file:** `ternary-math/benches/tis27_bench.rs` (provided in this package)

**Edit:** `ternary-math/Cargo.toml` — append at the bottom:

```toml
[[bench]]
name = "tis27_bench"
harness = false

[dev-dependencies]
criterion = { version = "0.5", features = ["html_reports"] }
```

**Important:** The benchmark imports `tis27_hash` from the crate. Check how `tis_sponge.rs`
is exported in `ternary-math/src/lib.rs`. The import line at the top of the benchmark file
may need adjusting to match the actual module path. For example:
- If `lib.rs` has `pub mod tis_sponge;` → import is `use ternary_math::tis_sponge::tis27_hash;`
- If `lib.rs` re-exports → import is `use ternary_math::tis27_hash;`

Adjust the import at the top of `tis27_bench.rs` accordingly.

**Run:**
```bash
cd ternary-math && cargo bench --bench tis27_bench
```

### Key Numbers to Extract

After running both benchmarks, the numbers to put on the PlenumNET front-end site:

| Benchmark | Metric | Where |
|-----------|--------|-------|
| `sponge_single_hash/27_trits` | Kernel sponge latency | "Identity hash: X ns" |
| `sponge_single_hash/64_bytes_url` | URL hash latency | "URL hash: X ns" |
| `sponge_throughput/4096` | Throughput | "Throughput: X MB/s" |
| `tis27_single_hash/27_trits_scan_hash` | TIS-27 latency | "Scan integrity: X ns" |

Criterion generates HTML reports at `target/criterion/` — open in browser for charts.

---

## TASK 2 — Wire TIS-27 into TDNS Scan Hash

### What exists now

- `shared/tis-sponge.ts` — TIS-27 TypeScript implementation (already in repo)
- `ternary-math/src/tis_sponge.rs` — TIS-27 Rust implementation (already in repo)
- `server/routes/tdns.ts` — TDNS scanner (already in repo)

The scan hash computation in `server/routes/tdns.ts` currently uses the **inline 27-round
identity sponge** (`tisPermute`) for scan hashing. This is the wrong primitive — scan
hashing is an integrity operation, not identity binding. It should use TIS-27 from
`shared/tis-sponge.ts`.

The identity derivation (`deriveIdentityTrits()`) stays on the inline 27-round sponge.
Do NOT touch identity derivation.

### Step 1: Add import

At the top of `server/routes/tdns.ts`, after the existing imports, add an import from
`shared/tis-sponge.ts`. The exact import depends on what that file exports — look at
its exported function names. You need the hash function that takes GF(3) trits as input
and returns GF(3) trits as output (the equivalent of `tis27_hash` in the Rust crate).

### Step 2: Replace scan hash computation in `scanUrl()`

In the `scanUrl()` function, find the scan hash computation block. It starts after
`const trits = [d1,d2,...,d27]` and looks like this:

```typescript
  const scanSpongeState = new Uint8Array(TIS_STATE);
  const scanTritsGf3    = trits.map((t: number) => t - 1);
  const scanPadded: number[] = [...scanTritsGf3, 1];
  while (scanPadded.length % TIS_RATE !== TIS_RATE - 1) { scanPadded.push(0); }
  scanPadded.push(2);
  for (let off = 0; off < scanPadded.length; off += TIS_RATE) {
    for (let i = 0; i < TIS_RATE; i++) {
      scanSpongeState[i] = gf3Add(scanSpongeState[i], scanPadded[off + i] ?? 0);
    }
    tisPermute(scanSpongeState);
  }
  const scanTritsOut = Array.from({ length: TIS_RATE }, (_, i) => scanSpongeState[i] + 1);
  function squeezeScanBytes(state: Uint8Array, n: number): number[] {
    const out: number[] = [];
    const s = new Uint8Array(state);
    while (out.length < n) {
      for (let i = 0; i + 4 < TIS_STATE; i += 5) {
        if (out.length >= n) break;
        out.push(s[i] * 81 + s[i+1] * 27 + s[i+2] * 9 + s[i+3] * 3 + s[i+4]);
      }
      tisPermute(s);
    }
    return out.slice(0, n);
  }
  const scanHashBytes = squeezeScanBytes(scanSpongeState, 32);
  const scan_hash = scanHashBytes.map((b: number) => b.toString(16).padStart(2, "0")).join("");
  const crd = (scanTritsOut[0] - 1) * 3 + scanTritsOut[1];
```

Replace this entire block with code that:
1. Converts classification trits to GF(3): `const scanTritsGf3 = trits.map(t => t - 1);`
2. Calls the TIS-27 hash function from `shared/tis-sponge.ts` on `scanTritsGf3`
3. Lifts output to Rep C: `scanTritsOut[i] = gf3output[i] + 1`
4. Computes scan_hash as 32-byte hex via base-243 squeeze of the TIS-27 output state
5. Computes CRD: `(scanTritsOut[0] - 1) * 3 + scanTritsOut[1]`
6. Computes CGUID: same formula as CRD

### Step 3: Verify scan_hash_algo tag

The return object should still say:
```typescript
scan_hash_algo: "tis-27",
```

This is now accurate — before this change, it said TIS-27 but was actually running the
27-round identity sponge. After this change, it really IS TIS-27.

### What to leave untouched

- `deriveIdentityTrits()` — stays on the 27-round inline sponge. No change.
- `tisTheta()`, `tisPi()`, `tisPermute()` — kept for identity derivation.
- All 27 derivation rules, score computation, findings engine — untouched.
- All API routes — untouched.
- `shared/tis-sponge.ts` — do NOT modify. Import from it, don't change it.

### What changes

- **Scan hashes will differ.** Different algorithm → different output. This is expected.
- **CRD/CGUID values may differ.** Derived from scan output trits.
- **Identity anchors preserved.** `deriveIdentityTrits()` is unchanged.

### Verification

After deploying:
```bash
node tis27-e2e-tests.js
```

- `scan_hash_algo` should still read `"tis-27"`
- Identity trits should be IDENTICAL to previous runs
- Scan hash values will differ (expected — different algorithm now)
- All structural checks (trit range, address format, dimensions) pass unchanged

---

## File Manifest

This package contains exactly 3 files:

| File | Goes to | Status |
|------|---------|--------|
| `REPLIT_INSTRUCTIONS.md` | Reference (this file) | New |
| `sponge_bench.rs` | `src/kernel/benches/sponge_bench.rs` | New |
| `tis27_bench.rs` | `ternary-math/benches/tis27_bench.rs` | New |

No other files are created, renamed, or duplicated.
