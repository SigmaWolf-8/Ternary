# ternary-math CI Matrix

## Rust Version
- **MSRV**: 1.77.0
- **Stable**: latest stable (primary)
- **Nightly**: optional, for Kani/MIRI proofs only

## Target Triples

| Target | Features | Build | Test | Expected Duration |
|--------|----------|-------|------|-------------------|
| `x86_64-unknown-linux-gnu` | default (parallel) | ✅ | ✅ | ~90s |
| `x86_64-unknown-linux-gnu` | no-default-features | ✅ | ✅ | ~60s |
| `aarch64-unknown-linux-gnu` | default | ✅ | cross | ~120s |
| `wasm32-unknown-unknown` | no-default-features | ✅ | wasm-pack test | ~45s |

## Pipeline Steps

```
1. cargo fmt --check
2. cargo clippy --all-targets -- -D warnings
3. cargo build --locked --release
4. cargo test --locked
5. cargo test --locked --no-default-features
6. make wasm
7. make audit
8. cargo tree --edges=normal | grep -E "rsa|sha2|aes-gcm" → must be empty
```

## WASM-Specific
- **wasm-pack**: >= 0.13.1 (pin in CI with `cargo install wasm-pack --version 0.13.1`)
- **Build command**: `wasm-pack build --target web --no-default-features --release`
- **Smoke test**: `wasm-pack test --headless --chrome --no-default-features`

## Benchmarks
- Run on tagged releases only (not every PR)
- Targets: `inter_cube`, `ttc_benchmark`, `crypto_benchmarks`
- Duration: ~5 min total on x86_64
