# Phase 6 — Heap Path for Large TritInt Values

## What Was Built

The heap allocation path for TritInt values exceeding R₄ = 40 trits. Runtime arithmetic now transparently handles values of arbitrary size.

## File

| File | Destination | Lines | Tests |
|------|------------|-------|-------|
| `trit_int.rs` | `ternary-math/src/trit_int.rs` | 2,643 | 94 |

This is the ONLY file that changes in Phase 6. All other files (trit.rs, ags.rs, tri182.rs, lib.rs, Cargo.toml) are unchanged.

## What Changed

### TritIntStorage::Heap variant
- `Heap { packed: Zeroizing<Vec<u8>>, trit_count: u32 }` added to the enum
- `Zeroizing<Vec<u8>>` from the zeroize crate — automatically zeros buffer on drop
- `trit_count: u32` — host bookkeeping field for trit count (u32 instead of inline's u8)
- TritInt remains Clone-only (never was Copy)

### Dynamic helper functions (new)
- `trit_at_gen(&[u8], u32)` — extract trit from any-size packed slice
- `add_gen`, `sub_gen`, `mul_gen` — arithmetic on packed slices, auto-promote result to heap if > 40 trits
- `lt_gen`, `eq_gen` — comparison on packed slices
- `to_u64_gen` — boundary crossing with overflow detection
- `trit_shift_left_gen` — shift for division
- `pack_trits`, `make_from_packed`, `make_from_trits` — result construction (auto inline/heap)

### Shared internal API
- `packed_slice(&self) -> &[u8]` — unified slice view for both inline and heap
- `count(&self) -> u32` — trit count as u32 for both variants
- `parts()` retained for const-path backward compat (panics on heap)
- `into_parts()` retained for const fn (inline-only)

### Runtime arithmetic — no more overflow panics
- `add`, `sub`, `mul` — use dynamic helpers, auto-promote to heap
- `div_mod` — rewritten with dynamic helpers for arbitrary-size operands
- `add_with_carry` — updated for heap
- `pow`, `gcd`, `extended_gcd`, `mod_pow` — work via updated add/sub/mul/div_mod
- `const_add`, `const_mul` — UNCHANGED (inline-only, asserts remain)

### Shrink-to-inline
- `make_from_packed` automatically converts result back to inline when ≤ 40 trits
- Old heap buffer zeroed via Zeroizing drop before deallocation
- Shrunk values are PartialEq and Hash-identical to direct inline construction

### Updated traits
- Display, Debug, PartialEq, Ord, Hash — all work via packed_slice()/count()
- Hash produces identical results for inline and heap representations of same value

### Updated repr conversions
- to_repr_a/b/c/d — work via packed_slice()/count()
- try_from_repr_c — upper bound changed from R₄=40 to R₉=9,841 trits

### Updated Zeroize
- Heap variant: calls zeroize() on Zeroizing<Vec<u8>> contents, sets trit_count to 0
- Inline variant: unchanged

### Boundary crossings
- to_u128() — handles heap values up to 80 trits (3^80 < u128::MAX)
- to_u64() — returns Err(Overflow(64)) for values > 40 trits
- to_decimal() — panics with descriptive message for heap-sized values

## Verification

```bash
cargo test --workspace
cargo test --workspace --features serde
cargo build --target wasm32-unknown-unknown --no-default-features
cargo build --target wasm32-unknown-unknown --no-default-features --features serde
```

## Phase 6 Tests (12 new tests)

- Large multiplication (3^20 × 3^20 = 3^40, 41 trits, heap)
- pow(3, 50) — 51 trits on heap
- Heap shrinks to inline after division
- Hash identity: heap-then-shrink == direct inline
- Rep C round-trip for heap values
- Heap add/sub round-trip
- Heap comparison (< and >)
- Heap Display formatting
- Zeroize clears heap value
- Heap to_u128 (3^50 fits in u128)
- Heap to_u64 overflow (3^50 > u64::MAX)
- try_from_repr_c accepts 50-trit input (heap), rejects 9842 (> R₉)
