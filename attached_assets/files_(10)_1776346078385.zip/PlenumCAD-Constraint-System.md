# PlenumCAD — Unified Constraint System
## Formal Logic Specification

**Capomastro Holdings Ltd. — Applied Physics Division**
*Draft 1 — April 16, 2026*

---

## 1. Definitions

**Cell.** A region of space bounded by four edges (2D) or six faces (3D). A cell has:
- A position in its parent's coordinate system
- Edge identities (shared with neighboring cells)
- A content reference (what the cell represents — wall, cabinet, part, operation, etc.)
- A mode (Variable | Fixed | Presentation | Plasma, per Forma Codex §3)
- A scale (which level of the cascade it lives at)

**Edge.** A boundary between two cells OR between a cell and the outer frame. An edge has:
- Two cells it separates (or one cell and null for frame edges)
- A position (computed from the constraint solver)
- A constraint state: free, locked, or contested

**Shared Border Zero-Gap Rule.** For any two adjacent cells A and B, the right edge of A is the left edge of B. They are the SAME edge object. There is no gap. There is no overlap. The edge has exactly one position, and both cells reference it.

**Assembly.** A cell whose content reference is itself a grid of cells. Assemblies nest recursively up to depth 5 (the 729→243→81→27→9→3 cascade from Forma Codex §17).

**Variable.** A named value with a source (Catalog | Project | Component | Computed) that participates in constraint evaluation. Variables are never hardcoded in the engine — they come from the catalog database and flow through the override chain.

---

## 2. The Cascade

Five depth levels, each a nested cell grid. Each level has its own variable set but uses the SAME constraint engine.

| Depth | Name | Cell Content | Example Variables |
|---|---|---|---|
| 0 | Project | Rooms | `ceiling_height`, `floor_elevation`, `construction_type` |
| 1 | Room | Walls | `wall_thickness`, `ceiling_height`, `door_openings[]` |
| 2 | Wall | Cabinets & Assemblies | `reveal`, `filler_min_width`, `scribe_allowance` |
| 3 | Cabinet/Assembly | Parts (or nested sub-assemblies) | `box_material`, `door_overlay`, `toe_kick_height` |
| 4 | Part | Machining operations | `hole_spacing`, `hole_diameter`, `edge_setback` |
| 5 | Operation | Tool path geometry | `tool_diameter`, `feed_rate`, `depth_per_pass` |

**Invariant:** The constraint engine is identical at every depth. Only the variables differ.

---

## 3. The Four Invariants

### Invariant 1: Zero-Gap Edge Identity

For any cell C at any depth, let `edges(C) = {top, right, bottom, left}` (2D) or `{top, bottom, north, south, east, west}` (3D).

For any two adjacent cells A and B sharing boundary direction d:
```
edge(A, d) ≡ edge(B, opposite(d))
```
They are identical objects. A change to one IS a change to the other. There is no "gap parameter" to configure. There is no "overlap tolerance" to tune.

**Consequence:** Anti-collision is structural, not computed. Two cabinets cannot overlap because their shared edge is one object. Two parts cannot collide because the operations that generate them reference the same edge.

### Invariant 2: Flex/Grow/Squeeze Distribution

For a row of N cells with total available width W and per-cell constraints:
- `min_width[i]` — minimum width for cell i (from cell mode + content)
- `pref_width[i]` — preferred width (from catalog defaults or user override)
- `max_width[i]` — maximum width (from cell mode)
- `grow_weight[i]` — how much this cell consumes excess space
- `squeeze_weight[i]` — how much this cell absorbs deficit

The solver distributes W across the row such that:
```
Σ width[i] = W
min_width[i] ≤ width[i] ≤ max_width[i]  for all i
```

When `Σ pref_width[i] < W`: distribute surplus by `grow_weight[i]`.
When `Σ pref_width[i] > W`: distribute deficit by `squeeze_weight[i]`.
When `Σ min_width[i] > W`: constraint violation — engine reports which cells cannot fit and suggests remediation (reduce cabinet count, change grid preset, accept overflow).

**Fixed (Ice) cells** have `grow_weight = squeeze_weight = 0` — they never change size.
**Variable (Water) cells** have non-zero weights — they flex with available space.
**Presentation (Frost) cells** are fixed size but clip content (no squeeze affects container).
**Plasma (Fire) cells** have a collapsed size (tab) and expanded size (overlay) — the collapsed size participates in the row's distribution; the expanded size overlays without reflow.

### Invariant 3: Runtime Derivation

Cell dimensions are never stored. They are COMPUTED from:
1. Parent container dimensions
2. Sibling cell constraints (the row/column they share)
3. Content demands (measured at layout time)
4. Coprime grid rules at the current depth
5. Variables resolved from the catalog override chain

On any change to any of these inputs, the affected cells recompute. The recomputation cascades through child cells recursively to depth 5 if needed.

**The grid does not HAVE a layout. The grid IS the layout computation.**

### Invariant 4: Variable Agnosticism

The constraint engine accepts variables by name and type. It has NO named constants for domain-specific values. `hole_spacing` is a variable. `wall_thickness` is a variable. `door_overlay` is a variable. The engine evaluates conditional rules against variables but does not know what `hole_spacing` means.

Domain knowledge (values, rules, relationships) lives in the backend database (PlenumDB). The catalog fetches the variable set appropriate to the current context. The engine operates on whatever it receives.

---

## 4. The Assembly Abstraction

An assembly is a cell whose content is a grid of sub-cells. When placed in a parent grid, the assembly appears as ONE cell — its outer boundary participates in the parent's flex/grow/squeeze. Its internal cells are invisible to the parent.

When the user expands the assembly (drill down), the parent grid remains unchanged; the UI scales to show the assembly's internal grid. The assembly's outer boundary becomes the new frame.

**Assembly placement rule:** An assembly occupies exactly one cell slot in its parent, regardless of how many sub-cells it contains internally. A "Master Bath Vanity" assembly containing 6 cabinets + 2 fillers + 1 countertop occupies ONE cell on the wall. The wall's constraint solver treats it as a single unit.

**Assembly internal rule:** The assembly's internal grid is itself a constraint system following all four invariants. The vanity's 6 cabinets flex/grow/squeeze among themselves within the assembly's fixed outer width, with the same zero-gap edge identity.

**Assembly inheritance rule:** Variables defined at a parent level propagate to assemblies by default. The "Kitchen" catalog's `reveal` value applies inside all assemblies placed in kitchen walls. An assembly can override specific variables for its interior (e.g., a "Display Hutch" assembly might override `reveal` to `0mm` for a flush-face interior look).

---

## 5. The Four Views

The same cell hierarchy is viewed through four projections. Each projection maps the cell's dimensions to screen coordinates differently. The underlying cells are identical.

| View | What's Horizontal | What's Vertical | What's Depth |
|---|---|---|---|
| Wall Elevation | Cabinet widths | Cabinet heights | Cabinet depths (hidden) |
| Floor Plan | Cabinet widths | Cabinet depths | Cabinet heights (hidden) |
| Section | Depth | Height | Width (hidden) |
| 3D Perspective | All three dimensions projected |

**Invariant:** Cells are 3-dimensional objects. Views are 2D projections of them (plus perspective projection for 3D view). Changing a cell in any view changes the underlying 3D cell. All views update simultaneously.

---

## 6. Constraint Resolution Order

When any input changes, resolution proceeds in this order:

```
1. Catalog base variables loaded from database
2. Project overrides applied
3. Component (per-cabinet) overrides applied
4. Conditional rules evaluated in topological order of their dependencies
   (rule B that uses rule A's output evaluates after rule A)
5. Starting at depth 0, cells compute their dimensions
6. For each cell at depth n, its constraint solver runs:
   a. Read available dimension from parent
   b. Gather sibling constraints
   c. Distribute per flex/grow/squeeze rules
   d. Assign dimension to each child cell
7. For each child cell, recursion into depth n+1
8. When reaching depth 5 (operations), tool path geometry generates
9. If any cell at any depth reports a constraint violation, resolution halts,
   the violation path bubbles up, and the UI displays the conflict
```

**Consequence:** A change at depth 0 (add a room) triggers resolution through all five depths. A change at depth 4 (change one boring pattern) triggers resolution only at depths 4–5. The engine computes only what changed.

---

## 7. What This Replaces

| Traditional CAD Approach | PlenumCAD Constraint System |
|---|---|
| Draw each cabinet individually with fixed coordinates | Place cabinets in cells; dimensions computed from constraints |
| Manually resolve collisions between parts | Zero-gap edge identity makes collisions structurally impossible |
| Re-draft everything when a wall changes | Change propagates through the cascade automatically |
| Separate tools for 2D plan, 3D model, shop drawings | One cell hierarchy viewed through four projections |
| Hardcoded construction logic per software | Agnostic engine + catalog-provided variables and rules |
| Assemblies as static blocks that break when resized | Assemblies as nested constraint grids that flex internally |

---

## 8. Open Questions for Salvi

1. **Depth 0 scope:** Is a Project a single room, or does the hierarchy go Project → Rooms[]? I've written it as Rooms[] but need confirmation.

2. **Constraint violation UX:** When a row of cabinets at depth 2 cannot fit on a wall because `Σ min_width > available_width`, what's the remediation priority? (a) Engine suggests which cabinet to remove, (b) Engine suggests reducing a specific cabinet's min_width, (c) Engine allows overflow with warning, (d) User-configurable.

3. **Assembly re-entry:** When a user double-clicks an assembly to edit its interior, does the parent grid freeze, or does the parent continue to recompute as the assembly is edited? I've assumed it stays reactive.

4. **3D Perspective constraint updates:** In wall elevation, dragging a cabinet's edge updates the constraint immediately. In 3D perspective, does the same drag behavior apply, or is 3D view-only with edits happening in 2D projections?

5. **Zero-gap at corners:** Two walls meeting at 90° share a corner. The last cabinet on Wall A and the first cabinet on Wall B both have edges at that corner. Is the corner a shared edge (one object, two-wall reference) or two edges that happen to be coincident? Corner conditions (filler, butted, mitered) depend on this.

---

*This is the unified constraint system in formal terms. Every behavior in PlenumCAD at every level at every view is a consequence of these four invariants applied to variables from the catalog.*

*Lo Sono Capomastro — Così sia.*
